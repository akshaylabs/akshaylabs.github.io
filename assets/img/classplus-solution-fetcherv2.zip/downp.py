import json
import os
import re
import time
import requests

def sanitize_filename(name):
    """
    Removes characters that are invalid for filenames in most operating systems.
    """
    return re.sub(r'[<>:"/\\|?*]', '_', name)

def download_file(url, local_path, retries=5, delay=2):
    """
    Downloads a file with a retry mechanism.

    Args:
        url (str): The URL of the file to download.
        local_path (str): The local path where the file should be saved.
        retries (int): The number of times to retry the download.
        delay (int): The delay in seconds between retries.

    Returns:
        bool: True if the download was successful, False otherwise.
    """
    filename = os.path.basename(local_path)
    for attempt in range(retries):
        try:
            print(f"Downloading {filename} from {url} (Attempt {attempt + 1}/{retries})...")
            with requests.get(url, stream=True, timeout=30) as r:
                r.raise_for_status()
                with open(local_path, 'wb') as f:
                    for chunk in r.iter_content(chunk_size=8192):
                        f.write(chunk)
                print(f"Successfully downloaded to {local_path}")
                return True
        except requests.exceptions.RequestException as e:
            print(f"Error on attempt {attempt + 1}: {e}")
            if attempt < retries - 1:
                print(f"Retrying in {delay} seconds...")
                time.sleep(delay)
            else:
                print(f"Failed to download {filename} after {retries} attempts.")
    return False

def process_content_item(item, file_map_by_id, pdfs_dir, thumbnails_dir):
    """
    Processes a single content item, downloading if necessary and updating its status.
    """
    item_id = item.get('id')
    if not item_id:
        return

    # If item is already successfully downloaded, skip it
    if item_id in file_map_by_id and file_map_by_id[item_id].get('status') == 'success':
        return

    content_type = item.get('contentType')
    name = item.get('name', '')
    local_path = None
    file_type = None
    url = None

    # --- Logic for Thumbnails (contentType: 2) ---
    if content_type == 2:
        thumbnail_url = item.get('thumbnailUrl')
        if name and thumbnail_url:
            valid_ext = ['.jpg', '.jpeg', '.png', '.svg', '.gif', '.bmp']
            _, ext = os.path.splitext(name)
            filename = sanitize_filename(name) if ext.lower() in valid_ext else f"{sanitize_filename(name)}.jpg"
            local_path = os.path.join(thumbnails_dir, filename)
            file_type = 'thumbnail'
            url = thumbnail_url

    # --- Logic for PDFs (contentType: 3) ---
    elif content_type == 3 and item.get('format') == 'pdf':
        pdf_url = item.get('url')
        if name and pdf_url:
            filename = sanitize_filename(name)
            if not filename.lower().endswith('.pdf'):
                filename += '.pdf'
            local_path = os.path.join(pdfs_dir, filename)
            file_type = 'pdf'
            url = pdf_url

    # --- Perform Download and Update Map ---
    if local_path and url:
        is_success = download_file(url, local_path)
        status = 'success' if is_success else 'failed'
        
        # Update existing entry or create a new one
        if item_id in file_map_by_id:
            file_map_by_id[item_id]['status'] = status
        else:
            file_map_by_id[item_id] = {
                'id': item_id,
                'name': name,
                'type': file_type,
                'original_url': url,
                'local_path': local_path,
                'status': status
            }

def traverse_content(item, callback, **kwargs):
    """
    Recursively traverses the course content structure and applies a callback to each item.
    """
    callback(item, **kwargs)
    if item.get('contentType') == 1 and 'children' in item:
        for child in item['children']:
            traverse_content(child, callback, **kwargs)

def main():
    """
    Main function to run the script.
    """
    json_input_file = 'course.json'
    pdfs_output_dir = 'pdfs'
    thumbnails_output_dir = 'thumbnails'
    map_output_file = 'file_map.json'

    os.makedirs(pdfs_output_dir, exist_ok=True)
    os.makedirs(thumbnails_output_dir, exist_ok=True)

    # 1. Load the existing file map if it exists
    file_map_list = []
    if os.path.exists(map_output_file):
        try:
            with open(map_output_file, 'r', encoding='utf-8') as f:
                file_map_list = json.load(f)
        except (json.JSONDecodeError, FileNotFoundError):
            print(f"Warning: Could not read '{map_output_file}'. Starting with a fresh map.")
            file_map_list = []
    
    # Convert list to a dictionary for efficient lookup (id -> item)
    file_map_by_id = {item['id']: item for item in file_map_list}

    # 2. Retry any previously failed downloads
    failed_items = [item for item in file_map_by_id.values() if item.get('status') == 'failed']
    if failed_items:
        print(f"\n--- Retrying {len(failed_items)} failed downloads ---")
        for item in failed_items:
            if download_file(item['original_url'], item['local_path']):
                item['status'] = 'success' # Update status on success
        print("--- Finished retrying ---\n")

    # 3. Load the main course data
    try:
        with open(json_input_file, 'r', encoding='utf-8') as f:
            course_data = json.load(f)
    except FileNotFoundError:
        print(f"Error: The file '{json_input_file}' was not found.")
        return
    except json.JSONDecodeError:
        print(f"Error: The file '{json_input_file}' is not a valid JSON file.")
        return

    # 4. Process all items from course.json, skipping successful ones
    print("--- Processing course content ---")
    if isinstance(course_data, list):
        for item in course_data:
            traverse_content(item, process_content_item, file_map_by_id=file_map_by_id, pdfs_dir=pdfs_output_dir, thumbnails_dir=thumbnails_output_dir)
    elif isinstance(course_data, dict):
        traverse_content(course_data, process_content_item, file_map_by_id=file_map_by_id, pdfs_dir=pdfs_output_dir, thumbnails_dir=thumbnails_output_dir)

    # 5. Save the updated mapping back to the JSON file
    # Convert the dictionary back to a list for saving
    final_map_list = list(file_map_by_id.values())
    with open(map_output_file, 'w', encoding='utf-8') as f:
        json.dump(final_map_list, f, indent=4)

    print(f"\nProcessing complete. A map of downloaded files has been saved to '{map_output_file}'")

if __name__ == "__main__":
    main()