const STORAGE_KEY = 'yt_crop_settings';

const enableToggle = document.getElementById('enableToggle');
const cropSlider = document.getElementById('cropSlider');
const valueBadge = document.getElementById('valueBadge');
const cropIndicator = document.getElementById('cropIndicator');
const previewTitle = document.getElementById('previewTitle');
const previewDetail = document.getElementById('previewDetail');
const manualInput = document.getElementById('manualInput');
const statusDot = document.getElementById('statusDot');
const statusText = document.getElementById('statusText');
const resetBtn = document.getElementById('resetBtn');
const cropSection = document.getElementById('cropSection');

let settings = {
  enabled: false,
  bottomPx: 40
};

const PRESETS = [20, 40, 60, 80, 100, 120];
const DESCRIPTIONS = {
  small: 'Removes a thin strip. Good for small watermarks.',
  medium: 'Removes ~8% of video at 1080p. Good for most bottom banners.',
  large: 'Removes a significant portion. Good for tall ticker bars.',
  xlarge: 'Removes a large strip. Use for very tall embedded overlays.'
};

function getDescription(px) {
  if (px <= 30) return DESCRIPTIONS.small;
  if (px <= 70) return DESCRIPTIONS.medium;
  if (px <= 120) return DESCRIPTIONS.large;
  return DESCRIPTIONS.xlarge;
}

function updateUI() {
  const px = settings.bottomPx;

  // Slider + badge
  cropSlider.value = Math.min(px, 200);
  valueBadge.textContent = px + 'px';
  manualInput.value = px;

  // Preview indicator: simulate % of a 45px tall thumbnail
  // A 1080p video is 1080px. px/1080 * 45 = indicator height
  const pct = Math.min((px / 1080) * 100, 50);
  const heightPx = Math.max(3, Math.round((px / 200) * 22));
  cropIndicator.style.height = heightPx + 'px';

  // Preview text
  previewTitle.textContent = `Crop: ${px}px from bottom`;
  previewDetail.textContent = getDescription(px);

  // Preset buttons
  document.querySelectorAll('.preset-btn').forEach(btn => {
    btn.classList.toggle('active', parseInt(btn.dataset.px) === px);
  });

  // Enable state
  enableToggle.checked = settings.enabled;
  cropSection.classList.toggle('disabled-overlay', !settings.enabled);

  // Status
  if (settings.enabled) {
    statusDot.classList.add('on');
    statusText.textContent = `Active — cropping ${px}px`;
  } else {
    statusDot.classList.remove('on');
    statusText.textContent = 'Inactive';
  }
}

function saveAndSend() {
  chrome.storage.local.set({ [STORAGE_KEY]: settings });

  // Send to active YouTube tab
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs[0]) return;
    const tab = tabs[0];
    if (!tab.url || !tab.url.includes('youtube.com')) return;
    chrome.tabs.sendMessage(tab.id, {
      type: 'UPDATE_CROP',
      settings: settings
    }).catch(() => {
      // Content script may not be injected yet; inject it
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['content.js']
      }).then(() => {
        chrome.tabs.sendMessage(tab.id, {
          type: 'UPDATE_CROP',
          settings: settings
        }).catch(() => {});
      }).catch(() => {});
    });
  });
}

function setCrop(px) {
  settings.bottomPx = Math.max(1, Math.min(400, parseInt(px) || 40));
  updateUI();
  saveAndSend();
}

// Event listeners
enableToggle.addEventListener('change', () => {
  settings.enabled = enableToggle.checked;
  updateUI();
  saveAndSend();
});

cropSlider.addEventListener('input', () => {
  setCrop(parseInt(cropSlider.value));
});

manualInput.addEventListener('change', () => {
  const val = parseInt(manualInput.value);
  if (!isNaN(val) && val > 0) setCrop(val);
});

manualInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') manualInput.blur();
});

document.querySelectorAll('.preset-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    setCrop(parseInt(btn.dataset.px));
  });
});

resetBtn.addEventListener('click', () => {
  settings = { enabled: false, bottomPx: 40 };
  updateUI();
  saveAndSend();
});

// Load saved settings on popup open
chrome.storage.local.get(STORAGE_KEY, (data) => {
  if (data[STORAGE_KEY]) {
    settings = { ...settings, ...data[STORAGE_KEY] };
  }
  updateUI();
});
