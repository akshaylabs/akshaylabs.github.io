// YouTube Video Cropper - Content Script

const STORAGE_KEY = 'yt_crop_settings';
const STYLE_ID = 'yt-crop-injected-style';

let settings = {
  enabled: false,
  bottomPx: 40
};

function getInjectedStyle(cropPx) {
  // YouTube in fullscreen uses position:absolute and calculates top/left
  // to center the video. We can't easily override that math via CSS alone.
  // Instead we let YouTube center it normally, then use translateY to shift
  // UP by half the crop — this re-centers the *visible* (cropped) portion.
  // We use a CSS variable trick: apply the same rule for both normal + fullscreen.
  return `
    /* Normal + fullscreen: clip bottom and shift up by half crop to re-center */
    .html5-video-container video,
    #movie_player video {
      clip-path: inset(0px 0px ${cropPx}px 0px) !important;
      transform: translateY(${Math.round(cropPx / 2)}px) !important;
      transform-origin: center top !important;
      transition: none !important;
    }
  `;
}

function injectStyle(cropPx) {
  let el = document.getElementById(STYLE_ID);
  if (!el) {
    el = document.createElement('style');
    el.id = STYLE_ID;
    document.head.appendChild(el);
  }
  el.textContent = getInjectedStyle(cropPx);
}

function removeStyle() {
  const el = document.getElementById(STYLE_ID);
  if (el) el.remove();
}

function applyToVideo() {
  if (settings.enabled && settings.bottomPx > 0) {
    injectStyle(settings.bottomPx);
  } else {
    removeStyle();
  }
}

function loadAndApply() {
  chrome.storage.local.get(STORAGE_KEY, (data) => {
    if (data[STORAGE_KEY]) {
      settings = { ...settings, ...data[STORAGE_KEY] };
    }
    applyToVideo();
  });
}

// Re-apply when DOM changes (video replaced on navigation)
const observer = new MutationObserver(() => {
  if (settings.enabled) applyToVideo();
});
observer.observe(document.body, { childList: true, subtree: true });

// Re-apply on fullscreen change
document.addEventListener('fullscreenchange', () => {
  setTimeout(applyToVideo, 200);
});
document.addEventListener('webkitfullscreenchange', () => {
  setTimeout(applyToVideo, 200);
});

// Listen for messages from popup
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'UPDATE_CROP') {
    settings = { ...settings, ...msg.settings };
    applyToVideo();
    sendResponse({ ok: true });
  }
  if (msg.type === 'GET_STATUS') {
    sendResponse({ settings });
  }
  return true;
});

loadAndApply();