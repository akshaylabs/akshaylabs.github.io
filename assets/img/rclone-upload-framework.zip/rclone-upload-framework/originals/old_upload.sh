#!/usr/bin/env bash
#
# robust_rclone_uploader.sh
# -----------------------------------------------------------------------------
# Merged and enhanced script for end-to-end, interruption-safe bulk uploading.
# It combines a simple retry mechanism with an advanced, stateful, and
# highly configurable framework.
#
# Features
# --------
# • Uses a structured table for defining upload jobs (source -> destination).
# • Employs a dedicated rclone config file to avoid permission issues.
# • Automatic resume after interruption via a state file (tracks PENDING, OK, FAIL).
# • Per-job retry loop for upload and verification steps.
# • Verification via `rclone check` (defaults to `--size-only` for speed).
# • Singleton execution using a lock file to prevent simultaneous runs.
# • Colored, timestamped master log and individual log files for each job.
# • Comprehensive CLI flags for overriding defaults, forcing reruns, and dry runs.
# • Robust rclone options for timeouts and retries are pre-configured.
# • Optional check for remote free space before starting uploads.
#
# -----------------------------------------------------------------------------
# CONFIG SECTION – EDIT THESE TO MATCH YOUR ENVIRONMENT
# -----------------------------------------------------------------------------

# Default path to the rclone configuration file (override with --config)
RCLONE_CONFIG_DEFAULT="/teamspace/studios/this_studio/rclone_config/rclone.conf"

# Default path to the rclone binary (optional; searches PATH if empty)
RCLONE_BIN_DEFAULT="/teamspace/studios/this_studio/rclone-v1.70.3-linux-amd64/rclone"

# Default base path containing the source folders (override with --base)
# *** MAKE SURE THIS PATH IS CORRECT FOR YOUR SYSTEM ***
BASE_PATH_DEFAULT="/teamspace/studios/this_studio/video_av_chemistry_classes/course_output/course_downloads/Old recorded"

# --- Rclone Performance and Robustness Tuning ---
# These options are passed to rclone. Use an array for safer option handling.
# NOTE: -P (--progress) is now handled conditionally and is not in this list.

RCLONE_OPTS_DEFAULT=(
  "--contimeout=60s"        # Connect timeout
  "--timeout=300s"          # Data transfer timeout
  "--retries=5"             # Retries on recoverable errors (per-file)
  "--low-level-retries=10"  # Retries for low-level network operations
)

# --- Transfer Tuning & Retry Logic ---
TRANSFERS_DEFAULT=4         # Number of parallel file transfers
CHECKERS_DEFAULT=8          # Number of parallel checkers (for file listings)
MAX_RETRIES_DEFAULT=3       # Max attempts to upload+verify a group
RETRY_SLEEP_DEFAULT=15      # Seconds to wait between failed attempts

# -----------------------------------------------------------------------------
# GROUP DEFINITIONS
# Format: label|local_relative_path|full_remote_path
# *** MODIFIED FOR 4-BUCKET PLAN ***
# -----------------------------------------------------------------------------
read -r -d '' GROUP_TABLE <<'EOF_GROUPS'
# --- BUCKET 1 (14.047 GiB) -> Remote: old1 ---
Bucket1-Pharmacotherapeutics|D. Pharm Second Year/Pharmacotherapeutics|old1:OLD_DPharm_SecondYear/Bucket1/Pharmacotherapeutics

# --- BUCKET 2 (14.201 GiB) -> Remote: old2 ---
Bucket2-CommunityPharm|D. Pharm Second Year/Community Pharmacy|old2:OLD_DPharm_SecondYear/Bucket2/Community Pharmacy
Bucket2-EEDM|D. Pharm Second Year/EEDM|old2:OLD_DPharm_SecondYear/Bucket2/EEDM

# --- BUCKET 3 (9.390 GiB) -> Remote: old3 ---
Bucket3-HospitalPharm|D. Pharm Second Year/Hospital and Clinical Pharmacy|old3:OLD_DPharm_SecondYear/Bucket3/Hospital and Clinical Pharmacy

# --- BUCKET 4 (11.180 GiB) -> Remote: old4 ---
Bucket4-Pharmacology|D. Pharm Second Year/Pharmacology|old4:OLD_DPharm_SecondYear/Bucket4/Pharmacology
EOF_GROUPS

# -----------------------------------------------------------------------------
# END CONFIG SECTION
# -----------------------------------------------------------------------------

# ===== Globals set from CLI and config =====
BASE_PATH="$BASE_PATH_DEFAULT"
RCLONE_CONFIG="$RCLONE_CONFIG_DEFAULT"
RCLONE_BIN="$RCLONE_BIN_DEFAULT"
RCLONE_OPTS=("${RCLONE_OPTS_DEFAULT[@]}") # Copy default array
TRANSFERS="$TRANSFERS_DEFAULT"
CHECKERS="$CHECKERS_DEFAULT"
MAX_RETRIES="$MAX_RETRIES_DEFAULT"
RETRY_SLEEP="$RETRY_SLEEP_DEFAULT"
VERIFY=1
DEEP_VERIFY=0 # Default to size-only check
DRY_RUN=0
FORCE_ALL=0
FORCE_LABEL=""

# -----------------------------------------------------------------------------
# Colors (auto-disable if not a TTY)
# -----------------------------------------------------------------------------
if [[ -t 1 ]]; then
  C_RESET='\033[0m' C_GREEN='\033[32m' C_YELLOW='\033[33m' C_RED='\033[31m' C_BLUE='\033[34m'
else
  C_RESET='' C_GREEN='' C_YELLOW='' C_RED='' C_BLUE=''
fi

# -----------------------------------------------------------------------------
# Print usage
# -----------------------------------------------------------------------------
usage() {
  cat <<USAGE
Usage: $0 [options]

Options:
  --base PATH            Base path of source folders. Default: "$BASE_PATH_DEFAULT"
  --config FILE          rclone config file. Default: "$RCLONE_CONFIG_DEFAULT"
  --rclone-bin PATH      Path to rclone binary. Default: Searches PATH or uses "$RCLONE_BIN_DEFAULT"
  --transfers N          Parallel file transfers. Default: $TRANSFERS_DEFAULT
  --checkers N           Parallel metadata checkers. Default: $CHECKERS_DEFAULT
  --max-retries N        Upload+verify attempts per group. Default: $MAX_RETRIES_DEFAULT
  --retry-sleep SEC      Seconds between retry attempts. Default: $RETRY_SLEEP_DEFAULT
  --no-verify            Skip 'rclone check' step (upload only).
  --deep-verify          Use checksums for verification (slower but more thorough).
  --dry-run              Pass --dry-run to rclone (simulate changes).
  --force-all            Reprocess all groups even if state shows success.
  --force LABEL          Reprocess only the named group label.
  --list-groups          Print group labels and exit.
  -h|--help              Show this help.

Example:
  $0 --force Bucket4-Pharmacology --deep-verify
USAGE
}

# -----------------------------------------------------------------------------
# Parse CLI
# -----------------------------------------------------------------------------
while [[ $# -gt 0 ]]; do
  case "$1" in
    --base) BASE_PATH="$2"; shift 2;;
    --config) RCLONE_CONFIG="$2"; shift 2;;
    --rclone-bin) RCLONE_BIN="$2"; shift 2;;
    --transfers) TRANSFERS="$2"; shift 2;;
    --checkers) CHECKERS="$2"; shift 2;;
    --max-retries) MAX_RETRIES="$2"; shift 2;;
    --retry-sleep) RETRY_SLEEP="$2"; shift 2;;
    --no-verify) VERIFY=0; shift;;
    --deep-verify) DEEP_VERIFY=1; shift;;
    --dry-run) DRY_RUN=1; shift;;
    --force-all) FORCE_ALL=1; shift;;
    --force) FORCE_LABEL="$2"; shift 2;;
    --list-groups) echo "$GROUP_TABLE" | grep -v '^#' | cut -d'|' -f1; exit 0;;
    -h|--help) usage; exit 0;;
    *) echo "Unknown option: $1" >&2; usage; exit 1;;
  esac
done

# -----------------------------------------------------------------------------
# Derived paths/files
# -----------------------------------------------------------------------------
LOG_DIR="$BASE_PATH/.rclone_logs"
MASTER_LOG="$LOG_DIR/master.log"
STATE_FILE="$LOG_DIR/state.tsv"   # label\tstatus\tattempts
LOCK_FILE="$LOG_DIR/.upload.lock"

mkdir -p "$LOG_DIR"

# -----------------------------------------------------------------------------
# Logging helpers
# -----------------------------------------------------------------------------
ts() { date +'%F %T'; }
log_exec() { echo -e "[$(ts)] $*" >> "$MASTER_LOG"; }
log() { echo -e "[$(ts)] $*" | tee -a "$MASTER_LOG"; }
log_green() { log "${C_GREEN}$*${C_RESET}"; }
log_yellow() { log "${C_YELLOW}$*${C_RESET}"; }
log_red() { log "${C_RED}$*${C_RESET}"; }
log_blue() { log "${C_BLUE}$*${C_RESET}"; }

# -----------------------------------------------------------------------------
# State handling (status: PENDING, OK, FAIL, RUNNING)
# -----------------------------------------------------------------------------
declare -A STATE_STATUS
declare -A STATE_ATTEMPTS

init_state_file() {
  : >"$STATE_FILE"
  while IFS='|' read -r label _ _; do
    [[ -z "$label" || "$label" =~ ^# ]] && continue
    echo -e "${label}\tPENDING\t0" >>"$STATE_FILE"
    STATE_STATUS[$label]="PENDING"
    STATE_ATTEMPTS[$label]=0
  done <<<"$GROUP_TABLE"
}

load_state_file() {
  if [[ ! -f "$STATE_FILE" ]]; then init_state_file; return; fi
  while IFS=$'\t' read -r label status attempts _; do
    [[ -z "$label" ]] && continue
    local clean_attempts
    clean_attempts=$(echo "$attempts" | grep -o '^[0-9]\+' || echo "0")
    STATE_STATUS[$label]="$status"
    STATE_ATTEMPTS[$label]="${clean_attempts:-0}"
  done <"$STATE_FILE"
}

save_state_file() {
  local temp_state_file="$STATE_FILE.new"
  : >"$temp_state_file"
  while IFS='|' read -r label _ _; do
    [[ -z "$label" || "$label" =~ ^# ]] && continue
    echo -e "${label}\t${STATE_STATUS[$label]:-PENDING}\t${STATE_ATTEMPTS[$label]:-0}" >>"$temp_state_file"
  done <<<"$GROUP_TABLE"
  mv "$temp_state_file" "$STATE_FILE"
}

update_state() {
  local label="$1" status="$2" attempts="$3"
  STATE_STATUS[$label]="$status"
  STATE_ATTEMPTS[$label]="$attempts"
  save_state_file
}

# -----------------------------------------------------------------------------
# Prerequisite and Lockfile Checks
# -----------------------------------------------------------------------------
RCLONE_CMD=""
if [[ -n "$RCLONE_BIN" && -x "$RCLONE_BIN" ]]; then
  RCLONE_CMD="$RCLONE_BIN"
elif command -v rclone >/dev/null 2>&1; then
  RCLONE_CMD=$(command -v rclone)
else
  log_red "FATAL: rclone command not found."
  log_red "Please install rclone, ensure it's in your PATH, or specify its location via --rclone-bin."
  exit 1
fi

if [[ ! -f "$RCLONE_CONFIG" ]]; then
  log_red "FATAL: rclone config not found at: $RCLONE_CONFIG"
  log_red "You can create one by running: $RCLONE_CMD config --config \"$RCLONE_CONFIG\""
  exit 1
fi

exec 9>"$LOCK_FILE"
if ! flock -n 9; then
  log_red "Another instance of this script is already running (lock held on $LOCK_FILE). Exiting."
  exit 1
fi

cleanup() {
  local rc=$?
  if [[ $rc -ne 0 ]]; then log_red "Script exiting with rc=$rc (interrupted?). State saved."; fi
}
trap cleanup EXIT INT TERM

# -----------------------------------------------------------------------------
# Optional remote free-space check (best effort)
# -----------------------------------------------------------------------------
check_remote_space() {
  local remote_path="$1"
  local remote="${remote_path%%:*}:"
  log_blue "($remote) Checking free space (informational)..."
  local free_bytes
  free_bytes=$("$RCLONE_CMD" about "$remote" --config "$RCLONE_CONFIG" 2>/dev/null | awk '/Free:/{print $2$3}')
  if [[ -n "$free_bytes" ]]; then
    log_blue "($remote) Reports Free: $free_bytes"
  else
    log_yellow "($remote) Could not determine free space (backend may not support it)."
  fi
}

# -----------------------------------------------------------------------------
# Process a single group (upload + optional verify)
# -----------------------------------------------------------------------------
process_group() {
  local label="$1" local_rel="$2" remote_path="$3"
  local total_attempts=${STATE_ATTEMPTS[$label]:-0}

  # --- Filtering Logic ---
  if (( FORCE_ALL == 0 )) && [[ -n "$FORCE_LABEL" ]] && [[ "$FORCE_LABEL" != "$label" ]]; then
    log_exec "Skipping $label (only forcing '$FORCE_LABEL')."
    return 0
  fi
  if (( FORCE_ALL == 0 )) && [[ -z "$FORCE_LABEL" ]] && [[ "${STATE_STATUS[$label]}" == "OK" ]]; then
    log_exec "Skipping $label (already marked OK). Use --force-all or --force '$label' to rerun."
    return 0
  fi

  local src="$BASE_PATH/$local_rel"
  if [[ ! -d "$src" ]]; then
    log_red "($label) Source directory missing: $src. Marking as FAIL."
    update_state "$label" FAIL "$total_attempts"
    return 1
  fi

  update_state "$label" RUNNING "$total_attempts"
  local group_log="$LOG_DIR/${label//\//_}.log"
  : >"$group_log"

  local try=1
  while (( try <= MAX_RETRIES )); do
    total_attempts=$((total_attempts + 1))
    log_blue "($label) Starting attempt #$try of $MAX_RETRIES. Uploading: $src -> $remote_path"
    update_state "$label" RUNNING "$total_attempts"

    # *** FIXED ***
    # Build command flags dynamically.
    # The -P (--progress) flag can cause a non-zero exit code with --dry-run,
    # so we only add it when not in a dry run.
    local rclone_run_opts=("${RCLONE_OPTS[@]}")
    if (( DRY_RUN == 1 )); then
      rclone_run_opts+=(--dry-run)
    else
      rclone_run_opts+=(-P) # Add Progress flag only for real runs
    fi

    # --- Step 1: Upload ---
    if ! "$RCLONE_CMD" copy "$src" "$remote_path" \
        --config "$RCLONE_CONFIG" \
        --transfers="$TRANSFERS" --checkers="$CHECKERS" \
        --create-empty-src-dirs \
        "${rclone_run_opts[@]}" \
        --log-file="$group_log" --log-level INFO; then
      log_yellow "($label) 'rclone copy' command failed on attempt #$try. Full log: $group_log"
    else
      # --- Step 2: Verify (if copy was successful) ---
      if (( VERIFY == 1 )); then
        local verify_mode="size-only"
        local check_opts=("--size-only")
        if (( DEEP_VERIFY == 1 )); then
          verify_mode="checksum"
          check_opts=() # Use default check (hashes)
        fi
        log_blue "($label) Upload command successful. Verifying integrity ($verify_mode)..."

        if "$RCLONE_CMD" check "$src" "$remote_path" \
            --config "$RCLONE_CONFIG" \
            --checkers="$CHECKERS" \
            "${rclone_run_opts[@]}" \
            "${check_opts[@]}" \
            --log-file="$group_log" --log-level INFO; then
          log_green "($label) SUCCESS: Upload and verification complete."
          update_state "$label" OK "$total_attempts"
          return 0
        else
          log_red "($label) VERIFICATION FAILED on attempt #$try. Differences detected."
          log_red "($label) Check the log for details: $group_log"
        fi
      else # Verification disabled
        log_green "($label) SUCCESS: Upload complete (verification was disabled)."
        update_state "$label" OK "$total_attempts"
        return 0
      fi
    fi

    (( try++ ))
    if (( try <= MAX_RETRIES )); then
      log_yellow "($label) Sleeping for $RETRY_SLEEP seconds before next attempt..."
      sleep "$RETRY_SLEEP"
    fi
  done

  log_red "($label) FAILED after $MAX_RETRIES attempts. State remains FAIL. See log: $group_log"
  update_state "$label" FAIL "$total_attempts"
  return 1
}

# -----------------------------------------------------------------------------
# Main Execution
# -----------------------------------------------------------------------------
log_blue "--- Robust Rclone Uploader Started ---"
log "Base Path: $BASE_PATH"
log "Rclone Config: $RCLONE_CONFIG"
log "Rclone Binary: $RCLONE_CMD"
log "Log Directory: $LOG_DIR"
if ((DRY_RUN == 1)); then log_yellow "Dry Run mode is ACTIVE. No files will be transferred."; fi
if ((DEEP_VERIFY == 1)); then log_yellow "Deep Verification (checksum) is ACTIVE."; fi


load_state_file   # Creates state file if missing
save_state_file   # Ensures all defined groups are in the state file

# Process each group defined in the table
while IFS='|' read -r label local_rel remote_path; do
  [[ -z "$label" || "$label" =~ ^# ]] && continue # Skip empty lines and comments
  check_remote_space "$remote_path"
  process_group "$label" "$local_rel" "$remote_path" || true
done <<<"$GROUP_TABLE"

# --- Final Summary ---
log_blue "--- All Jobs Processed. Final Summary ---"
FAIL_COUNT=0
while IFS='|' read -r label local_rel _; do
  [[ -z "$label" || "$label" =~ ^# ]] && continue # Skip empty lines and comments
  status="${STATE_STATUS[$label]}"
  attempts="${STATE_ATTEMPTS[$label]}"
  case "$status" in
    OK) log_green "  - $label: OK (total attempts: $attempts)";;
    FAIL) log_red "  - $label: FAIL (total attempts: $attempts)"; FAIL_COUNT=$((FAIL_COUNT + 1));;
    RUNNING) log_yellow "  - $label: INCOMPLETE (stuck in RUNNING state, attempts: $attempts)"; FAIL_COUNT=$((FAIL_COUNT + 1));;
    *) log_yellow "  - $label: $status (attempts: $attempts)";;
  esac
done <<<"$GROUP_TABLE"

# Create a summary file for any failed groups for external tooling
FAIL_FILE="$LOG_DIR/rclone_failed_groups.txt"
if (( FAIL_COUNT > 0 )); then
  log_red "There were $FAIL_COUNT incomplete or failed groups. Writing details to: $FAIL_FILE"
  : > "$FAIL_FILE"
  while IFS='|' read -r label local_rel remote_path; do
    [[ -z "$label" || "$label" =~ ^# ]] && continue
    status="${STATE_STATUS[$label]}"
    if [[ "$status" == "FAIL" || "$status" == "RUNNING" ]]; then
        echo "$label|$BASE_PATH/$local_rel|$remote_path" >> "$FAIL_FILE"
    fi
  done <<<"$GROUP_TABLE"
  exit 2 # Exit with error code 2 if there were failures
else
  log_green "--- All groups completed successfully. ---"
  [[ -f "$FAIL_FILE" ]] && rm "$FAIL_FILE"
  exit 0
fi