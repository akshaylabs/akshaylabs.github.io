#!/usr/bin/env bash
# =============================================================================
# rclone-uploader.sh — Universal Rclone Upload Framework
# =============================================================================
#
# A generic, production-grade framework for bulk uploading files to any
# cloud storage backend supported by rclone (Google Drive, S3, Mega,
# Dropbox, Backblaze B2, OneDrive, SFTP, and 70+ more).
#
# USAGE
#   ./rclone-uploader.sh --groups config/my-jobs.conf [options]
#
# QUICKSTART
#   1. Install rclone and configure your remotes:  rclone config
#   2. Copy config/jobs.example.conf → config/my-jobs.conf
#   3. Edit my-jobs.conf with your source folders and remote paths
#   4. Run: ./rclone-uploader.sh --groups config/my-jobs.conf
#
# See README.md for full documentation.
# =============================================================================

set -euo pipefail

FRAMEWORK_VERSION="1.0.0"

# =============================================================================
# DEFAULTS  (all overridable via CLI flags or --groups config file)
# =============================================================================
RCLONE_CONFIG_DEFAULT=""          # Empty = use rclone's default (~/.config/rclone/rclone.conf)
RCLONE_BIN_DEFAULT=""             # Empty = search PATH
BASE_PATH_DEFAULT="."             # Root that group local_paths are relative to

RCLONE_OPTS_DEFAULT=(
  "--contimeout=60s"
  "--timeout=300s"
  "--retries=5"
  "--low-level-retries=10"
)

TRANSFERS_DEFAULT=4
CHECKERS_DEFAULT=8
MAX_RETRIES_DEFAULT=5
RETRY_SLEEP_DEFAULT=30

# =============================================================================
# RUNTIME GLOBALS  (populated from CLI / groups file)
# =============================================================================
GROUPS_FILE=""
BASE_PATH="$BASE_PATH_DEFAULT"
RCLONE_CONFIG="$RCLONE_CONFIG_DEFAULT"
RCLONE_BIN="$RCLONE_BIN_DEFAULT"
RCLONE_OPTS=("${RCLONE_OPTS_DEFAULT[@]}")
TRANSFERS="$TRANSFERS_DEFAULT"
CHECKERS="$CHECKERS_DEFAULT"
MAX_RETRIES="$MAX_RETRIES_DEFAULT"
RETRY_SLEEP="$RETRY_SLEEP_DEFAULT"
VERIFY=1
DEEP_VERIFY=0
DRY_RUN=0
FORCE_ALL=0
FORCE_LABEL=""
LOG_DIR=""
GROUP_TABLE=""

# =============================================================================
# COLORS  (auto-disabled when stdout is not a TTY)
# =============================================================================
if [[ -t 1 ]]; then
  C_RESET='\033[0m' C_GREEN='\033[32m' C_YELLOW='\033[33m' C_RED='\033[31m' C_BLUE='\033[34m' C_BOLD='\033[1m'
else
  C_RESET='' C_GREEN='' C_YELLOW='' C_RED='' C_BLUE='' C_BOLD=''
fi

# =============================================================================
# HELPERS
# =============================================================================

# Returns 0 (true) if a line is blank or a comment
is_comment() { [[ -z "${1// }" || "${1// }" =~ ^# ]]; }

ts()         { date +'%F %T'; }
log_raw()    { echo -e "[$(ts)] $*" | tee -a "$MASTER_LOG"; }
log_exec()   { echo -e "[$(ts)] $*" >> "$MASTER_LOG"; }
log()        { log_raw "$*"; }
log_green()  { log_raw "${C_GREEN}$*${C_RESET}"; }
log_yellow() { log_raw "${C_YELLOW}$*${C_RESET}"; }
log_red()    { log_raw "${C_RED}$*${C_RESET}"; }
log_blue()   { log_raw "${C_BLUE}$*${C_RESET}"; }
log_bold()   { log_raw "${C_BOLD}$*${C_RESET}"; }

die() { echo -e "${C_RED}FATAL: $*${C_RESET}" >&2; exit 1; }

# =============================================================================
# USAGE
# =============================================================================
usage() {
  cat <<USAGE

${C_BOLD}rclone-uploader.sh${C_RESET} v${FRAMEWORK_VERSION} — Universal Rclone Upload Framework

${C_BOLD}USAGE${C_RESET}
  $0 --groups <jobs.conf> [options]

${C_BOLD}REQUIRED${C_RESET}
  --groups FILE          Path to your job definitions file.
                         See config/jobs.example.conf for format.

${C_BOLD}PATH OPTIONS${C_RESET}
  --base PATH            Root directory that local paths in jobs.conf are
                         relative to. Default: current directory (".")
  --config FILE          rclone config file. Default: rclone's own default
  --rclone-bin PATH      Path to rclone binary. Default: searches \$PATH
  --log-dir PATH         Directory for logs. Default: <base>/.rclone_logs

${C_BOLD}TRANSFER OPTIONS${C_RESET}
  --transfers N          Parallel file transfers. Default: $TRANSFERS_DEFAULT
  --checkers N           Parallel metadata checkers. Default: $CHECKERS_DEFAULT
  --max-retries N        Max upload+verify attempts per job. Default: $MAX_RETRIES_DEFAULT
  --retry-sleep SEC      Seconds between retry attempts. Default: $RETRY_SLEEP_DEFAULT

${C_BOLD}VERIFICATION${C_RESET}
  --no-verify            Skip post-upload integrity check (faster, less safe).
  --deep-verify          Use checksums instead of file-size comparison
                         (slower, but catches bit-level corruption).

${C_BOLD}RUN CONTROL${C_RESET}
  --dry-run              Simulate everything; no files are transferred.
  --force-all            Ignore saved state; reprocess all jobs.
  --force LABEL          Ignore saved state for one specific job label only.
  --list-jobs            Print all job labels from the groups file and exit.

${C_BOLD}OTHER${C_RESET}
  -h|--help              Show this help message.
  --version              Print framework version and exit.

${C_BOLD}EXAMPLES${C_RESET}
  # First run — upload everything
  $0 --groups config/my-jobs.conf

  # Resume after interruption (automatically skips completed jobs)
  $0 --groups config/my-jobs.conf

  # Simulate a run without transferring anything
  $0 --groups config/my-jobs.conf --dry-run

  # Re-run one specific failed job with checksum verification
  $0 --groups config/my-jobs.conf --force photos-2024 --deep-verify

  # Override base path and use more parallel transfers
  $0 --groups config/my-jobs.conf --base /mnt/nas --transfers 8

USAGE
}

# =============================================================================
# PARSE CLI
# =============================================================================
parse_cli() {
  [[ $# -eq 0 ]] && { usage; exit 0; }

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --groups)       GROUPS_FILE="$2";    shift 2 ;;
      --base)         BASE_PATH="$2";      shift 2 ;;
      --config)       RCLONE_CONFIG="$2";  shift 2 ;;
      --rclone-bin)   RCLONE_BIN="$2";     shift 2 ;;
      --log-dir)      LOG_DIR="$2";        shift 2 ;;
      --transfers)    TRANSFERS="$2";      shift 2 ;;
      --checkers)     CHECKERS="$2";       shift 2 ;;
      --max-retries)  MAX_RETRIES="$2";    shift 2 ;;
      --retry-sleep)  RETRY_SLEEP="$2";    shift 2 ;;
      --no-verify)    VERIFY=0;            shift ;;
      --deep-verify)  DEEP_VERIFY=1;       shift ;;
      --dry-run)      DRY_RUN=1;           shift ;;
      --force-all)    FORCE_ALL=1;         shift ;;
      --force)        FORCE_LABEL="$2";    shift 2 ;;
      --list-jobs)
        [[ -z "$GROUPS_FILE" ]] && die "--groups FILE must be specified before --list-jobs"
        load_groups_file
        while IFS= read -r line; do
          is_comment "$line" && continue
          echo "$line" | cut -d'|' -f1
        done <<<"$GROUP_TABLE"
        exit 0 ;;
      --version)      echo "rclone-uploader.sh v${FRAMEWORK_VERSION}"; exit 0 ;;
      -h|--help)      usage; exit 0 ;;
      *) echo "Unknown option: $1" >&2; usage; exit 1 ;;
    esac
  done
}

# =============================================================================
# LOAD GROUPS FILE
# Reads a .conf file and extracts:
#   - Key=value settings (override defaults)
#   - Job table lines (label|local_path|remote_path)
# =============================================================================
load_groups_file() {
  [[ -z "$GROUPS_FILE" ]]    && die "No --groups file specified. Run with --help for usage."
  [[ ! -f "$GROUPS_FILE" ]]  && die "Groups file not found: $GROUPS_FILE"

  GROUP_TABLE=""
  local in_jobs_section=0

  while IFS= read -r line || [[ -n "$line" ]]; do
    # Strip inline comments and trim
    local clean="${line%%#*}"
    clean="${clean#"${clean%%[![:space:]]*}"}"  # ltrim
    clean="${clean%"${clean##*[![:space:]]}"}"  # rtrim

    [[ -z "$clean" ]] && continue

    # Section header
    if [[ "$clean" == "[jobs]" ]]; then
      in_jobs_section=1
      continue
    fi
    if [[ "$clean" =~ ^\[.*\]$ ]]; then
      in_jobs_section=0
      continue
    fi

    if (( in_jobs_section == 0 )); then
      # Key=value settings — override defaults
      if [[ "$clean" =~ ^([A-Z_]+)[[:space:]]*=[[:space:]]*(.*)$ ]]; then
        local key="${BASH_REMATCH[1]}" val="${BASH_REMATCH[2]}"
        case "$key" in
          BASE_PATH)     BASE_PATH="$val" ;;
          RCLONE_CONFIG) RCLONE_CONFIG="$val" ;;
          RCLONE_BIN)    RCLONE_BIN="$val" ;;
          TRANSFERS)     TRANSFERS="$val" ;;
          CHECKERS)      CHECKERS="$val" ;;
          MAX_RETRIES)   MAX_RETRIES="$val" ;;
          RETRY_SLEEP)   RETRY_SLEEP="$val" ;;
          LOG_DIR)       LOG_DIR="$val" ;;
        esac
      fi
    else
      # Jobs table line — keep raw (including section comment lines starting with #)
      GROUP_TABLE+="${line}"$'\n'
    fi
  done < "$GROUPS_FILE"

  [[ -z "$GROUP_TABLE" ]] && die "No jobs found in [jobs] section of: $GROUPS_FILE"
}

# =============================================================================
# STATE MACHINE  (PENDING | RUNNING | OK | FAIL)
# Stored in: <log_dir>/state.tsv
# =============================================================================
declare -A STATE_STATUS
declare -A STATE_ATTEMPTS

init_state_file() {
  : >"$STATE_FILE"
  while IFS= read -r line; do
    is_comment "$line" && continue
    local label; label=$(echo "$line" | cut -d'|' -f1)
    [[ -z "$label" ]] && continue
    echo -e "${label}\tPENDING\t0" >>"$STATE_FILE"
    STATE_STATUS[$label]="PENDING"
    STATE_ATTEMPTS[$label]=0
  done <<<"$GROUP_TABLE"
}

load_state_file() {
  [[ ! -f "$STATE_FILE" ]] && { init_state_file; return; }
  while IFS=$'\t' read -r label status attempts _; do
    [[ -z "$label" ]] && continue
    local clean_attempts
    clean_attempts=$(echo "$attempts" | grep -o '^[0-9]\+' || echo "0")
    STATE_STATUS[$label]="$status"
    STATE_ATTEMPTS[$label]="${clean_attempts:-0}"
  done <"$STATE_FILE"
}

save_state_file() {
  local tmp="$STATE_FILE.new"
  : >"$tmp"
  while IFS= read -r line; do
    is_comment "$line" && continue
    local label; label=$(echo "$line" | cut -d'|' -f1)
    [[ -z "$label" ]] && continue
    echo -e "${label}\t${STATE_STATUS[$label]:-PENDING}\t${STATE_ATTEMPTS[$label]:-0}" >>"$tmp"
  done <<<"$GROUP_TABLE"
  mv "$tmp" "$STATE_FILE"
}

update_state() {
  STATE_STATUS[$1]="$2"
  STATE_ATTEMPTS[$1]="$3"
  save_state_file
}

# =============================================================================
# REMOTE FREE-SPACE CHECK  (best-effort; not all backends support it)
# =============================================================================
check_remote_space() {
  local remote="${1%%:*}:"
  log_blue "  ($remote) Checking free space..."
  local free
  free=$("$RCLONE_CMD" about "$remote" \
    ${RCLONE_CONFIG:+--config "$RCLONE_CONFIG"} 2>/dev/null \
    | awk '/Free:/{print $2$3}')
  if [[ -n "$free" ]]; then
    log_blue "  ($remote) Free: $free"
  else
    log_yellow "  ($remote) Free space unavailable (backend may not support it)."
  fi
}

# =============================================================================
# PROCESS ONE JOB  (upload + optional verify, with retry loop)
# =============================================================================
process_job() {
  local label="$1" local_rel="$2" remote_path="$3"
  local total_attempts=${STATE_ATTEMPTS[$label]:-0}

  # Filtering
  if (( FORCE_ALL == 0 )) && [[ -n "$FORCE_LABEL" ]] && [[ "$FORCE_LABEL" != "$label" ]]; then
    log_exec "  Skipping '$label' (--force targets '$FORCE_LABEL')."
    return 0
  fi
  if (( FORCE_ALL == 0 )) && [[ -z "$FORCE_LABEL" ]] && [[ "${STATE_STATUS[$label]}" == "OK" ]]; then
    log_exec "  Skipping '$label' (already OK). Use --force '$label' or --force-all to rerun."
    return 0
  fi

  local src="$BASE_PATH/$local_rel"
  if [[ ! -d "$src" ]]; then
    log_red "  [$label] Source not found: $src — marking FAIL."
    update_state "$label" FAIL "$total_attempts"
    return 1
  fi

  update_state "$label" RUNNING "$total_attempts"
  local job_log="$LOG_DIR/${label//[\/: ]/_}.log"
  : >"$job_log"

  # Build rclone flags
  local rclone_run_opts=("${RCLONE_OPTS[@]}")
  if (( DRY_RUN == 1 )); then
    rclone_run_opts+=(--dry-run)
  else
    rclone_run_opts+=(-P)   # Progress flag — omitted on dry-run (causes non-zero exit)
  fi
  [[ -n "$RCLONE_CONFIG" ]] && rclone_run_opts+=(--config "$RCLONE_CONFIG")

  local try=1
  while (( try <= MAX_RETRIES )); do
    total_attempts=$(( total_attempts + 1 ))
    log_blue "  [$label] Attempt $try/$MAX_RETRIES — $src → $remote_path"
    update_state "$label" RUNNING "$total_attempts"

    # ── Step 1: Upload ─────────────────────────────────────────────────────
    if "$RCLONE_CMD" copy "$src" "$remote_path" \
        --transfers="$TRANSFERS" --checkers="$CHECKERS" \
        --create-empty-src-dirs \
        "${rclone_run_opts[@]}" \
        --log-file="$job_log" --log-level INFO; then

      # ── Step 2: Verify ───────────────────────────────────────────────────
      if (( VERIFY == 1 )); then
        local verify_mode="size-only" check_opts=("--size-only")
        (( DEEP_VERIFY == 1 )) && { verify_mode="checksum"; check_opts=(); }
        log_blue "  [$label] Verifying ($verify_mode)..."

        if "$RCLONE_CMD" check "$src" "$remote_path" \
            --checkers="$CHECKERS" \
            "${rclone_run_opts[@]}" \
            "${check_opts[@]}" \
            --log-file="$job_log" --log-level INFO; then
          log_green "  [$label] ✓ DONE — uploaded and verified."
          update_state "$label" OK "$total_attempts"
          return 0
        else
          log_red "  [$label] ✗ Verification failed on attempt $try. Log: $job_log"
        fi
      else
        log_green "  [$label] ✓ DONE — uploaded (verification skipped)."
        update_state "$label" OK "$total_attempts"
        return 0
      fi

    else
      log_yellow "  [$label] Upload failed on attempt $try. Log: $job_log"
    fi

    (( try++ ))
    if (( try <= MAX_RETRIES )); then
      log_yellow "  [$label] Retrying in ${RETRY_SLEEP}s..."
      sleep "$RETRY_SLEEP"
    fi
  done

  log_red "  [$label] ✗ FAILED after $MAX_RETRIES attempts. Log: $job_log"
  update_state "$label" FAIL "$total_attempts"
  return 1
}

# =============================================================================
# MAIN
# =============================================================================
main() {
  parse_cli "$@"
  load_groups_file

  # CLI flags override conf-file values which override defaults
  # Set LOG_DIR now that BASE_PATH is resolved
  [[ -z "$LOG_DIR" ]] && LOG_DIR="$BASE_PATH/.rclone_logs"
  mkdir -p "$LOG_DIR"

  MASTER_LOG="$LOG_DIR/master.log"
  STATE_FILE="$LOG_DIR/state.tsv"
  LOCK_FILE="$LOG_DIR/.upload.lock"

  # Resolve rclone binary
  RCLONE_CMD=""
  if [[ -n "$RCLONE_BIN" && -x "$RCLONE_BIN" ]]; then
    RCLONE_CMD="$RCLONE_BIN"
  elif command -v rclone >/dev/null 2>&1; then
    RCLONE_CMD=$(command -v rclone)
  else
    die "rclone not found. Install it or pass --rclone-bin <path>."
  fi

  # Validate rclone config if explicitly set
  if [[ -n "$RCLONE_CONFIG" && ! -f "$RCLONE_CONFIG" ]]; then
    die "rclone config not found: $RCLONE_CONFIG"
  fi

  # Singleton lock
  exec 9>"$LOCK_FILE"
  flock -n 9 || die "Another instance is already running (lock: $LOCK_FILE)."

  # Cleanup trap
  trap 'rc=$?; (( rc != 0 )) && log_red "Exited with rc=$rc — state saved, safe to resume."; exit $rc' EXIT INT TERM

  # ── Banner ──────────────────────────────────────────────────────────────────
  log_bold "╔══════════════════════════════════════════════╗"
  log_bold "║     rclone-uploader.sh  v${FRAMEWORK_VERSION}              ║"
  log_bold "╚══════════════════════════════════════════════╝"
  log      "  Groups file : $GROUPS_FILE"
  log      "  Base path   : $BASE_PATH"
  log      "  rclone bin  : $RCLONE_CMD"
  log      "  Log dir     : $LOG_DIR"
  log      "  Transfers   : $TRANSFERS  |  Checkers: $CHECKERS"
  log      "  Max retries : $MAX_RETRIES  |  Retry sleep: ${RETRY_SLEEP}s"
  (( DRY_RUN     )) && log_yellow "  ⚠  DRY RUN — no files will be transferred."
  (( DEEP_VERIFY )) && log_yellow "  ⚠  DEEP VERIFY (checksum) active."
  (( FORCE_ALL   )) && log_yellow "  ⚠  FORCE ALL — ignoring saved state."
  [[ -n "$FORCE_LABEL" ]] && log_yellow "  ⚠  FORCE — reprocessing only: $FORCE_LABEL"
  log_bold "──────────────────────────────────────────────"

  load_state_file
  save_state_file   # Persist any newly added jobs

  # ── Process each job ────────────────────────────────────────────────────────
  while IFS= read -r line; do
    is_comment "$line" && continue
    IFS='|' read -r label local_rel remote_path <<<"$line"
    [[ -z "$label" || -z "$local_rel" || -z "$remote_path" ]] && {
      log_yellow "  Skipping malformed line: $line"
      continue
    }
    log_bold "──────────────────────────────────────────────"
    log_blue "  JOB: $label"
    check_remote_space "$remote_path"
    process_job "$label" "$local_rel" "$remote_path" || true
  done <<<"$GROUP_TABLE"

  # ── Final Summary ────────────────────────────────────────────────────────────
  log_bold "╔══════════════════════════════════════════════╗"
  log_bold "║              FINAL SUMMARY                   ║"
  log_bold "╚══════════════════════════════════════════════╝"

  local fail_count=0 ok_count=0 total=0
  while IFS= read -r line; do
    is_comment "$line" && continue
    local label; label=$(echo "$line" | cut -d'|' -f1)
    [[ -z "$label" ]] && continue
    (( total++ ))
    local status="${STATE_STATUS[$label]:-UNKNOWN}"
    local attempts="${STATE_ATTEMPTS[$label]:-0}"
    case "$status" in
      OK)      log_green  "  ✓  $label  (attempts: $attempts)"; (( ok_count++ )) ;;
      FAIL)    log_red    "  ✗  $label  (attempts: $attempts)"; (( fail_count++ )) ;;
      RUNNING) log_yellow "  ~  $label  INCOMPLETE/STUCK (attempts: $attempts)"; (( fail_count++ )) ;;
      *)       log_yellow "  ?  $label  $status (attempts: $attempts)" ;;
    esac
  done <<<"$GROUP_TABLE"

  log_bold "──────────────────────────────────────────────"
  log      "  Total: $total  |  OK: $ok_count  |  Failed: $fail_count"

  local fail_file="$LOG_DIR/failed_jobs.txt"
  if (( fail_count > 0 )); then
    log_red "  $fail_count job(s) failed. See: $fail_file"
    : >"$fail_file"
    while IFS= read -r line; do
      is_comment "$line" && continue
      IFS='|' read -r label local_rel remote_path <<<"$line"
      [[ -z "$label" ]] && continue
      local status="${STATE_STATUS[$label]:-}"
      [[ "$status" == "FAIL" || "$status" == "RUNNING" ]] && \
        echo "$label|$BASE_PATH/$local_rel|$remote_path" >>"$fail_file"
    done <<<"$GROUP_TABLE"
    exit 2   # Exit code 2 = partial failure (useful for CI/CD pipelines)
  else
    log_green "  All $ok_count job(s) completed successfully. 🎉"
    [[ -f "$fail_file" ]] && rm "$fail_file"
    exit 0
  fi
}

main "$@"
