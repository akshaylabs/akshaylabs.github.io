# Copyright (C) @TheSmartBisnu
# Channel: https://t.me/itsSmartDev
#
# Single-file webhook bot — zero local module imports.
# HuggingFace Spaces Docker:  uvicorn main:app --host 0.0.0.0 --port 7860
#
# DEPLOYMENT NOTE:
#   HF Spaces blocks api.telegram.org (Bot API HTTP).
#   This bot uses Pyrogram over MTProto (raw TCP) — NOT blocked.
#
# ARCHITECTURE:
#   /bdl — Parallel pipeline with ordered delivery:
#     Phase 1: bulk-fetch message metadata (chunked get_messages)
#     Phase 2: N parallel download workers (asyncio.Semaphore pool)
#     Phase 3: ordered sender (ready_queue + send_pointer, send-as-ready)
#     Phase 4: /retry command re-attempts failed/abandoned slots,
#              editing their placeholder messages in-place
#
#   Features:
#     - Forward EVERYTHING: media, text, polls, stickers, forwards
#     - Preserve reply chains: source reply→msg mapping to our group
#     - Partial file fallback: send whatever bytes we got with warning caption
#     - Abandoned placeholder: text message keeping sequence on total failure
#     - /retry: re-run failed slots and edit placeholders with results
#     - /killall: hard-cancels ALL worker tasks for that batch immediately
#     - Live status board: edits loading_msg every STATE_LOG_INTERVAL seconds
#     - Status message always at bottom: deleted+resent after each file send
#     - Upload progress bar: ephemeral message showing upload %, then deleted
#     - No reply-to spam: downloaded files are standalone, only status replies

import os
import sys
import json
import shutil
import psutil
import asyncio
import logging
import traceback
from time import time
from typing import Optional, Dict, List, Any, Tuple
from contextlib import asynccontextmanager
from logging.handlers import RotatingFileHandler
from dataclasses import dataclass
from enum import Enum

from dotenv import load_dotenv
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from pyrogram import Client
from pyrogram.enums import ParseMode
from pyrogram.errors import PeerIdInvalid, BadRequest, FloodWait
from pyrogram.errors.exceptions.flood_420 import FloodPremiumWait
from pyrogram.parser import Parser
from pyrogram.utils import get_channel_id
from pyrogram.types import (
    InputMediaPhoto, InputMediaVideo,      
    InputMediaAudio, InputMediaDocument,   
    InlineKeyboardMarkup, InlineKeyboardButton,
)
from pyleaves import Leaves

# ════════════════════════════════════════════════════════
# LOGGING
# ════════════════════════════════════════════════════════
try:
    os.remove("logs.txt")
except Exception:
    pass

logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s - %(levelname)s] - %(funcName)s() - Line %(lineno)d: %(name)s - %(message)s",
    datefmt="%d-%b-%y %I:%M:%S %p",
    handlers=[
        RotatingFileHandler("logs.txt", mode="w+", maxBytes=5_000_000, backupCount=10),
        logging.StreamHandler(),
    ],
)
logging.getLogger("pyrogram").setLevel(logging.ERROR)

def LOGGER(name: str) -> logging.Logger:
    return logging.getLogger(name)

# ════════════════════════════════════════════════════════
# CONFIG
# ════════════════════════════════════════════════════════
try:
    load_dotenv("config.env.local")
    load_dotenv("config.env")
except Exception:
    pass

_missing = [v for v in ("BOT_TOKEN", "SESSION_STRING", "API_ID", "API_HASH")
            if not os.getenv(v)]
if _missing:
    print(f"ERROR: Missing required env vars: {', '.join(_missing)}")
    sys.exit(1)

class PyroConf:
    API_ID   = int(os.getenv("API_ID", "6"))
    API_HASH = os.getenv("API_HASH", "eb06d4abfb49dc3eeb1aeb98ae0f581e")
    BOT_TOKEN      = os.getenv("BOT_TOKEN")
    SESSION_STRING = os.getenv("SESSION_STRING")
    BOT_START_TIME = time()

    # Workers
    MAX_FETCH_WORKERS        = int(os.getenv("MAX_FETCH_WORKERS", "3"))
    MAX_CONCURRENT_DOWNLOADS = int(os.getenv("MAX_CONCURRENT_DOWNLOADS", "3"))
    # Parallel Telegram uploads (mirrors rclone --transfers=4 from upload_all.sh)
    # Downloads fill a pool; uploads drain it M at a time, ordered delivery preserved.
    MAX_UPLOAD_WORKERS       = int(os.getenv("MAX_UPLOAD_WORKERS", "2"))

    # Retry
    MAX_DOWNLOAD_RETRIES     = int(os.getenv("MAX_DOWNLOAD_RETRIES", "3"))
    RETRY_DELAY_SECONDS      = int(os.getenv("RETRY_DELAY_SECONDS", "5"))

    # Timeouts / limits
    CONSECUTIVE_ERROR_LIMIT  = int(os.getenv("CONSECUTIVE_ERROR_LIMIT", "5"))
    FLOOD_WAIT_DELAY         = int(os.getenv("FLOOD_WAIT_DELAY", "3"))
    FETCH_BATCH_SIZE         = int(os.getenv("FETCH_BATCH_SIZE", "20"))

    # Live UI update interval (seconds)
    STATE_LOG_INTERVAL       = float(os.getenv("STATE_LOG_INTERVAL", "5.0"))

    # Upload progress edit interval (seconds)
    UPLOAD_PROGRESS_INTERVAL = float(os.getenv("UPLOAD_PROGRESS_INTERVAL", "3.0"))

# ════════════════════════════════════════════════════════
# TASK STATUS
# ════════════════════════════════════════════════════════
class TaskStatus(str, Enum):
    PENDING      = "pending"
    FETCHING     = "fetching"
    DOWNLOADING  = "downloading"
    SENDING      = "sending"     # queued for upload (downloaded, waiting for upload slot)
    UPLOADING    = "uploading"   # actively uploading to Telegram
    COMPLETED    = "completed"
    FAILED       = "failed"
    PARTIAL      = "partial"    # sent with warning — partial file
    ABANDONED    = "abandoned"  # placeholder message sent, retryable
    SKIPPED      = "skipped"

_STATUS_ICON = {
    TaskStatus.PENDING:     "⏳",
    TaskStatus.FETCHING:    "🔍",
    TaskStatus.DOWNLOADING: "⬇️",
    TaskStatus.SENDING:     "📦",   # queued, waiting for upload slot
    TaskStatus.UPLOADING:   "📤",   # actively uploading
    TaskStatus.COMPLETED:   "✅",
    TaskStatus.FAILED:      "❌",
    TaskStatus.PARTIAL:     "⚠️",
    TaskStatus.ABANDONED:   "🔲",
    TaskStatus.SKIPPED:     "⏭️",
}

# Callback data for the inline Refresh button on the status message
REFRESH_CB    = "batch_refresh"
# Callback data for /settings toggles
SETTING_CB_PREFIX = "setting:"   # setting:<key>:<value>

# ════════════════════════════════════════════════════════
# USER SETTINGS
# Per-chat preferences stored in memory.
# Persists for the lifetime of the process (resets on redeploy).
# ════════════════════════════════════════════════════════
_SETTING_DEFAULTS: Dict[str, Any] = {
    "status_always_bottom": True,   # delete+resend status after each file
}

_user_settings: Dict[int, Dict[str, Any]] = {}  # chat_id → {key: value}

def get_setting(chat_id: int, key: str) -> Any:
    return _user_settings.get(chat_id, {}).get(key, _SETTING_DEFAULTS.get(key))

def set_setting(chat_id: int, key: str, value: Any) -> None:
    if chat_id not in _user_settings:
        _user_settings[chat_id] = dict(_SETTING_DEFAULTS)
    _user_settings[chat_id][key] = value

# ── Settings menu helpers ────────────────────────────────
_SETTING_LABELS = {
    "status_always_bottom": "📌 Status bar always at bottom",
}

def _settings_keyboard(chat_id: int) -> InlineKeyboardMarkup:
    """
    Build an inline keyboard showing every setting as a toggle button.
    Each button label reflects the CURRENT state and the callback toggles it.
    Returns a Pyrogram InlineKeyboardMarkup so edit_message_text can use it directly.
    """
    rows = []
    for key, label in _SETTING_LABELS.items():
        val  = get_setting(chat_id, key)
        # Button shows current state; tapping sends the toggled value
        icon = "✅ On" if val else "❌ Off"
        cb   = f"{SETTING_CB_PREFIX}{key}:{int(not val)}"
        rows.append([InlineKeyboardButton(f"{icon}  {label}", callback_data=cb)])
    rows.append([InlineKeyboardButton("✖ Close", callback_data="settings_close")])
    return InlineKeyboardMarkup(rows)

def _settings_keyboard_dict(chat_id: int) -> dict:
    """Same as _settings_keyboard but as a raw dict for webhook JSON responses."""
    rows = []
    for key, label in _SETTING_LABELS.items():
        val  = get_setting(chat_id, key)
        icon = "✅ On" if val else "❌ Off"
        cb   = f"{SETTING_CB_PREFIX}{key}:{int(not val)}"
        rows.append([{"text": f"{icon}  {label}", "callback_data": cb}])
    rows.append([{"text": "✖ Close", "callback_data": "settings_close"}])
    return {"inline_keyboard": rows}

def _settings_text(chat_id: int) -> str:
    header = "\u2699\ufe0f **Bot Settings**\n\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\nTap a setting to toggle it.\n"
    lines = [header]
    for key, label in _SETTING_LABELS.items():
        val  = get_setting(chat_id, key)
        icon = "\u2705 On" if val else "\u274c Off"
        lines.append(f"{label}: **{icon}**")
    return "\n".join(lines)

# ════════════════════════════════════════════════════════
# UX HELPERS
# ════════════════════════════════════════════════════════
def fmt_size(b: float) -> str:
    for u in ["B", "KB", "MB", "GB"]:
        if b < 1024:
            return f"{b:.1f} {u}"
        b /= 1024
    return f"{b:.1f} TB"

def fmt_time(seconds: float) -> str:
    if seconds <= 0 or seconds != seconds:
        return "—"
    seconds = int(seconds)
    if seconds < 60:
        return f"{seconds}s"
    m, s = divmod(seconds, 60)
    if m < 60:
        return f"{m}m {s}s"
    h, m = divmod(m, 60)
    return f"{h}h {m}m"

def progress_bar(current: int, total: int, length: int = 10) -> str:
    if not total or total <= 0 or current <= 0:
        return "░" * length
    pct    = min(1.0, current / total)
    filled = int(length * pct)
    return "▓" * filled + "░" * (length - filled)

def short_name(filename: str, maxlen: int = 35) -> str:
    return filename if len(filename) <= maxlen else filename[:maxlen - 3] + "..."

def build_progress_text(phase: str, current: int, total: int,
                        speed: float, elapsed: float,
                        filename: str, attempt: int = 1,
                        max_retries: int = 1) -> str:
    pct       = min(100, int(current * 100 / total)) if total > 0 else 0
    bar       = progress_bar(current, total)
    total_str = fmt_size(total) if total > 0 else "?"
    eta       = fmt_time((total - current) / speed) if (
        total > 0 and speed > 0 and current < total) else "—"
    icon      = "📥" if phase == "download" else "📤"
    label     = "Downloading" if phase == "download" else "Uploading"
    retry_str = f"  _(retry {attempt}/{max_retries})_" if attempt > 1 else ""
    return (
        f"{icon} **{label}:**{retry_str} `{filename}`\n\n"
        f"`{bar}` **{pct}%**\n\n"
        f"**Done:** `{fmt_size(current)}` / `{total_str}`\n"
        f"**Speed:** `{fmt_size(speed)}/s`\n"
        f"**ETA:** `{eta}`\n"
        f"**Elapsed:** `{fmt_time(elapsed)}`"
    )

def get_readable_time(seconds: int) -> str:
    result = ""
    days, rem = divmod(seconds, 86400)
    if int(days):   result += f"{int(days)}d"
    hrs,  rem = divmod(rem, 3600)
    if int(hrs):    result += f"{int(hrs)}h"
    mins, sec = divmod(rem, 60)
    if int(mins):   result += f"{int(mins)}m"
    result += f"{int(sec)}s"
    return result

# ════════════════════════════════════════════════════════
# BATCH STATE — per slot
# ════════════════════════════════════════════════════════
@dataclass
class TaskState:
    index:            int
    url:              str
    status:           TaskStatus  = TaskStatus.PENDING
    filename:         str         = ""
    file_size:        int         = 0
    bytes_done:       int         = 0
    error:            str         = ""
    retry_count:      int         = 0
    # message_id of placeholder/partial sent in group — used by /retry
    placeholder_msg_id: Optional[int] = None
    # message_id of the successfully sent final message in group
    sent_msg_id:      Optional[int]   = None

# ════════════════════════════════════════════════════════
# BATCH STATE MANAGER — live Telegram UI
# ════════════════════════════════════════════════════════
class BatchStateManager:
    def __init__(self, total: int, chat_id: int, reply_to_id: int,
                 status_message=None, batch_start: float = None,
                 refresh_event: asyncio.Event = None):
        self.total          = total
        self.chat_id        = chat_id
        self.reply_to_id    = reply_to_id
        self.status_message = status_message
        self.batch_start    = batch_start or time()
        self.refresh_event  = refresh_event   # set by /refresh to force instant redraw
        self.state_map:     Dict[int, TaskState] = {}
        self.update_queue:  asyncio.Queue        = asyncio.Queue()
        self._stop_event:   asyncio.Event        = asyncio.Event()
        self._task:         Optional[asyncio.Task] = None
        self._last_ui:      float                = time()  # wait full interval before first edit

    def register_slots(self, indices: List[int], urls: List[str]):
        for i, url in zip(indices, urls):
            self.state_map[i] = TaskState(index=i, url=url)

    async def put(self, index: int, **kwargs):
        await self.update_queue.put({"index": index, **kwargs})

    def start(self):
        self._task = asyncio.create_task(self._run(), name="BatchStateManager")
        return self._task

    async def stop(self):
        self._stop_event.set()
        if self._task:
            try:
                await asyncio.wait_for(self._task, timeout=30.0)
            except asyncio.TimeoutError:
                LOGGER(__name__).error("BatchStateManager stop timed out")
                self._task.cancel()

    def _refresh_markup(self) -> InlineKeyboardMarkup:
        return InlineKeyboardMarkup([[
            InlineKeyboardButton("🔄 Refresh", callback_data=REFRESH_CB)
        ]])

    async def move_status_to_bottom(self):
        """
        After each file send, either delete+resend the status message so
        it stays at the bottom (status_always_bottom=True), or just
        edit it in-place (status_always_bottom=False).
        Controlled per-user via /settings.
        """
        if not self.status_message:
            return
        text = self._build_ui_text()
        if get_setting(self.chat_id, "status_always_bottom"):
            # Delete + resend → always the newest/bottommost message
            try:
                await self.status_message.delete()
            except Exception:
                pass
            try:
                self.status_message = await bot.send_message(
                    self.chat_id, text,
                    reply_markup=self._refresh_markup())
                self._last_ui = time()
            except Exception as e:
                LOGGER(__name__).debug(f"move_status_to_bottom (resend) failed: {e}")
        else:
            # Edit in-place → stays where it was, no new message
            try:
                await bot.edit_message_text(
                    chat_id=self.chat_id,
                    message_id=self.status_message.id,
                    text=text,
                    reply_markup=self._refresh_markup())
                self._last_ui = time()
            except Exception as e:
                LOGGER(__name__).debug(f"move_status_to_bottom (edit) failed: {e}")

    async def _run(self):
        LOGGER(__name__).info("BatchStateManager started.")
        while not self._stop_event.is_set():
            # ── 1. Check time FIRST — update UI if interval elapsed ─────
            # /refresh: force immediate redraw
            if self.refresh_event and self.refresh_event.is_set():
                self.refresh_event.clear()
                self._last_ui = 0.0
            if time() - self._last_ui >= PyroConf.STATE_LOG_INTERVAL:
                await self._update_live_ui()

            # ── 2. Wait for next state update (up to STATE_LOG_INTERVAL) ─
            # Wakes immediately when a worker pushes an update.
            # Times out after STATE_LOG_INTERVAL so the UI check above
            # fires reliably even when the queue is busy.
            try:
                update = await asyncio.wait_for(
                    self.update_queue.get(),
                    timeout=PyroConf.STATE_LOG_INTERVAL)
                self._apply(update)
                self.update_queue.task_done()
                # Drain any burst that arrived while we were awaiting
                while True:
                    try:
                        u2 = self.update_queue.get_nowait()
                        self._apply(u2)
                        self.update_queue.task_done()
                    except asyncio.QueueEmpty:
                        break
            except asyncio.TimeoutError:
                pass   # interval elapsed — loop back, UI check fires next

        await self._flush()
        await self._update_live_ui()
        LOGGER(__name__).info("BatchStateManager finished.")

    def _apply(self, update: dict):
        idx = update.pop("index", None)
        if idx is not None and idx in self.state_map:
            s = self.state_map[idx]
            for k, v in update.items():
                if hasattr(s, k):
                    setattr(s, k, v)

    async def _flush(self):
        while not self.update_queue.empty():
            try:
                update = self.update_queue.get_nowait()
                self._apply(update)
                self.update_queue.task_done()
            except asyncio.QueueEmpty:
                break

    def _counts(self) -> Dict[TaskStatus, int]:
        counts = {s: 0 for s in TaskStatus}
        for ts in self.state_map.values():
            counts[ts.status] += 1
        return counts

    def _build_ui_text(self) -> str:
        counts  = self._counts()
        elapsed = time() - self.batch_start
        done    = sum(counts[s] for s in (
            TaskStatus.COMPLETED, TaskStatus.FAILED,
            TaskStatus.PARTIAL, TaskStatus.ABANDONED, TaskStatus.SKIPPED))
        bar     = progress_bar(done, self.total, length=10)
        pct     = int(done * 100 / self.total) if self.total else 0

        header = (
            f"⚡ **Batch Download** — `{self.total}` posts\n"
            f"`{bar}` {pct}%  •  "
            f"✅`{counts[TaskStatus.COMPLETED]}` "
            f"⚠️`{counts[TaskStatus.PARTIAL]}` "
            f"🔲`{counts[TaskStatus.ABANDONED]}` "
            f"❌`{counts[TaskStatus.FAILED]}` "
            f"⏭️`{counts[TaskStatus.SKIPPED]}` "
            f"•  `{fmt_time(elapsed)}`\n"
            f"⬇️`{counts[TaskStatus.DOWNLOADING]}` dl  "
            f"📤`{counts[TaskStatus.UPLOADING]}` up  "
            f"📦`{counts[TaskStatus.SENDING]}` queued"
        )

        active_lines = []
        for ts in sorted(self.state_map.values(), key=lambda x: x.index):
            if ts.status not in (TaskStatus.DOWNLOADING, TaskStatus.UPLOADING,
                                 TaskStatus.SENDING, TaskStatus.FETCHING):
                continue
            icon  = _STATUS_ICON[ts.status]
            label = short_name(ts.filename or f"Post #{ts.index + 1}", 28)
            if ts.status == TaskStatus.DOWNLOADING:
                if ts.file_size > 0 and ts.bytes_done > 0:
                    pbar = progress_bar(ts.bytes_done, ts.file_size, length=6)
                    active_lines.append(
                        f"{icon} `{pbar}` `{label}`\n"
                        f"    `{fmt_size(ts.bytes_done)}` / `{fmt_size(ts.file_size)}`")
                elif ts.file_size > 0:
                    active_lines.append(
                        f"{icon} `{label}` — `{fmt_size(ts.file_size)}`")
                else:
                    active_lines.append(f"{icon} `{label}`")
            elif ts.status == TaskStatus.UPLOADING:
                size_str = f"`{fmt_size(ts.file_size)}`" if ts.file_size else ""
                active_lines.append(f"📤 `{label}` {size_str} — _uploading…_")
            elif ts.status == TaskStatus.SENDING:
                active_lines.append(f"📦 `{label}` — _queued for upload_")
            else:
                active_lines.append(f"{icon} `{label}`")

        recent_lines = []
        recent = [
            ts for ts in sorted(self.state_map.values(),
                                 key=lambda x: x.index, reverse=True)
            if ts.status in (TaskStatus.COMPLETED, TaskStatus.FAILED,
                             TaskStatus.PARTIAL, TaskStatus.ABANDONED)
        ][:4]
        for ts in reversed(recent):
            icon  = _STATUS_ICON[ts.status]
            label = short_name(ts.filename or f"Post #{ts.index + 1}", 28)
            if ts.status == TaskStatus.COMPLETED:
                sz = f"`{fmt_size(ts.file_size)}`" if ts.file_size else ""
                recent_lines.append(f"{icon} `{label}` {sz}")
            elif ts.status == TaskStatus.PARTIAL:
                recent_lines.append(f"{icon} `{label}` — _partial, sent with warning_")
            elif ts.status == TaskStatus.ABANDONED:
                recent_lines.append(f"{icon} `{label}` — _placeholder sent, use /retry_")
            else:
                err = short_name(ts.error or "error", 35)
                recent_lines.append(f"{icon} `{label}` — _{err}_")

        parts = [header]
        if active_lines:
            parts.append("\n**Active:**\n" + "\n".join(active_lines))
        if recent_lines:
            parts.append("\n**Recent:**\n" + "\n".join(recent_lines))
        pending = counts[TaskStatus.PENDING]
        if pending > 0:
            parts.append(f"\n_⏳ {pending} post(s) queued…_")
        parts.append("\n_/skip — skip current  •  /killall — stop all  •  /refresh — refresh now_")
        return "\n".join(parts)

    async def _update_live_ui(self):
        self._last_ui = time()
        counts = self._counts()
        LOGGER(__name__).info(
            f"[Batch] {self.total} total | "
            f"✅{counts[TaskStatus.COMPLETED]} "
            f"⬇️{counts[TaskStatus.DOWNLOADING]} "
            f"📤{counts[TaskStatus.SENDING]} "
            f"⚠️{counts[TaskStatus.PARTIAL]} "
            f"🔲{counts[TaskStatus.ABANDONED]} "
            f"❌{counts[TaskStatus.FAILED]} "
            f"⏭️{counts[TaskStatus.SKIPPED]}")
        if not self.status_message:
            return
        try:
            await bot.edit_message_text(
                chat_id=self.chat_id,
                message_id=self.status_message.id,
                text=self._build_ui_text(),
                reply_markup=self._refresh_markup())
        except Exception as e:
            LOGGER(__name__).debug(f"Live UI edit skipped: {e}")

    def summary(self) -> dict:
        counts = {s: 0 for s in TaskStatus}
        for ts in self.state_map.values():
            counts[ts.status] += 1
        return counts

    def get_retryable(self) -> List[TaskState]:
        """Return slots that can be retried (failed or abandoned)."""
        return [
            ts for ts in self.state_map.values()
            if ts.status in (TaskStatus.FAILED, TaskStatus.ABANDONED,
                             TaskStatus.PARTIAL)
        ]

# ════════════════════════════════════════════════════════
# PER-BATCH REGISTRY — stores state managers by (chat_id, batch_key)
# Used by /retry to find the last batch's state
# ════════════════════════════════════════════════════════
_batch_registry: Dict[int, "BatchStateManager"] = {}  # chat_id → last BatchStateManager
_batch_worker_tasks: Dict[int, List[asyncio.Task]]   = {}  # chat_id → worker tasks

# ════════════════════════════════════════════════════════
# FILE HELPERS
# ════════════════════════════════════════════════════════
def get_download_path(folder_id: int, filename: str,
                      root_dir: str = "downloads") -> str:
    folder = os.path.join(root_dir, str(folder_id))
    os.makedirs(folder, exist_ok=True)
    return os.path.join(folder, filename)

def cleanup_download(path: str) -> None:
    try:
        if path and os.path.exists(path):
            os.remove(path)
        if path and os.path.exists(path + ".temp"):
            os.remove(path + ".temp")
        if path:
            folder = os.path.dirname(path)
            if os.path.isdir(folder) and not os.listdir(folder):
                os.rmdir(folder)
    except Exception as e:
        LOGGER(__name__).error(f"Cleanup failed for {path}: {e}")

def cleanup_downloads_root(root_dir: str = "downloads") -> tuple:
    if not os.path.isdir(root_dir):
        return 0, 0
    file_count = total_size = 0
    for dirpath, _, filenames in os.walk(root_dir):
        for name in filenames:
            file_count += 1
            try:
                total_size += os.path.getsize(os.path.join(dirpath, name))
            except OSError:
                pass
    shutil.rmtree(root_dir, ignore_errors=True)
    return file_count, total_size

async def fileSizeLimit(file_size, message, action_type="download",
                        is_premium=False):
    MAX_FILE_SIZE = 2 * 2_097_152_000 if is_premium else 2_097_152_000
    if file_size > MAX_FILE_SIZE:
        await message.reply(
            f"The file size exceeds the {fmt_size(MAX_FILE_SIZE)} "
            f"limit and cannot be {action_type}ed.")
        return False
    return True

# ════════════════════════════════════════════════════════
# MEDIA CHECKS
# ════════════════════════════════════════════════════════
def has_downloadable_media(msg) -> bool:
    return bool(
        msg.document or msg.video  or msg.audio     or msg.voice or
        msg.video_note or msg.animation or msg.sticker or msg.photo
    )

def has_any_content(msg) -> bool:
    """True for anything worth forwarding: media, text, polls, etc."""
    return bool(
        msg.text or msg.caption or msg.media or
        msg.poll or msg.location or msg.venue or
        msg.contact or msg.dice or msg.game
    )

# ════════════════════════════════════════════════════════
# LINK HELPERS
# ════════════════════════════════════════════════════════
async def get_parsed_msg(text, entities):
    return Parser.unparse(text, entities or [], is_html=False)

def getChatMsgID(link: str):
    linkps = link.split("/")
    chat_id = message_id = None
    try:
        if len(linkps) == 7 and linkps[3] == "c":
            chat_id    = get_channel_id(int(linkps[4]))
            message_id = int(linkps[6])
        elif len(linkps) == 6:
            if linkps[3] == "c":
                chat_id    = get_channel_id(int(linkps[4]))
                message_id = int(linkps[5])
            else:
                chat_id    = linkps[3]
                message_id = int(linkps[5])
        elif len(linkps) == 5:
            chat_id = linkps[3]
            if chat_id == "m":
                raise ValueError("Invalid ClientType")
            message_id = int(linkps[4])
    except (ValueError, TypeError):
        raise ValueError("Invalid post URL. Must end with a numeric ID.")
    if not chat_id or not message_id:
        raise ValueError("Please send a valid Telegram post URL.")
    return chat_id, message_id

def get_file_name(message_id: int, chat_message) -> str:
    if chat_message.document:
        return chat_message.document.file_name or f"{message_id}"
    elif chat_message.video:
        return chat_message.video.file_name or f"{message_id}.mp4"
    elif chat_message.audio:
        return chat_message.audio.file_name or f"{message_id}.mp3"
    elif chat_message.voice:
        return f"{message_id}.ogg"
    elif chat_message.video_note:
        return f"{message_id}.mp4"
    elif chat_message.animation:
        return chat_message.animation.file_name or f"{message_id}.gif"
    elif chat_message.sticker:
        if chat_message.sticker.is_animated: return f"{message_id}.tgs"
        elif chat_message.sticker.is_video:  return f"{message_id}.webm"
        else:                                return f"{message_id}.webp"
    elif chat_message.photo:
        return f"{message_id}.jpg"
    return f"{message_id}"

def get_expected_file_size(chat_message) -> Optional[int]:
    if chat_message.document:   return chat_message.document.file_size
    elif chat_message.video:    return chat_message.video.file_size
    elif chat_message.audio:    return chat_message.audio.file_size
    elif chat_message.voice:    return chat_message.voice.file_size
    elif chat_message.video_note: return chat_message.video_note.file_size
    elif chat_message.animation: return chat_message.animation.file_size
    elif chat_message.sticker:  return chat_message.sticker.file_size
    return None

# ════════════════════════════════════════════════════════
# ROBUST DOWNLOAD — retry, size validation, partial capture
# Returns (path, error, is_partial)
#   path       — file path if any bytes saved, else None
#   error      — error description if failed
#   is_partial — True if file exists but is truncated
# ════════════════════════════════════════════════════════
async def download_single_message(
    chat_message,
    download_path: str,
    progress_message=None,
    start_time: float = None,
    retries: int = None,
) -> Tuple[Optional[str], Optional[str], bool]:

    max_retries   = retries if retries is not None else PyroConf.MAX_DOWNLOAD_RETRIES
    expected_size = get_expected_file_size(chat_message)
    last_partial_path: Optional[str] = None   # best partial we've seen so far

    for attempt in range(1, max_retries + 1):
        media_path = None
        attempt_path = (download_path if attempt == 1
                        else f"{download_path}.retry{attempt}")
        try:
            kwargs: dict = {"file_name": attempt_path}
            if progress_message and start_time:
                if callable(progress_message):
                    kwargs["progress"] = progress_message
                else:
                    kwargs["progress"]      = Leaves.progress_for_pyrogram
                    kwargs["progress_args"] = ("📥 Downloading", progress_message, start_time)
            media_path = await chat_message.download(**kwargs)

        except FloodPremiumWait as e:
            wait_s = int(getattr(e, "value", 0) or 15)
            LOGGER(__name__).warning(f"FloodPremiumWait {wait_s}s (attempt {attempt}/{max_retries})")
            for p in (attempt_path, attempt_path + ".temp", media_path):
                if p and os.path.exists(p):
                    try: os.remove(p)
                    except Exception: pass
            if attempt < max_retries:
                await asyncio.sleep(wait_s + 2)
                continue
            break

        except FloodWait as e:
            wait_s = int(getattr(e, "value", 0) or 0)
            LOGGER(__name__).warning(f"FloodWait {wait_s}s (attempt {attempt}/{max_retries})")
            for p in (attempt_path, attempt_path + ".temp", media_path):
                if p and os.path.exists(p):
                    try: os.remove(p)
                    except Exception: pass
            if attempt < max_retries and wait_s > 0:
                await asyncio.sleep(wait_s + 1)
                continue
            break

        except OSError as e:
            LOGGER(__name__).warning(f"TCP error attempt {attempt}/{max_retries}: {e}")
            for p in (attempt_path, attempt_path + ".temp", media_path):
                if p and os.path.exists(p):
                    try: os.remove(p)
                    except Exception: pass
            if attempt < max_retries:
                await asyncio.sleep(PyroConf.RETRY_DELAY_SECONDS * attempt + 3)
                continue
            break

        except (TimeoutError, asyncio.TimeoutError) as e:
            LOGGER(__name__).warning(f"Timeout attempt {attempt}/{max_retries}")
            for p in (attempt_path, attempt_path + ".temp", media_path):
                if p and os.path.exists(p):
                    try: os.remove(p)
                    except Exception: pass
            if attempt < max_retries:
                await asyncio.sleep(PyroConf.RETRY_DELAY_SECONDS * attempt)
                continue
            break

        except Exception as e:
            err_str = str(e)
            # AUTH_BYTES_INVALID: Pyrogram's DC migration session has stale
            # auth bytes. Needs a longer sleep so the client can re-establish
            # authorization to the target DC before retrying.
            if "AUTH_BYTES_INVALID" in err_str:
                LOGGER(__name__).warning(
                    f"AUTH_BYTES_INVALID attempt {attempt}/{max_retries} — "
                    f"waiting for DC re-auth…")
                for p in (attempt_path, attempt_path + ".temp", media_path):
                    if p and os.path.exists(p):
                        try: os.remove(p)
                        except Exception: pass
                if attempt < max_retries:
                    await asyncio.sleep(15 * attempt)   # give Pyrogram time to reconnect
                    continue
                break
            LOGGER(__name__).error(f"Download error attempt {attempt}/{max_retries}: {e}")
            for p in (attempt_path, attempt_path + ".temp", media_path):
                if p and os.path.exists(p):
                    try: os.remove(p)
                    except Exception: pass
            if attempt < max_retries:
                await asyncio.sleep(PyroConf.RETRY_DELAY_SECONDS * attempt)
                continue
            break

        # ── Validate ──────────────────────────────────────
        if not media_path or not os.path.exists(media_path):
            if attempt < max_retries:
                await asyncio.sleep(PyroConf.RETRY_DELAY_SECONDS)
                continue
            break

        actual_size = os.path.getsize(media_path)

        if actual_size == 0:
            LOGGER(__name__).warning(f"0-byte file attempt {attempt}/{max_retries}: {media_path}")
            for p in (media_path, attempt_path + ".temp"):
                if p and os.path.exists(p):
                    try: os.remove(p)
                    except Exception: pass
            if attempt < max_retries:
                await asyncio.sleep(PyroConf.RETRY_DELAY_SECONDS * attempt)
                continue
            break

        if expected_size and actual_size < expected_size * 0.95:
            LOGGER(__name__).warning(
                f"Partial download attempt {attempt}/{max_retries}: "
                f"got {fmt_size(actual_size)} / expected {fmt_size(expected_size)}")
            # Keep this partial as our best candidate
            if last_partial_path and last_partial_path != media_path:
                try: os.remove(last_partial_path)
                except Exception: pass
            last_partial_path = media_path
            # Clean up .temp but NOT the file itself — we may send it as partial
            if os.path.exists(attempt_path + ".temp"):
                try: os.remove(attempt_path + ".temp")
                except Exception: pass
            if attempt < max_retries:
                await asyncio.sleep(PyroConf.RETRY_DELAY_SECONDS * attempt * 2)
                continue
            # All retries exhausted — return partial as last resort
            LOGGER(__name__).warning(
                f"Returning partial file after all retries: {last_partial_path}")
            return last_partial_path, (
                f"Partial: {fmt_size(actual_size)} / {fmt_size(expected_size)}"), True

        # ── Success ───────────────────────────────────────
        if attempt_path != download_path:
            try:
                if os.path.exists(download_path):
                    os.remove(download_path)
                os.rename(media_path, download_path)
                media_path = download_path
            except Exception as e:
                LOGGER(__name__).warning(f"Rename failed, using as-is: {e}")
        # Clean up any leftover partial from a previous attempt
        if last_partial_path and last_partial_path != media_path:
            try: os.remove(last_partial_path)
            except Exception: pass
        LOGGER(__name__).info(
            f"✅ Download OK: {fmt_size(actual_size)} "
            f"→ {os.path.basename(media_path)} (attempt {attempt})")
        return media_path, None, False

    # ── Total failure — return best partial if we have one ──
    if last_partial_path and os.path.exists(last_partial_path):
        actual = os.path.getsize(last_partial_path)
        LOGGER(__name__).warning(
            f"All retries exhausted — using partial: {fmt_size(actual)}")
        return last_partial_path, f"Partial: {fmt_size(actual)} / {fmt_size(expected_size or 0)}", True

    return None, "Download failed after all retries", False

# ════════════════════════════════════════════════════════
# SEND MEDIA WITH UPLOAD PROGRESS BAR
# Shows an ephemeral "📤 Uploading…" message with a live
# progress bar while the file uploads. When upload completes
# the progress message is deleted, leaving only the file.
# ════════════════════════════════════════════════════════
async def send_media_with_progress(
    bot_client,
    chat_id: int,
    media_path: str,
    media_type: str,
    caption: str,
    filename: str = "",
) -> Optional[Any]:
    """
    Send a file to Telegram with a live upload progress bar.
    Returns the sent message object, or None on failure.
    The upload progress message is sent standalone (no reply_to)
    so it doesn't pollute the reply chain, and is deleted after.
    """
    fname_short   = short_name(filename or os.path.basename(media_path), 35)
    file_size     = os.path.getsize(media_path) if os.path.exists(media_path) else 0
    upload_start  = time()
    last_edit     = [0.0]

    # Send ephemeral progress message
    try:
        prog_msg = await bot_client.send_message(
            chat_id,
            f"📤 **Uploading…** `{fname_short}`\n\n"
            f"`░░░░░░░░░░` 0%\n"
            f"**Size:** `{fmt_size(file_size)}`")
    except Exception:
        prog_msg = None

    async def _upload_progress(current: int, total: int):
        now = time()
        if now - last_edit[0] < PyroConf.UPLOAD_PROGRESS_INTERVAL:
            return
        last_edit[0] = now
        elapsed = now - upload_start
        speed   = current / elapsed if elapsed > 0 else 0
        actual_total = total if total and total > 0 else file_size
        try:
            if prog_msg:
                await prog_msg.edit(
                    build_progress_text(
                        "upload", current, actual_total,
                        speed, elapsed, fname_short))
        except Exception:
            pass

    send_map = {
        "photo":    bot_client.send_photo,
        "video":    bot_client.send_video,
        "audio":    bot_client.send_audio,
        "document": bot_client.send_document,
    }
    sender = send_map.get(media_type, bot_client.send_document)

    sent_msg = None
    for attempt in range(2):
        try:
            sent_msg = await sender(
                chat_id, media_path,
                caption=caption or "",
                progress=_upload_progress,
            )
            break
        except FloodWait as e:
            wait_s = int(getattr(e, "value", 0) or 0)
            if wait_s > 0 and attempt == 0:
                await asyncio.sleep(wait_s + 1)
                continue
            raise

    # Delete the progress message — the real file is now in chat
    if prog_msg:
        try:
            await prog_msg.delete()
        except Exception:
            pass

    return sent_msg

# ════════════════════════════════════════════════════════
# FORWARD ANY MESSAGE TYPE
# Handles: media, text, polls, stickers, forwards, etc.
# Preserves reply chains via src_to_dst_map.
# ════════════════════════════════════════════════════════
async def _send_with_flood_retry(send_fn, *args, retries: int = 3, **kwargs) -> Optional[Any]:
    """
    Call any bot send_* function with FloodWait retry.
    On FloodWait, sleeps the required duration and retries up to `retries` times.
    Returns the sent message or None on failure.
    """
    for attempt in range(1, retries + 1):
        try:
            return await send_fn(*args, **kwargs)
        except FloodWait as e:
            wait_s = int(getattr(e, "value", 0) or 0)
            LOGGER(__name__).warning(
                f"FloodWait {wait_s}s on {send_fn.__name__} "
                f"(attempt {attempt}/{retries})")
            if attempt < retries and wait_s > 0:
                await asyncio.sleep(wait_s + 1)
                continue
            LOGGER(__name__).error(
                f"{send_fn.__name__} FloodWait retries exhausted")
            return None
        except Exception as e:
            LOGGER(__name__).error(
                f"{send_fn.__name__} failed attempt {attempt}/{retries}: {e}")
            if attempt < retries:
                await asyncio.sleep(3 * attempt)
                continue
            return None
    return None


async def forward_message(
    src_msg,
    chat_id: int,
    caption_override: str = "",
    media_path: str = None,
    media_type: str = None,
    is_partial: bool = False,
    src_to_dst_map: Dict[int, int] = None,
    filename: str = "",
) -> Optional[Any]:
    """
    Forward a single message to chat_id.
    - If media_path provided: send that file (download path)
    - Else: forward text/polls/other content
    - Preserves reply chain: if src_msg.reply_to_message_id is in
      src_to_dst_map, use mapped dst message_id as reply_to
    - No reply_to_message_id to the /bdl command — files are standalone
    """
    # Resolve reply chain
    reply_to = None
    if src_to_dst_map and src_msg.reply_to_message_id:
        reply_to = src_to_dst_map.get(src_msg.reply_to_message_id)

    # Build caption
    caption = caption_override
    if not caption:
        try:
            caption = await get_parsed_msg(
                src_msg.caption or src_msg.text or "",
                src_msg.caption_entities or src_msg.entities)
        except Exception:
            caption = src_msg.caption or src_msg.text or ""

    if is_partial and media_path:
        # Prepend partial warning to caption
        actual = os.path.getsize(media_path) if os.path.exists(media_path) else 0
        expected = get_expected_file_size(src_msg) or 0
        warn = (
            f"⚠️ **Partial File** — download was cut short.\n"
            f"Got `{fmt_size(actual)}` / expected `{fmt_size(expected)}`\n"
            f"Use `/retry` to attempt a full re-download.\n"
            f"{'━' * 19}\n"
        )
        caption = warn + (caption or "")

    sent_msg = None

    if media_path and os.path.exists(media_path):
        sent_msg = await send_media_with_progress(
            bot, chat_id, media_path,
            media_type or "document",
            caption, filename or os.path.basename(media_path))

    elif src_msg.text or src_msg.caption:
        sent_msg = await _send_with_flood_retry(
            bot.send_message,
            chat_id, caption or "\u200b",
            reply_to_message_id=reply_to)

    elif src_msg.poll:
        poll = src_msg.poll
        opts = [o.text for o in poll.options]
        sent_msg = await _send_with_flood_retry(
            bot.send_poll,
            chat_id, poll.question, opts,
            is_anonymous=poll.is_anonymous,
            allows_multiple_answers=poll.allows_multiple_answers,
            reply_to_message_id=reply_to)

    elif src_msg.location:
        loc = src_msg.location
        sent_msg = await _send_with_flood_retry(
            bot.send_location,
            chat_id, loc.latitude, loc.longitude,
            reply_to_message_id=reply_to)

    elif src_msg.contact:
        c = src_msg.contact
        sent_msg = await _send_with_flood_retry(
            bot.send_contact,
            chat_id, c.phone_number, c.first_name,
            last_name=c.last_name,
            reply_to_message_id=reply_to)

    elif src_msg.dice:
        sent_msg = await _send_with_flood_retry(
            bot.send_dice,
            chat_id, emoji=src_msg.dice.emoji,
            reply_to_message_id=reply_to)

    else:
        # Fallback: Pyrogram forward
        try:
            fwd = await bot.forward_messages(
                chat_id, src_msg.chat.id, src_msg.id)
            sent_msg = fwd[0] if isinstance(fwd, list) else fwd
        except FloodWait as e:
            wait_s = int(getattr(e, "value", 0) or 0)
            LOGGER(__name__).warning(f"FloodWait {wait_s}s on forward_messages")
            await asyncio.sleep(wait_s + 1)
            try:
                fwd = await bot.forward_messages(
                    chat_id, src_msg.chat.id, src_msg.id)
                sent_msg = fwd[0] if isinstance(fwd, list) else fwd
            except Exception as e2:
                LOGGER(__name__).error(f"forward_messages retry failed: {e2}")
        except Exception as e:
            LOGGER(__name__).error(f"Generic forward failed: {e}")

    return sent_msg

# ════════════════════════════════════════════════════════
# PYROGRAM CLIENTS
# ════════════════════════════════════════════════════════
bot = Client(
    "media_bot",
    api_id=PyroConf.API_ID,
    api_hash=PyroConf.API_HASH,
    bot_token=PyroConf.BOT_TOKEN,
    workers=100,
    parse_mode=ParseMode.MARKDOWN,
    max_concurrent_transmissions=10,
    sleep_threshold=30,
)

user = Client(
    "user_session",
    api_id=PyroConf.API_ID,
    api_hash=PyroConf.API_HASH,
    session_string=PyroConf.SESSION_STRING,
    workers=100,
    max_concurrent_transmissions=10,
    sleep_threshold=30,
)

# ════════════════════════════════════════════════════════
# GLOBAL STATE
# ════════════════════════════════════════════════════════
RUNNING_TASKS: set = set()
download_semaphore: Optional[asyncio.Semaphore] = None
_skip_events: Dict[int, asyncio.Event] = {}
_kill_events: Dict[int, asyncio.Event] = {}   # hard kill per user

def get_skip_event(chat_id: int) -> asyncio.Event:
    if chat_id not in _skip_events:
        _skip_events[chat_id] = asyncio.Event()
    return _skip_events[chat_id]

def get_kill_event(chat_id: int) -> asyncio.Event:
    if chat_id not in _kill_events:
        _kill_events[chat_id] = asyncio.Event()
    return _kill_events[chat_id]

_refresh_events: Dict[int, asyncio.Event] = {}

def get_refresh_event(chat_id: int) -> asyncio.Event:
    if chat_id not in _refresh_events:
        _refresh_events[chat_id] = asyncio.Event()
    return _refresh_events[chat_id]

def track_task(coro):
    task = asyncio.create_task(coro)
    RUNNING_TASKS.add(task)
    task.add_done_callback(RUNNING_TASKS.discard)
    return task

# ════════════════════════════════════════════════════════
# WEBHOOK HELPERS
# ════════════════════════════════════════════════════════
def _msg(chat_id: int, text: str, parse_mode: str = "Markdown",
         reply_markup: dict = None,
         disable_web_page_preview: bool = False) -> dict:
    payload = {"method": "sendMessage", "chat_id": chat_id,
               "text": text, "parse_mode": parse_mode}
    if reply_markup:
        payload["reply_markup"] = reply_markup
    if disable_web_page_preview:
        payload["disable_web_page_preview"] = True
    return payload

def _update_channel_markup() -> dict:
    return {"inline_keyboard": [[
        {"text": "Update Channel", "url": "https://t.me/+kwQk31iUrwE3MTc1"}
    ]]}

# ════════════════════════════════════════════════════════
# COMMAND HANDLERS
# ════════════════════════════════════════════════════════
def handle_start(chat_id: int) -> dict:
    return _msg(chat_id,
        "👋 **Welcome to Media Downloader Bot!**\n\n"
        "I can copy entire channels — media, text, polls, stickers, everything.\n"
        "Just send me a link (paste it directly or use `/dl <link>`).\n\n"
        "ℹ️ Use `/help` to view all commands.\n"
        "🔒 Make sure the user client is part of the source chat.\n\n"
        "Ready? Send me a Telegram post link!",
        reply_markup=_update_channel_markup(),
        disable_web_page_preview=True)

def handle_help(chat_id: int) -> dict:
    return _msg(chat_id,
        "💡 **Media Downloader Bot Help**\n\n"
        "➤ **Single Post**\n"
        "   `/dl <post_URL>` or paste the link directly.\n\n"
        "➤ **Batch Copy**\n"
        "   `/bdl start_link end_link`\n"
        "   Copies ALL posts in range: media, text, polls, stickers.\n"
        "   Reply chains are preserved.\n"
        "   💡 `/bdl https://t.me/ch/100 https://t.me/ch/120`\n\n"
        "➤ `/retry`   – re-attempt failed/partial posts from last batch\n"
        "➤ `/settings` – configure bot preferences (e.g. status bar position)\n"
        "➤ `/skip`    – skip current stuck file in a batch\n"
        "➤ `/killall` – hard-stop everything immediately\n"
        "➤ `/refresh` – force-refresh the live status board instantly\n"
        "➤ `/logs`    – get the bot log file\n"
        "➤ `/cleanup` – delete leftover temp files\n"
        "➤ `/stats`   – system & bot statistics\n\n"
        "**Partial downloads:** if a file can't be fully downloaded, the bot\n"
        "sends whatever it got with a ⚠️ warning. Use `/retry` to fix it.",
        reply_markup=_update_channel_markup(),
        disable_web_page_preview=True)

def handle_stats(chat_id: int) -> dict:
    uptime     = get_readable_time(int(time() - PyroConf.BOT_START_TIME))
    total, used, free = shutil.disk_usage(".")
    net        = psutil.net_io_counters()
    cpu        = psutil.cpu_percent(interval=0.2)
    mem        = psutil.virtual_memory()
    proc       = psutil.Process(os.getpid())
    active     = len([t for t in RUNNING_TASKS if not t.done()])
    dl_files   = sum(len(files) for _, _, files in os.walk("downloads")) \
                 if os.path.isdir("downloads") else 0
    retryable  = 0
    if chat_id in _batch_registry:
        retryable = len(_batch_registry[chat_id].get_retryable())

    return _msg(chat_id,
        "📊 **Bot Statistics**\n"
        "━━━━━━━━━━━━━━━━━━━\n"
        f"🕐 **Uptime:**       `{uptime}`\n"
        f"⚙️ **Active Jobs:**  `{active}`\n"
        f"📁 **Temp Files:**   `{dl_files}`\n"
        f"🔁 **Retryable:**    `{retryable}` slot(s) from last batch\n"
        "━━━━━━━━━━━━━━━━━━━\n"
        f"💾 **Disk:**         `{fmt_size(used)}` / `{fmt_size(total)}` "
        f"(`{fmt_size(free)}` free)\n"
        f"🧠 **Memory:**       `{round(proc.memory_info()[0]/1024**2)} MiB` "
        f"/ `{round(mem.total/1024**2)} MiB`\n"
        f"⚡ **CPU:**          `{cpu}%`\n"
        f"🌐 **Network:**      ↑`{fmt_size(net.bytes_sent)}` "
        f"↓`{fmt_size(net.bytes_recv)}`\n"
        "━━━━━━━━━━━━━━━━━━━\n"
        f"👷 **Workers:**      fetch=`{PyroConf.MAX_FETCH_WORKERS}` "
        f"dl=`{PyroConf.MAX_CONCURRENT_DOWNLOADS}` "
        f"ul=`{PyroConf.MAX_UPLOAD_WORKERS}` "
        f"retries=`{PyroConf.MAX_DOWNLOAD_RETRIES}`")

def handle_killall(chat_id: int) -> dict:
    # Hard kill: set kill event + cancel all tasks for this user
    get_kill_event(chat_id).set()
    get_skip_event(chat_id).set()
    # Cancel all worker tasks for this batch
    killed = 0
    for t in list(_batch_worker_tasks.get(chat_id, [])):
        if not t.done():
            t.cancel()
            killed += 1
    # Also cancel all global running tasks (belt and suspenders)
    cancelled = sum(
        1 for t in list(RUNNING_TASKS)
        if not t.done() and t.cancel())
    return _msg(chat_id,
        f"🛑 **Hard Stop Executed**\n\n"
        f"Cancelled `{killed}` download worker(s) and `{cancelled}` task(s).\n"
        f"_Everything for your batch has been stopped immediately._")

def handle_skip(chat_id: int) -> dict:
    get_skip_event(chat_id).set()
    return _msg(chat_id,
        "⏭️ **Skip signal sent.**\n"
        "_Current download will be abandoned and the batch continues._")

def handle_cleanup(chat_id: int) -> dict:
    try:
        files_removed, bytes_freed = cleanup_downloads_root()
        if files_removed == 0:
            return _msg(chat_id, "🧹 **Cleanup complete** — no leftover files found.")
        return _msg(chat_id,
            f"🧹 **Cleanup complete!**\n\n"
            f"🗑️ Removed `{files_removed}` file(s)\n"
            f"💾 Freed `{fmt_size(bytes_freed)}`")
    except Exception as e:
        LOGGER(__name__).error(f"Cleanup failed: {e}")
        return _msg(chat_id, "❌ **Cleanup failed.** Check `/logs` for details.")

def handle_settings(chat_id: int) -> dict:
    """Send the settings menu with inline toggle buttons."""
    return {
        "method": "sendMessage",
        "chat_id": chat_id,
        "text": _settings_text(chat_id),
        "parse_mode": "Markdown",
        "reply_markup": _settings_keyboard_dict(chat_id),
    }

def handle_refresh(chat_id: int) -> dict:
    """Force an instant redraw of the live status board via the refresh_event."""
    state_mgr = _batch_registry.get(chat_id)
    if not state_mgr:
        return _msg(chat_id,
            "ℹ️ **No active batch** — nothing to refresh.\n"
            "_Run `/bdl` to start a batch._")
    get_refresh_event(chat_id).set()
    return _msg(chat_id, "🔄 **Status board refreshed!**")

# ════════════════════════════════════════════════════════
# MESSAGE PROXY (for /dl single download replies)
# ════════════════════════════════════════════════════════
class _MsgProxy:
    def __init__(self, cid: int, rid: int):
        self.id   = rid
        self.chat = type("_Chat", (), {"id": cid})()

    async def reply(self, text, **kw):
        kw.pop("reply_markup", None)
        await bot.send_message(self.chat.id, text,
                               reply_to_message_id=self.id)

# ════════════════════════════════════════════════════════
# SINGLE DOWNLOAD HANDLER (/dl)
# ════════════════════════════════════════════════════════
async def handle_download(chat_id: int, reply_to_id: int, post_url: str):
    async with download_semaphore:
        if "?" in post_url:
            post_url = post_url.split("?", 1)[0]
        message = _MsgProxy(chat_id, reply_to_id)
        try:
            _cid, message_id = getChatMsgID(post_url)
            status_msg = await bot.send_message(
                chat_id, "🔍 **Fetching post info…**",
                reply_to_message_id=reply_to_id)

            chat_message = await user.get_messages(
                chat_id=_cid, message_ids=message_id)
            LOGGER(__name__).info(f"Downloading from: {post_url}")

            if chat_message.media and not has_downloadable_media(chat_message):
                await status_msg.edit(
                    "❌ **No Downloadable Media**\n\n"
                    "This post contains only a link preview or unsupported media type.")
                return

            if chat_message.document or chat_message.video or chat_message.audio:
                file_size = (
                    chat_message.document.file_size if chat_message.document else
                    chat_message.video.file_size    if chat_message.video    else
                    chat_message.audio.file_size)
                if not await fileSizeLimit(file_size, message, "download",
                                           user.me.is_premium):
                    await status_msg.delete()
                    return

            parsed_caption = await get_parsed_msg(
                chat_message.caption or "", chat_message.caption_entities)
            parsed_text = await get_parsed_msg(
                chat_message.text or "", chat_message.entities)

            if chat_message.media_group_id:
                await status_msg.edit("📥 **Downloading…**")
                if not await _send_single_media(
                        chat_message, chat_id, reply_to_id=None):
                    await status_msg.edit(
                        "❌ **Failed**\n\nCould not extract media from this post.")
                else:
                    await status_msg.delete()
                return

            elif has_downloadable_media(chat_message):
                filename      = get_file_name(message_id, chat_message)
                fname_short   = short_name(filename)
                expected_size = get_expected_file_size(chat_message) or 0
                download_path = get_download_path(reply_to_id, filename)

                await status_msg.edit(
                    f"🔍 **Preparing download…**\n\n"
                    f"📄 `{fname_short}`\n"
                    f"📦 Size: `{fmt_size(expected_size) if expected_size else 'unknown'}`")

                dl_start  = time()
                last_edit = [0.0]

                async def on_progress(current: int, total: int):
                    now = time()
                    if now - last_edit[0] < 2.5:
                        return
                    last_edit[0] = now
                    elapsed = now - dl_start
                    speed   = current / elapsed if elapsed > 0 else 0
                    actual_total = total if total and total > 0 else expected_size
                    try:
                        await status_msg.edit(
                            build_progress_text(
                                "download", current, actual_total,
                                speed, elapsed, fname_short))
                    except Exception:
                        pass

                media_path, err, is_partial = await download_single_message(
                    chat_message, download_path,
                    progress_message=on_progress,
                    start_time=dl_start)

                if not media_path:
                    await status_msg.edit(
                        f"❌ **Download Failed**\n"
                        f"━━━━━━━━━━━━━━━━━━━\n"
                        f"📄 `{fname_short}`\n"
                        f"💬 `{err}`\n\n"
                        f"_Please try again._")
                    return

                actual_size = os.path.getsize(media_path)
                dl_elapsed  = time() - dl_start
                dl_speed    = actual_size / dl_elapsed if dl_elapsed > 0 else 0

                await status_msg.edit(
                    f"📤 **Uploading to Telegram…**\n\n"
                    f"📄 `{fname_short}`\n"
                    f"📦 `{fmt_size(actual_size)}`"
                    + (f"\n\n⚠️ _Partial file ({err})_" if is_partial else ""))

                media_type = (
                    "photo"    if chat_message.photo else
                    "video"    if chat_message.video else
                    "audio"    if chat_message.audio else
                    "document")

                caption = parsed_caption
                if is_partial:
                    caption = (
                        f"⚠️ **Partial File** — {err}\n"
                        f"{'━' * 19}\n" + caption)

                sent_msg = await send_media_with_progress(
                    bot, chat_id, media_path, media_type, caption, filename)
                cleanup_download(media_path)

                total_elapsed = time() - dl_start
                result_text = (
                    f"{'⚠️ Partial Download' if is_partial else '✅ Download Complete!'}\n"
                    f"━━━━━━━━━━━━━━━━━━━\n"
                    f"📄 **File:** `{fname_short}`\n"
                    f"📦 **Size:** `{fmt_size(actual_size)}`\n"
                    f"⚡ **Speed:** `{fmt_size(dl_speed)}/s`\n"
                    f"⏱ **Time:** `{fmt_time(total_elapsed)}`"
                    + (f"\n\n_Use /retry if you need the complete file._"
                       if is_partial else ""))
                await status_msg.edit(result_text)

            elif chat_message.text or chat_message.caption:
                await status_msg.delete()
                await bot.send_message(chat_id, parsed_text or parsed_caption)
            else:
                await status_msg.edit(
                    "❌ **Nothing to Download**\n\n"
                    "This post contains no media or text.")

        except FloodWait as e:
            wait_s = int(getattr(e, "value", 0) or 0)
            LOGGER(__name__).warning(f"FloodWait: {wait_s}s")
            try:
                await status_msg.edit(
                    f"⏳ **Rate Limited**\n\nWaiting `{wait_s}s`…")
            except Exception:
                pass
            if wait_s > 0:
                await asyncio.sleep(wait_s + 1)
        except (PeerIdInvalid, BadRequest, KeyError):
            try:
                await status_msg.edit(
                    "❌ **Access Denied**\n\n"
                    "Make sure the user client is a member of the source chat.")
            except Exception:
                await message.reply("❌ **Access Denied**")
        except Exception as e:
            LOGGER(__name__).error(traceback.format_exc())
            try:
                await status_msg.edit(
                    f"❌ **Something Went Wrong**\n\n`{str(e)[:200]}`")
            except Exception:
                await message.reply(f"❌ **Error:** `{str(e)[:200]}`")


async def _send_single_media(chat_message, chat_id: int,
                             reply_to: int = None) -> bool:
    """Send one media item standalone (used by /dl for media groups)."""
    if not has_downloadable_media(chat_message):
        return False
    filename      = get_file_name(chat_message.id, chat_message)
    download_path = get_download_path(chat_id, filename)
    media_path, err, is_partial = await download_single_message(
        chat_message, download_path)
    if not media_path:
        return False
    cap = ""
    try:
        cap = await get_parsed_msg(
            chat_message.caption or "", chat_message.caption_entities)
    except Exception:
        cap = chat_message.caption or ""
    if is_partial:
        actual = os.path.getsize(media_path)
        expected = get_expected_file_size(chat_message) or 0
        cap = f"⚠️ **Partial File** {fmt_size(actual)}/{fmt_size(expected)}\n" + cap
    media_type = (
        "photo" if chat_message.photo else
        "video" if chat_message.video else
        "audio" if chat_message.audio else "document")
    await send_media_with_progress(bot, chat_id, media_path,
                                   media_type, cap, filename)
    cleanup_download(media_path)
    return True

# ════════════════════════════════════════════════════════
# SLOT RESULT
# ════════════════════════════════════════════════════════
@dataclass
class _SlotResult:
    index:      int
    msg:        Any
    media_path: Optional[str] = None
    caption:    str           = ""
    media_type: str           = "document"
    filename:   str           = ""
    error:      Optional[str] = None
    skipped:    bool          = False
    is_partial: bool          = False   # partial file — send with warning

# ════════════════════════════════════════════════════════
# DOWNLOAD WORKER
# ════════════════════════════════════════════════════════
async def _download_worker(
    index:       int,
    chat_message,              # single message OR list of messages (media group)
    reply_to_id: int,
    slot_future: asyncio.Future,
    state_mgr:   BatchStateManager,
    worker_sem:  asyncio.Semaphore,
    skip_event:  asyncio.Event,
    kill_event:  asyncio.Event,
):
    async with worker_sem:
        if skip_event.is_set() or kill_event.is_set():
            await state_mgr.put(index, status=TaskStatus.SKIPPED)
            slot_future.set_result(_SlotResult(
                index=index, msg=chat_message, skipped=True))
            return

        # ── Media group: download each item, package as list ──────────────
        if isinstance(chat_message, list):
            group_msgs = chat_message
            group_results = []
            for gm in group_msgs:
                if not has_downloadable_media(gm):
                    continue
                gfilename  = get_file_name(gm.id, gm)
                gpath      = get_download_path(reply_to_id, f"grp_{gm.id}_{gfilename}")
                gexpected  = get_expected_file_size(gm) or 0
                await state_mgr.put(index, status=TaskStatus.DOWNLOADING,
                                    filename=gfilename, file_size=gexpected)
                gpath_dl, gerr, gpartial = await download_single_message(gm, gpath)
                if kill_event.is_set():
                    for r in group_results:
                        if r.get("path") and os.path.exists(r["path"]):
                            cleanup_download(r["path"])
                    if gpath_dl and os.path.exists(gpath_dl):
                        cleanup_download(gpath_dl)
                    if index in state_mgr.state_map:
                        state_mgr.state_map[index].status = TaskStatus.SKIPPED
                    slot_future.set_result(_SlotResult(
                        index=index, msg=group_msgs[0], skipped=True))
                    return
                gcap = ""
                try:
                    gcap = await get_parsed_msg(
                        gm.caption or "", gm.caption_entities)
                except Exception:
                    gcap = gm.caption or ""
                gmtype = ("photo" if gm.photo else "video" if gm.video
                          else "audio" if gm.audio else "document")
                group_results.append({
                    "msg_id": gm.id,
                    "path":    gpath_dl,     # None if download failed
                    "err":     gerr,
                    "partial": gpartial,
                    "cap":     gcap,
                    "mtype":   gmtype,
                    "filename": gfilename,
                    "expected": gexpected,
                })

            if not group_results:
                if index in state_mgr.state_map:
                    state_mgr.state_map[index].status = TaskStatus.ABANDONED
                    state_mgr.state_map[index].error  = "No downloadable media in group"
                slot_future.set_result(_SlotResult(
                    index=index, msg=group_msgs[0],
                    error="No downloadable media in group"))
                return

            has_any_success = any(r["path"] for r in group_results)
            if index in state_mgr.state_map:
                state_mgr.state_map[index].status = TaskStatus.SENDING
            slot_future.set_result(_SlotResult(
                index=index, msg=group_msgs[0],
                caption="", media_type="group",
                filename=f"media_group_{len(group_results)}_items",
                error=None,
                is_partial=any(r["partial"] for r in group_results)
                           or not has_any_success,
                media_path=json.dumps(group_results, default=str),
            ))
            return

        # ── Single message ─────────────────────────────────────────────────
        await state_mgr.put(index, status=TaskStatus.DOWNLOADING)

        if not has_downloadable_media(chat_message):
            # Text/poll/etc — no download needed
            await state_mgr.put(index, status=TaskStatus.SENDING,
                                filename=f"Post #{index+1}")
            slot_future.set_result(_SlotResult(
                index=index, msg=chat_message,
                caption="", media_type="text"))
            return

        filename      = get_file_name(chat_message.id, chat_message)
        download_path = get_download_path(reply_to_id, filename)
        expected_size = get_expected_file_size(chat_message) or 0

        await state_mgr.put(index, filename=filename, file_size=expected_size)

        _last_prog = [0.0]
        async def _slot_progress(current: int, total: int):
            if kill_event.is_set():
                return
            now = time()
            if now - _last_prog[0] < 3.0:
                return
            _last_prog[0] = now
            actual_total = total if total and total > 0 else expected_size
            await state_mgr.put(index, bytes_done=current, file_size=actual_total)

        media_path, err, is_partial = await download_single_message(
            chat_message, download_path,
            progress_message=_slot_progress)

        if kill_event.is_set():
            if media_path and os.path.exists(media_path):
                cleanup_download(media_path)
            await state_mgr.put(index, status=TaskStatus.SKIPPED)
            slot_future.set_result(_SlotResult(
                index=index, msg=chat_message, skipped=True))
            return

        if not media_path:
            # Directly update state_map (not via queue) so /retry sees it immediately
            if index in state_mgr.state_map:
                state_mgr.state_map[index].status = TaskStatus.ABANDONED
                state_mgr.state_map[index].error  = err or "Download failed"
            slot_future.set_result(_SlotResult(
                index=index, msg=chat_message,
                filename=filename,
                error=err or "Download failed"))
            return

        cap = ""
        try:
            cap = await get_parsed_msg(
                chat_message.caption or "",
                chat_message.caption_entities)
        except Exception:
            cap = chat_message.caption or ""

        media_type = (
            "photo"    if chat_message.photo else
            "video"    if chat_message.video else
            "audio"    if chat_message.audio else
            "document")

        status = TaskStatus.PARTIAL if is_partial else TaskStatus.SENDING
        await state_mgr.put(
            index, status=status,
            filename=filename,
            file_size=os.path.getsize(media_path))

        slot_future.set_result(_SlotResult(
            index=index, msg=chat_message,
            media_path=media_path,
            caption=cap,
            media_type=media_type,
            filename=filename,
            is_partial=is_partial,
        ))

# ════════════════════════════════════════════════════════
# SEND ONE SLOT
# Handles: media, partial, abandoned, text, polls, etc.
# Updates src_to_dst_map for reply chain preservation.
# Returns (sent, failed, skipped, next_index)
# ════════════════════════════════════════════════════════
async def _send_one_slot(
    index:          int,
    results:        Dict[int, _SlotResult],
    chat_id:        int,
    state_mgr:      BatchStateManager,
    src_to_dst_map: Dict[int, int],
    kill_event:     asyncio.Event,
) -> tuple:
    result = results[index]
    sent = failed = skipped = 0

    if kill_event.is_set():
        if result.media_path and os.path.exists(result.media_path):
            cleanup_download(result.media_path)
        skipped = 1
        return sent, failed, skipped, index + 1

    if result.skipped:
        skipped = 1
        if result.media_path:
            cleanup_download(result.media_path)
        LOGGER(__name__).info(f"[Sender] Slot {index} skipped.")
        return sent, failed, skipped, index + 1

    src_msg = result.msg

    # ── Abandoned: no bytes at all ─────────────────────────────────────────
    if result.error and not result.media_path and result.media_type != "group":
        failed = 1
        fname  = short_name(result.filename or f"Post #{index + 1}", 35)
        LOGGER(__name__).error(f"[Sender] Slot {index} abandoned: {result.error}")
        try:
            placeholder = await bot.send_message(
                chat_id,
                f"🔲 **File Unavailable** — Post #{index + 1}\n"
                f"━━━━━━━━━━━━━━━━━━━\n"
                f"📄 `{fname}`\n"
                f"⚠️ _{result.error[:150]}_\n\n"
                f"_The file exists in the source channel but could not be downloaded.\n"
                f"Use `/retry` after the batch completes to try again._")
            # Directly update state_map so /retry sees it immediately (no queue race)
            if index in state_mgr.state_map:
                state_mgr.state_map[index].status           = TaskStatus.ABANDONED
                state_mgr.state_map[index].placeholder_msg_id = placeholder.id
        except Exception as e:
            LOGGER(__name__).error(f"Placeholder send failed: {e}")
        return sent, failed, skipped, index + 1

    # ── Media group slot ───────────────────────────────────────────────────
    if result.media_type == "group" and result.media_path:
        try:
            group_items = json.loads(result.media_path)
        except Exception:
            group_items = []

        group_sent = group_failed = 0
        failed_filenames = []

        for item in group_items:
            ipath    = item.get("path")
            icap     = item.get("cap", "")
            imtype   = item.get("mtype", "document")
            ifname   = item.get("filename", "")
            ipartial = item.get("partial", False)
            ierr     = item.get("err", "")
            iexpected = item.get("expected", 0)

            # Item downloaded successfully (full or partial)
            if ipath and os.path.exists(ipath):
                actual = os.path.getsize(ipath)
                if ipartial:
                    icap = (f"⚠️ **Partial** `{fmt_size(actual)}`/`{fmt_size(iexpected)}`\n"
                            f"_Use `/retry` for full file._\n" + icap)
                try:
                    sm = await send_media_with_progress(
                        bot, chat_id, ipath, imtype, icap, ifname)
                    if sm and src_msg:
                        src_to_dst_map[src_msg.id] = sm.id
                    group_sent += 1
                    if ipartial:
                        group_failed += 1  # partial still needs retry
                except FloodWait as e:
                    wait_s = int(getattr(e, "value", 0) or 0)
                    await asyncio.sleep(wait_s + 1)
                    try:
                        sm = await send_media_with_progress(
                            bot, chat_id, ipath, imtype, icap, ifname)
                        group_sent += 1
                    except Exception as e2:
                        group_failed += 1
                        failed_filenames.append(ifname)
                        LOGGER(__name__).error(f"Group item retry send failed: {e2}")
                except Exception as e:
                    group_failed += 1
                    failed_filenames.append(ifname)
                    LOGGER(__name__).error(f"Group item send failed: {e}")
                finally:
                    cleanup_download(ipath)
            else:
                # Item download failed — send placeholder to preserve sequence
                group_failed += 1
                failed_filenames.append(ifname)
                fname_short = short_name(ifname or "unknown", 35)
                LOGGER(__name__).warning(
                    f"Group item missing/failed: {ifname} — {ierr}")
                try:
                    ph = await bot.send_message(
                        chat_id,
                        f"🔲 **File Unavailable** (group item)\n"
                        f"━━━━━━━━━━━━━━━━━━━\n"
                        f"📄 `{fname_short}`\n"
                        f"⚠️ _{str(ierr)[:120] or 'Download failed'}_\n\n"
                        f"_Use `/retry` to attempt re-download._")
                    # Store the placeholder for /retry
                    if index in state_mgr.state_map:
                        state_mgr.state_map[index].placeholder_msg_id = ph.id
                except Exception as pe:
                    LOGGER(__name__).error(f"Group placeholder send failed: {pe}")

        # Set final slot status
        if group_sent > 0 and group_failed == 0:
            sent = 1
            if index in state_mgr.state_map:
                state_mgr.state_map[index].status = TaskStatus.COMPLETED
        elif group_sent > 0 and group_failed > 0:
            sent = 1
            failed = 1   # partial success — mark both
            if index in state_mgr.state_map:
                state_mgr.state_map[index].status = TaskStatus.PARTIAL
                state_mgr.state_map[index].error  = (
                    f"Some items failed: {', '.join(failed_filenames)}")
        else:
            failed = 1
            if index in state_mgr.state_map:
                state_mgr.state_map[index].status = TaskStatus.ABANDONED
        return sent, failed, skipped, index + 1

    # ── Media (full or partial) ────────────────────────────────────────────
    if result.media_path:
        if not os.path.exists(result.media_path):
            failed = 1
            LOGGER(__name__).error(f"[Sender] Slot {index}: file gone before send")
            try:
                ph = await bot.send_message(
                    chat_id,
                    f"🔲 **File Lost** — Post #{index + 1}\n\n"
                    f"`{os.path.basename(result.media_path)}`\n"
                    f"_File was removed before upload. Use `/retry`._")
                if index in state_mgr.state_map:
                    state_mgr.state_map[index].status           = TaskStatus.ABANDONED
                    state_mgr.state_map[index].placeholder_msg_id = ph.id
            except Exception:
                pass
            return sent, failed, skipped, index + 1

        try:
            sent_msg = await forward_message(
                src_msg=src_msg,
                chat_id=chat_id,
                media_path=result.media_path,
                media_type=result.media_type,
                is_partial=result.is_partial,
                src_to_dst_map=src_to_dst_map,
                filename=result.filename,
            )
            fsize = (os.path.getsize(result.media_path)
                     if os.path.exists(result.media_path) else 0)
            if result.is_partial:
                failed += 1
                if index in state_mgr.state_map:
                    state_mgr.state_map[index].status = TaskStatus.PARTIAL
                    if sent_msg:
                        state_mgr.state_map[index].placeholder_msg_id = sent_msg.id
            else:
                sent = 1
                if index in state_mgr.state_map:
                    state_mgr.state_map[index].status   = TaskStatus.COMPLETED
                    state_mgr.state_map[index].file_size = fsize
            if sent_msg and src_msg:
                src_to_dst_map[src_msg.id] = sent_msg.id
                if index in state_mgr.state_map:
                    state_mgr.state_map[index].sent_msg_id = sent_msg.id
            LOGGER(__name__).info(
                f"[Sender] {'⚠️' if result.is_partial else '✅'} "
                f"Slot {index} sent ({fmt_size(fsize)})")
        except Exception as e:
            failed = 1
            if index in state_mgr.state_map:
                state_mgr.state_map[index].status = TaskStatus.FAILED
                state_mgr.state_map[index].error  = str(e)
            LOGGER(__name__).error(f"[Sender] Send failed slot {index}: {e}")
            try:
                ph = await bot.send_message(
                    chat_id,
                    f"🔲 **Upload Failed** — Post #{index + 1}\n\n"
                    f"`{str(e)[:200]}`\n_Use `/retry` to try again._")
                if index in state_mgr.state_map:
                    state_mgr.state_map[index].placeholder_msg_id = ph.id
            except Exception:
                pass
        finally:
            cleanup_download(result.media_path)
        return sent, failed, skipped, index + 1

    # ── Text / poll / other non-media ─────────────────────────────────────
    if src_msg:
        try:
            sent_msg = await forward_message(
                src_msg=src_msg,
                chat_id=chat_id,
                src_to_dst_map=src_to_dst_map,
            )
            await state_mgr.put(index, status=TaskStatus.COMPLETED)
            sent = 1
            if sent_msg and src_msg:
                src_to_dst_map[src_msg.id] = sent_msg.id
                await state_mgr.put(index, sent_msg_id=sent_msg.id)
        except Exception as e:
            failed = 1
            await state_mgr.put(index, status=TaskStatus.FAILED, error=str(e))
            LOGGER(__name__).error(f"[Sender] Non-media forward failed slot {index}: {e}")
    else:
        skipped = 1

    return sent, failed, skipped, index + 1

# ════════════════════════════════════════════════════════
# ORDERED SENDER — strict sequence, maximum throughput
#
# Why NOT parallel uploads:
#   send_document() both uploads AND sends in one atomic Telegram call.
#   There is no way to "hold" a sent message. If slot 2 uploads before
#   slot 0, it appears in the chat before slot 0 — order broken.
#
# Correct architecture (mirrors upload_all.sh sequential process_group):
#   Downloads run N-parallel (MAX_FETCH_WORKERS) → files land on disk
#   Sender is strictly sequential — sends slot[i], then slot[i+1], …
#   Speed comes from pre-downloading: by the time slot[i] finishes
#   uploading, slots[i+1…i+N] are already on disk → sender chains
#   through them with zero additional wait.
#
# This matches upv3.py's design exactly:
#   "Sequential Upload Loop: guarantees upload order"
#   "downloads are parallel, uploads are sequential"
# ════════════════════════════════════════════════════════
async def _ordered_sender(
    futures:        List[asyncio.Future],   # download futures (resolved in parallel)
    chat_id:        int,
    state_mgr:      "BatchStateManager",
    src_to_dst_map: Dict[int, int],
    skip_event:     asyncio.Event,
    kill_event:     asyncio.Event,
) -> dict:
    """
    Sends slots in strict order 0, 1, 2, …
    Downloads happen in parallel (N workers), so by the time slot[i]
    finishes uploading, slot[i+1] is likely already on disk.
    The sender immediately chains to it with zero wait.
    """
    n = len(futures)
    sent = failed = skipped = 0

    # ready_queue: download done-callbacks push indices here instantly
    ready_queue: asyncio.Queue      = asyncio.Queue()
    results: Dict[int, _SlotResult] = {}

    def _on_done(index: int, fut: asyncio.Future):
        if fut.cancelled():
            results[index] = _SlotResult(index=index, msg=None, skipped=True)
        elif fut.exception():
            results[index] = _SlotResult(
                index=index, msg=None, error=str(fut.exception()))
        else:
            results[index] = fut.result()
        ready_queue.put_nowait(index)

    for i, fut in enumerate(futures):
        fut.add_done_callback(lambda f, idx=i: _on_done(idx, f))
        if fut.done():
            _on_done(i, fut)

    send_pointer = 0   # next slot index that must be sent

    while send_pointer < n:

        # ── Hard kill ──────────────────────────────────────────────────────
        if kill_event.is_set():
            while send_pointer < n:
                if send_pointer in state_mgr.state_map:
                    state_mgr.state_map[send_pointer].status = TaskStatus.SKIPPED
                skipped += 1
                send_pointer += 1
            break

        # ── Skip current slot ──────────────────────────────────────────────
        if skip_event.is_set():
            skip_event.clear()
            fut = futures[send_pointer]
            if not fut.done():
                fut.cancel()
            if send_pointer in state_mgr.state_map:
                state_mgr.state_map[send_pointer].status = TaskStatus.SKIPPED
            LOGGER(__name__).info(f"[Sender] Slot {send_pointer} skipped by user.")
            skipped += 1
            send_pointer += 1
            while send_pointer < n and send_pointer in results:
                s, f, sk, send_pointer = await _send_one_slot(
                    send_pointer, results, chat_id, state_mgr,
                    src_to_dst_map, kill_event)
                sent += s; failed += f; skipped += sk
                await state_mgr.move_status_to_bottom()
            continue

        # ── Send if this slot is already downloaded ────────────────────────
        if send_pointer in results:
            if send_pointer in state_mgr.state_map:
                state_mgr.state_map[send_pointer].status = TaskStatus.UPLOADING
            s, f, sk, send_pointer = await _send_one_slot(
                send_pointer, results, chat_id, state_mgr,
                src_to_dst_map, kill_event)
            sent += s; failed += f; skipped += sk
            await state_mgr.move_status_to_bottom()
            while send_pointer < n and send_pointer in results:
                if kill_event.is_set():
                    break
                if send_pointer in state_mgr.state_map:
                    state_mgr.state_map[send_pointer].status = TaskStatus.UPLOADING
                s, f, sk, send_pointer = await _send_one_slot(
                    send_pointer, results, chat_id, state_mgr,
                    src_to_dst_map, kill_event)
                sent += s; failed += f; skipped += sk
                await state_mgr.move_status_to_bottom()
            continue

        # ── Wait for any download to complete ─────────────────────────────
        try:
            await asyncio.wait_for(ready_queue.get(), timeout=1.0)
        except asyncio.TimeoutError:
            continue

        while send_pointer < n and send_pointer in results:
            if kill_event.is_set():
                break
            if send_pointer in state_mgr.state_map:
                state_mgr.state_map[send_pointer].status = TaskStatus.UPLOADING
            s, f, sk, send_pointer = await _send_one_slot(
                send_pointer, results, chat_id, state_mgr,
                src_to_dst_map, kill_event)
            sent += s; failed += f; skipped += sk
            await state_mgr.move_status_to_bottom()

    return {"sent": sent, "failed": failed, "skipped": skipped}

# ════════════════════════════════════════════════════════
# BATCH DOWNLOAD
# ════════════════════════════════════════════════════════
async def handle_batch_download(chat_id: int, reply_to_id: int,
                                start_link: str, end_link: str):
    message = _MsgProxy(chat_id, reply_to_id)
    try:
        start_chat, start_id = getChatMsgID(start_link)
        end_chat,   end_id   = getChatMsgID(end_link)
    except Exception as e:
        await message.reply(f"**❌ Error parsing links:\n`{e}`**")
        return
    if start_chat != end_chat:
        await message.reply("**❌ Both links must be from the same channel.**")
        return
    if start_id > end_id:
        await message.reply("**❌ Invalid range: start ID cannot exceed end ID.**")
        return

    total_range = end_id - start_id + 1
    prefix      = start_link.rsplit("/", 1)[0]

    loading_msg = await bot.send_message(
        chat_id,
        f"🔍 **Fetching {total_range} posts…**\n\n"
        f"Range: `{start_id}` → `{end_id}`\n"
        f"⚡ Workers: `{PyroConf.MAX_FETCH_WORKERS}` parallel")

    # ── Phase 1: Bulk fetch ───────────────────────────────
    all_ids = list(range(start_id, end_id + 1))
    fetched_messages: Dict[int, Any] = {}
    consecutive_errors = 0
    meta_failed = 0

    for chunk_start in range(0, len(all_ids), PyroConf.FETCH_BATCH_SIZE):
        chunk = all_ids[chunk_start: chunk_start + PyroConf.FETCH_BATCH_SIZE]
        try:
            msgs = await user.get_messages(chat_id=start_chat, message_ids=chunk)
            if not isinstance(msgs, list):
                msgs = [msgs]
            for m in msgs:
                if m and m.id:
                    fetched_messages[m.id] = m
            consecutive_errors = 0
        except (PeerIdInvalid, BadRequest) as e:
            consecutive_errors += len(chunk)
            meta_failed        += len(chunk)
            LOGGER(__name__).error(f"Critical fetch error: {e}")
            if consecutive_errors >= PyroConf.CONSECUTIVE_ERROR_LIMIT:
                await loading_msg.delete()
                await message.reply(
                    f"❌ **Batch Aborted**\n"
                    f"━━━━━━━━━━━━━━━━━━━\n"
                    f"{consecutive_errors} consecutive access errors.\n"
                    f"Make sure the user client is a member of the channel.")
                return
        except FloodWait as e:
            wait_s = int(getattr(e, "value", 0) or 0)
            await asyncio.sleep(wait_s + 1)
        except Exception as e:
            meta_failed        += len(chunk)
            consecutive_errors += 1
            LOGGER(__name__).error(f"Fetch chunk error: {e}")
        if chunk_start + PyroConf.FETCH_BATCH_SIZE < len(all_ids):
            await asyncio.sleep(PyroConf.FLOOD_WAIT_DELAY)

    # ── Build ordered task list ───────────────────────────
    # Each slot is either a single message or a list of messages
    # (for media groups — all items in the group are one slot).
    ordered_tasks: List[Any] = []          # each item: msg OR [msg, msg, …]
    seen_media_groups: Dict[str, int] = {} # media_group_id → index in ordered_tasks
    skipped_meta = 0

    for msg_id in all_ids:
        msg = fetched_messages.get(msg_id)
        if not msg:
            skipped_meta += 1
            continue
        if msg.media_group_id:
            gid = str(msg.media_group_id)
            if gid in seen_media_groups:
                # Append to existing group slot — don't create a new slot
                slot_idx = seen_media_groups[gid]
                existing = ordered_tasks[slot_idx]
                if isinstance(existing, list):
                    existing.append(msg)
                else:
                    ordered_tasks[slot_idx] = [existing, msg]
                continue
            else:
                seen_media_groups[gid] = len(ordered_tasks)
        # Forward EVERYTHING with content (not just media)
        if not has_any_content(msg):
            skipped_meta += 1
            continue
        ordered_tasks.append(msg)

    total_tasks = len(ordered_tasks)
    if total_tasks == 0:
        await loading_msg.delete()
        await message.reply(
            f"❌ **Nothing to Forward**\n\n"
            f"No content found in that range.\n"
            f"Fetched `{len(fetched_messages)}`/`{total_range}` posts, "
            f"skipped `{skipped_meta + meta_failed}`.")
        return

    batch_start = time()
    # Don't hardcode the initial text — let _build_ui_text render it
    # so every subsequent edit is guaranteed to differ (elapsed time changes)
    await loading_msg.edit(
        f"⚡ **Batch Download** — `{total_tasks}` posts\n"
        f"_Preparing workers…_")

    # ── Phase 2: State manager + workers ─────────────────
    kill_event = get_kill_event(chat_id)
    kill_event.clear()
    skip_event = get_skip_event(chat_id)
    skip_event.clear()
    refresh_event = get_refresh_event(chat_id)
    refresh_event.clear()

    state_mgr = BatchStateManager(
        total=total_tasks, chat_id=chat_id, reply_to_id=reply_to_id,
        status_message=loading_msg, batch_start=batch_start,
        refresh_event=refresh_event)
    state_mgr.register_slots(
        list(range(total_tasks)),
        [f"{prefix}/{(m[0].id if isinstance(m, list) else m.id)}"
         for m in ordered_tasks])
    state_mgr.start()

    # Register for /retry
    _batch_registry[chat_id] = state_mgr

    worker_sem  = asyncio.Semaphore(PyroConf.MAX_FETCH_WORKERS)
    loop        = asyncio.get_event_loop()
    slot_futures: List[asyncio.Future] = [
        loop.create_future() for _ in ordered_tasks]

    worker_tasks = []
    for i, msg in enumerate(ordered_tasks):
        wt = track_task(_download_worker(
            index=i, chat_message=msg,
            reply_to_id=reply_to_id,
            slot_future=slot_futures[i],
            state_mgr=state_mgr,
            worker_sem=worker_sem,
            skip_event=skip_event,
            kill_event=kill_event,
        ))
        worker_tasks.append(wt)

    # Register worker tasks for /killall
    _batch_worker_tasks[chat_id] = worker_tasks

    # Reply chain: source msg_id → our group msg_id
    src_to_dst_map: Dict[int, int] = {}

    # ── Phase 3: Ordered sender ───────────────────────────
    results = await _ordered_sender(
        futures=slot_futures,
        chat_id=chat_id,
        state_mgr=state_mgr,
        src_to_dst_map=src_to_dst_map,
        skip_event=skip_event,
        kill_event=kill_event,
    )

    # Cancel any still-running workers
    for t in worker_tasks:
        if not t.done():
            t.cancel()
    if worker_tasks:
        await asyncio.wait(worker_tasks, timeout=10)

    await state_mgr.stop()

    # Delete status message (will send final summary instead)
    try:
        await state_mgr.status_message.delete()
    except Exception:
        pass

    sent    = results["sent"]
    failed  = results["failed"]
    skipped = results["skipped"] + skipped_meta + meta_failed
    elapsed = fmt_time(time() - batch_start)
    retryable = len(state_mgr.get_retryable())

    counts   = state_mgr.summary()
    n_partial = counts[TaskStatus.PARTIAL]
    summary = (
        f"{'🛑 Batch Stopped' if kill_event.is_set() else '✅ Batch Complete!'}\n"
        f"━━━━━━━━━━━━━━━━━━━\n"
        f"📥 **Sent:**      `{sent}` post(s)\n"
        f"⚠️ **Partial:**   `{n_partial}` (sent with warning)\n"
        f"🔲 **Abandoned:** `{retryable}` (placeholder sent)\n"
        f"⏭️ **Skipped:**   `{skipped}`\n"
        f"⏱ **Time:**      `{elapsed}`\n"
        f"━━━━━━━━━━━━━━━━━━━\n"
        f"⚡ **Workers:**   `{PyroConf.MAX_FETCH_WORKERS}` parallel"
        + (f"\n\n_💡 {retryable} slot(s) can be retried — send /retry_"
           if retryable > 0 else ""))
    await bot.send_message(chat_id, summary)

# ════════════════════════════════════════════════════════
# /retry COMMAND
# Re-attempts failed/abandoned/partial slots from the last
# batch, editing their placeholder messages with results.
# ════════════════════════════════════════════════════════
async def handle_retry(chat_id: int, reply_to_id: int):
    state_mgr = _batch_registry.get(chat_id)
    if not state_mgr:
        await bot.send_message(
            chat_id,
            "❌ **No batch found to retry.**\n\n"
            "Run a `/bdl` batch first.",
            reply_to_message_id=reply_to_id)
        return

    retryable = state_mgr.get_retryable()
    if not retryable:
        await bot.send_message(
            chat_id,
            "✅ **Nothing to retry** — all slots succeeded!",
            reply_to_message_id=reply_to_id)
        return

    status_msg = await bot.send_message(
        chat_id,
        f"🔁 **Retrying `{len(retryable)}` slot(s)…**\n\n"
        f"Slots: {', '.join(f'#{ts.index + 1}' for ts in retryable)}",
        reply_to_message_id=reply_to_id)

    fixed = still_failed = 0
    for ts in retryable:
        src_msg = None
        # Re-fetch the original message
        try:
            _cid, _mid = getChatMsgID(ts.url)
            src_msg = await user.get_messages(chat_id=_cid, message_ids=_mid)
        except Exception as e:
            LOGGER(__name__).error(f"Retry fetch failed slot {ts.index}: {e}")
            still_failed += 1
            continue

        if not src_msg:
            still_failed += 1
            continue
        # Non-media slot (text, poll, etc.) — forward directly, no download needed
        if not has_downloadable_media(src_msg):
            try:
                await forward_message(src_msg=src_msg, chat_id=chat_id)
                if ts.placeholder_msg_id:
                    try:
                        await bot.edit_message_text(
                            chat_id, ts.placeholder_msg_id,
                            f'✅ **Fixed!** — Post #{ts.index + 1} (text/non-media)')
                    except Exception:
                        pass
                ts.status = TaskStatus.COMPLETED
                fixed += 1
            except Exception as e:
                LOGGER(__name__).error(f'Retry non-media forward failed: {e}')
                still_failed += 1
            continue

        filename      = get_file_name(src_msg.id, src_msg)
        download_path = get_download_path(state_mgr.reply_to_id, filename)
        fname_short   = short_name(filename)

        await status_msg.edit(
            f"🔁 **Retrying…** `{fname_short}`\n\n"
            f"Slot #{ts.index + 1} of {len(retryable)}")

        media_path, err, is_partial = await download_single_message(
            src_msg, download_path)

        if not media_path:
            still_failed += 1
            LOGGER(__name__).error(f"Retry failed slot {ts.index}: {err}")
            continue

        cap = ""
        try:
            cap = await get_parsed_msg(
                src_msg.caption or "", src_msg.caption_entities)
        except Exception:
            cap = src_msg.caption or ""

        if is_partial:
            actual = os.path.getsize(media_path)
            expected = get_expected_file_size(src_msg) or 0
            cap = (f"⚠️ **Still Partial** {fmt_size(actual)}/{fmt_size(expected)}\n"
                   + cap)

        media_type = (
            "photo" if src_msg.photo else
            "video" if src_msg.video else
            "audio" if src_msg.audio else "document")

        try:
            sent_msg = await send_media_with_progress(
                bot, chat_id, media_path, media_type, cap, filename)
            cleanup_download(media_path)

            # Edit the old placeholder to point to the new message
            if ts.placeholder_msg_id and sent_msg:
                try:
                    await bot.edit_message_text(
                        chat_id, ts.placeholder_msg_id,
                        f"✅ **Fixed!** — Post #{ts.index + 1}\n\n"
                        f"_Successfully re-downloaded. See the message above._")
                except Exception:
                    pass

            await state_mgr.put(ts.index,
                                status=TaskStatus.COMPLETED if not is_partial
                                else TaskStatus.PARTIAL,
                                sent_msg_id=sent_msg.id if sent_msg else None)
            fixed += 1
        except Exception as e:
            still_failed += 1
            cleanup_download(media_path)
            LOGGER(__name__).error(f"Retry send failed slot {ts.index}: {e}")

    await status_msg.edit(
        f"🔁 **Retry Complete!**\n"
        f"━━━━━━━━━━━━━━━━━━━\n"
        f"✅ **Fixed:**      `{fixed}`\n"
        f"❌ **Still failed:** `{still_failed}`"
        + (f"\n\n_Some slots still failed. Try /retry again later._"
           if still_failed > 0 else ""))

# ════════════════════════════════════════════════════════
# FASTAPI LIFESPAN
# ════════════════════════════════════════════════════════
@asynccontextmanager
async def lifespan(app: FastAPI):
    global download_semaphore
    download_semaphore = asyncio.Semaphore(PyroConf.MAX_CONCURRENT_DOWNLOADS)
    LOGGER(__name__).info("Starting Pyrogram clients…")
    await user.start()
    await bot.start()
    LOGGER(__name__).info(
        f"Bot ready — workers: fetch={PyroConf.MAX_FETCH_WORKERS} "
        f"dl={PyroConf.MAX_CONCURRENT_DOWNLOADS}")
    yield
    LOGGER(__name__).info("Shutting down — cancelling tasks…")
    if RUNNING_TASKS:
        for t in list(RUNNING_TASKS):
            t.cancel()
        await asyncio.wait(list(RUNNING_TASKS), timeout=15)
    await bot.stop()
    await user.stop()
    LOGGER(__name__).info("Shutdown complete.")

app = FastAPI(lifespan=lifespan)

# ════════════════════════════════════════════════════════
# WEBHOOK
# ════════════════════════════════════════════════════════
@app.post("/webhook")
async def telegram_webhook(request: Request):
    update = await request.json()
    LOGGER(__name__).debug(f"Update: {update}")

    # ── Inline button callback (Refresh button on status message) ──────────
    if "callback_query" in update:
        cq      = update["callback_query"]
        cq_id   = cq["id"]
        cq_data = cq.get("data", "")
        cq_chat = cq["message"]["chat"]["id"]
        cq_msg_id = cq["message"]["message_id"]

        # ── Settings toggle ────────────────────────────────────────────────
        if cq_data.startswith(SETTING_CB_PREFIX):
            # Format: setting:<key>:<0|1>
            parts = cq_data[len(SETTING_CB_PREFIX):].rsplit(":", 1)
            if len(parts) == 2:
                key, raw_val = parts
                new_val = bool(int(raw_val))
                set_setting(cq_chat, key, new_val)
                label  = _SETTING_LABELS.get(key, key)
                status = "✅ On" if new_val else "❌ Off"

                # Update the settings menu immediately so the toggle reflects
                try:
                    await bot.edit_message_text(
                        chat_id=cq_chat,
                        message_id=cq_msg_id,
                        text=_settings_text(cq_chat),
                        reply_markup=_settings_keyboard(cq_chat))
                except Exception as e:
                    LOGGER(__name__).debug(f"Settings menu update failed: {e}")

                # For status_always_bottom: demonstrate the effect instantly.
                # If turned ON  → move status to bottom right now so user sees it snap down.
                # If turned OFF → edit status in-place so user sees it stop jumping.
                if key == "status_always_bottom":
                    state_mgr = _batch_registry.get(cq_chat)
                    if state_mgr and state_mgr.status_message:
                        try:
                            await state_mgr.move_status_to_bottom()
                        except Exception as e:
                            LOGGER(__name__).debug(f"Instant status demo failed: {e}")

                try:
                    await bot.answer_callback_query(
                        cq_id, f"{label}: {status}")
                except Exception:
                    pass

            return JSONResponse({"status": "ok"})

        # ── Settings close ─────────────────────────────────────────────────
        if cq_data == "settings_close":
            try:
                await bot.delete_messages(cq_chat, [cq_msg_id])
            except Exception:
                pass
            try:
                await bot.answer_callback_query(cq_id, "Settings closed.")
            except Exception:
                pass
            return JSONResponse({"status": "ok"})

        if cq_data == REFRESH_CB:
            state_mgr = _batch_registry.get(cq_chat)
            if state_mgr and state_mgr.status_message:
                try:
                    await bot.edit_message_text(
                        chat_id=cq_chat,
                        message_id=state_mgr.status_message.id,
                        text=state_mgr._build_ui_text(),
                        reply_markup=state_mgr._refresh_markup())
                    await bot.answer_callback_query(cq_id, "✅ Refreshed!")
                except Exception as e:
                    LOGGER(__name__).debug(f"Refresh callback failed: {e}")
                    try:
                        await bot.answer_callback_query(cq_id, "⚠️ Could not refresh")
                    except Exception:
                        pass
            else:
                try:
                    await bot.answer_callback_query(cq_id, "No active batch found.")
                except Exception:
                    pass
        return JSONResponse({"status": "ok"})

    if "message" not in update:
        return JSONResponse({"status": "ok"})

    msg     = update["message"]
    chat_id = msg["chat"]["id"]
    text    = msg.get("text", "").strip()
    msg_id  = msg["message_id"]

    if text.startswith("/start"):
        return JSONResponse(handle_start(chat_id))
    if text.startswith("/help"):
        return JSONResponse(handle_help(chat_id))
    if text.startswith("/stats"):
        return JSONResponse(handle_stats(chat_id))
    if text.startswith("/killall"):
        return JSONResponse(handle_killall(chat_id))
    if text.startswith("/skip"):
        return JSONResponse(handle_skip(chat_id))
    if text.startswith("/cleanup"):
        return JSONResponse(handle_cleanup(chat_id))
    if text.startswith("/settings"):
        return JSONResponse(handle_settings(chat_id))
    if text.startswith("/refresh"):
        return JSONResponse(handle_refresh(chat_id))

    if text.startswith("/retry"):
        track_task(handle_retry(chat_id, msg_id))
        return JSONResponse({"status": "ok"})

    if text.startswith("/logs"):
        async def _send_logs():
            if os.path.exists("logs.txt"):
                await bot.send_document(
                    chat_id, "logs.txt", caption="**Logs**",
                    reply_to_message_id=msg_id)
            else:
                await bot.send_message(
                    chat_id, "**No log file found.**",
                    reply_to_message_id=msg_id)
        track_task(_send_logs())
        return JSONResponse({"status": "ok"})

    if text.startswith("/dl"):
        parts = text.split(None, 1)
        if len(parts) < 2:
            return JSONResponse(
                _msg(chat_id, "**Provide a post URL after the /dl command.**"))
        track_task(handle_download(chat_id, msg_id, parts[1].strip()))
        return JSONResponse({"status": "ok"})

    if text.startswith("/bdl"):
        parts = text.split()
        if (len(parts) != 3
                or not all(p.startswith("https://t.me/") for p in parts[1:])):
            return JSONResponse(_msg(chat_id,
                "🚀 **Batch Copy**\n`/bdl start_link end_link`\n\n"
                "Copies everything: media, text, polls, stickers.\n"
                "Reply chains are preserved.\n\n"
                "💡 Example:\n"
                "`/bdl https://t.me/mychannel/100 https://t.me/mychannel/120`"))
        track_task(handle_batch_download(chat_id, msg_id, parts[1], parts[2]))
        return JSONResponse({"status": "ok"})

    if text and not text.startswith("/"):
        track_task(handle_download(chat_id, msg_id, text))
        return JSONResponse({"status": "ok"})

    return JSONResponse({"status": "ok"})