"""
This script fetches all video content from a Classplus course, retrieves the
final playable .m3u8 stream URL for each video, and saves the result in a
structured, stateful JSON file.

ROBUST & RESUMABLE DESIGN (v2.4 - Bug Fix):
- State File: Uses 'course_data_with_videos.json' to store progress.
- First Run: Scans the entire course to build a content tree, marking all
  videos as 'pending' with a retry counter.
- Subsequent Runs: Loads the state file and only processes videos that are
  'pending' or 'failed'.
- Retry Limit: A video will only be attempted a fixed number of times
  (MAX_VIDEO_ATTEMPTS). If it consistently fails, its status is changed to
  'permanently_failed' and it will be skipped in all future runs.
- Real-time Save: The state file is updated after every single video is
  processed, ensuring minimal data loss if the script is interrupted.
- Advanced Logging: Features colored console output for readability and
  structured JSON file logging for machine analysis.
"""
import os
import json
import re
import logging
import time
import sys  # NEW: Added for graceful exit
from pathlib import Path
from urllib.parse import urljoin
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from datetime import datetime
from typing import Optional, List, Dict, Any
from dotenv import load_dotenv

try:
    import colorlog
except ImportError:
    colorlog = None

load_dotenv() # <--- ADD THIS LINE


# -------------------------------
# CONFIGURATION
# -------------------------------
# ACCESS_TOKEN = "eyJhbGciOiJIUzM4NCIsInR5cCI6IkpXVCJ9.eyJpZCI6MTI0MTc4MjUzLCJvcmdJZCI6NDM5MzUxLCJ0eXBlIjoxLCJtb2JpbGUiOiI5MTYzOTIyNDk4MzciLCJuYW1lIjoiQWpheSIsImVtYWlsIjpudWxsLCJpc0ludGVybmF0aW9uYWwiOjAsImRlZmF1bHRMYW5ndWFnZSI6ImVuIiwiY291bnRyeUNvZGUiOiJJTiIsImNvdW50cnlJU08iOiI5MSIsInRpbWV6b25lIjoiR01UKzU6MzAiLCJpc0RpeSI6dHJ1ZSwib3JnQ29kZSI6InN0aWJsIiwiaXNEaXlTdWJhZG1pbiI6MCwiZmluZ2VycHJpbnRJZCI6IjczOWEyNDgyYmI0MjYzZTM2NzY1YzkyZTVkZTY2YmZlIiwiaWF0IjoxNzUyNTAyOTIyLCJleHAiOjE3NTMxMDc3MjJ9.tOcp-_JsPw_LZdtvP60wlfLcPi4hI80z4rSJ5wJlTabMY561FPdPIx4gUgyuoSj2"
ACCESS_TOKEN = os.getenv("ACCESS_TOKEN")
COURSE_ID = 516707
BASE_URL = "https://api.classplusapp.com/v2/course/content/get"

# --- State and Output File Configuration ---
OUTPUT_DIR = Path(os.getenv('COURSE_SAVE_PATH', './course_output')).resolve()
# OUTPUT_DIR = Path(os.getenv('COURSE_SAVE_PATH', '/teamspace/studios/this_studio/video_av_chemistry_classes/course_output')).resolve()
STATE_FILE_PATH = OUTPUT_DIR / 'course_data_with_videos.json'
LOG_FILE = OUTPUT_DIR / "download_links_log.jsonl"

# --- Network & Retry Logic ---
REQUEST_TIMEOUT = 30
MAX_RETRIES = 5
RETRY_BACKOFF_FACTOR = 0.5
API_DELAY = 0.5
CONSECUTIVE_ERROR_LIMIT = 10  # NEW: Exit after this many 403/404 errors in a row

# --- Configuration for retrying individual videos across script runs ---
MAX_VIDEO_ATTEMPTS = 500

# -------------------------------
# ADVANCED LOGGING SETUP
# -------------------------------
class JsonFormatter(logging.Formatter):
    """Custom formatter to output logs in JSONL format."""
    def format(self, record):
        log_object = {
            "timestamp": datetime.fromtimestamp(record.created).isoformat(),
            "level": record.levelname,
            "message": record.getMessage(),
            "module": record.module,
            "funcName": record.funcName,
            "lineno": record.lineno,
        }
        return json.dumps(log_object)

def setup_logging():
    """Configures logging for both console and file with beautiful output."""
    # FIX: Ensure the output directory exists *before* setting up file logging.
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    root_logger = logging.getLogger()
    root_logger.setLevel(logging.INFO)
    root_logger.handlers = []

    if colorlog:
        c_format = '%(log_color)s[%(asctime)s] %(levelname)-8s%(reset)s | %(message)s'
        formatter = colorlog.ColoredFormatter(c_format, datefmt='%H:%M:%S')
        handler = colorlog.StreamHandler()
    else:
        formatter = logging.Formatter('[%(asctime)s] %(levelname)-8s | %(message)s', datefmt='%H:%M:%S')
        handler = logging.StreamHandler()

    handler.setFormatter(formatter)
    root_logger.addHandler(handler)

    file_handler = logging.FileHandler(LOG_FILE, mode='a', encoding='utf-8')
    file_handler.setFormatter(JsonFormatter())
    root_logger.addHandler(file_handler)

    return logging.getLogger(__name__)

logger = setup_logging()

# NEW: Custom exception for fatal, non-recoverable errors
class CriticalErrorExit(Exception):
    pass

# NEW: Counter for consecutive critical API errors (like 403/404)
consecutive_error_counter = 0

# -------------------------------
# REQUESTS SESSION WITH RETRIES
# -------------------------------
session = requests.Session()
retries = Retry(total=MAX_RETRIES, backoff_factor=RETRY_BACKOFF_FACTOR, status_forcelist=(429, 500, 502, 503, 504))
adapter = HTTPAdapter(max_retries=retries)
session.mount('https://', adapter)
session.mount('http://', adapter)
HEADERS = {'x-access-token': ACCESS_TOKEN, 'User-Agent': 'video-downloader/2.4'}

# -------------------------------
# STATE MANAGEMENT & UTILITIES
# -------------------------------
def save_state(data: List[Dict]):
    """Atomically save the current state to the JSON file."""
    try:
        with open(STATE_FILE_PATH, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except IOError as e:
        logger.error(f"CRITICAL: Failed to save state to {STATE_FILE_PATH}. Error: {e}")

def load_state() -> Optional[List[Dict]]:
    """Load state from the JSON file if it exists."""
    if not STATE_FILE_PATH.exists():
        return None
    try:
        with open(STATE_FILE_PATH, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError) as e:
        logger.error(f"Could not load state file {STATE_FILE_PATH}. It might be corrupted. Error: {e}")
        return None

def log_summary(final_data: List[Dict]):
    """Logs a final summary report of the script's execution."""
    stats = {'completed': 0, 'failed': 0, 'permanently_failed': 0, 'pending': 0, 'total': 0}

    def count_statuses(nodes: List[Dict]):
        for node in nodes:
            if node.get('contentType') == 2:
                stats['total'] += 1
                status = node.get('downloadStatus', 'pending')
                if status in stats:
                    stats[status] += 1
            elif 'children' in node:
                count_statuses(node['children'])

    count_statuses(final_data)

    logger.info("=" * 60)
    logger.info("📊 SCRIPT EXECUTION SUMMARY 📊")
    logger.info("-" * 60)
    logger.info(f"  ✅ Completed:          {stats['completed']} / {stats['total']}")
    logger.info(f"  ⚠️ Failed (will retry):  {stats['failed']}")
    logger.info(f"  ❌ Permanently Failed:   {stats['permanently_failed']}")
    logger.info(f"  ⏳ Pending:              {stats['pending']}")
    logger.info("=" * 60)

# -------------------------------
# API & PARSING LOGIC
# -------------------------------
def fetch_folder_content(folder_id: Optional[int]) -> dict:
    """Fetches raw content for a given folder."""
    params = {'courseId': COURSE_ID, 'storeContentEvent': 'false'}
    # params = {'courseId': COURSE_ID, 'storeContentEvent': 'false', 'x-access-token': ACCESS_TOKEN}
    if folder_id is not None:
        params['folderId'] = folder_id
    try:
        resp = session.get(BASE_URL, headers=HEADERS, params=params, timeout=REQUEST_TIMEOUT)
        resp.raise_for_status()
        return resp.json().get('data', {})
    except requests.RequestException as e:
        logger.error(f"Failed to fetch folder_id={folder_id}: {e}")
        return {}

# MODIFIED: Entire function replaced to handle consecutive errors
def get_final_video_url(content_hash_id: str) -> Dict[str, Any]:
    """Takes a contentHashId and returns the final playable URL."""
    global consecutive_error_counter  # NEW: Declare usage of global counter

    try:
        api_url = f"https://api.classplusapp.com/cams/uploader/video/jw-signed-url?contentId={content_hash_id}"
        resp = session.get(api_url, headers=HEADERS, timeout=REQUEST_TIMEOUT)
        resp.raise_for_status()
        master_url = resp.json().get("url")
        if not master_url:
            return {"status": "failed", "error": "API did not return a master URL"}

        consecutive_error_counter = 0  # NEW: Reset counter on any successful API call

    except requests.RequestException as e:
        # NEW: Enhanced error handling for 403/404
        if isinstance(e, requests.HTTPError) and e.response is not None and e.response.status_code in (403, 404):
            consecutive_error_counter += 1
            error_msg = (
                f"Critical API error ({e.response.status_code}). This might mean your Access Token is "
                f"invalid/expired or content is removed. Consecutive errors: {consecutive_error_counter}/{CONSECUTIVE_ERROR_LIMIT}"
            )
            logger.warning(error_msg)
            if consecutive_error_counter >= CONSECUTIVE_ERROR_LIMIT:
                raise CriticalErrorExit(
                    f"Exiting: Reached {CONSECUTIVE_ERROR_LIMIT} consecutive critical errors (403/404). "
                    "Please check your ACCESS_TOKEN."
                )
            return {"status": "failed", "error": error_msg}
        # END NEW SECTION

        return {"status": "failed", "error": f"Failed to get master URL: {e}"}
    except json.JSONDecodeError:
        return {"status": "failed", "error": "Failed to parse master URL response"}

    try:
        resp = session.get(master_url)
        resp.raise_for_status()
        playlist_content = resp.text
    except requests.RequestException as e:
        return {"status": "failed", "error": f"Failed to fetch playlist content: {e}"}

    matches = re.findall(r'^([^#][^\n]+\.m3u8[^\s]*)$', playlist_content, re.MULTILINE)
    if not matches:
        # If the master playlist is valid but has no streams, reset the counter
        consecutive_error_counter = 0  # NEW: Reset on success here too
        return {"status": "failed", "error": "No .m3u8 variant stream found in playlist"}

    stream_path = matches[0].strip()
    final_url = urljoin(master_url, stream_path)
    return {"status": "completed", "url": final_url}


def build_initial_tree(folder_id: Optional[int] = None, depth=0) -> List[Dict]:
    """Recursively scans the course to build the initial structure."""
    prefix = "  " * depth
    folder_name_log = f"ID {folder_id}" if folder_id else "Root Folder"
    logger.info(f"{prefix}➡️  Scanning content of folder: '{folder_name_log}'...")

    data = fetch_folder_content(folder_id)
    if not data or not data.get('courseContent'):
        logger.info(f"{prefix}  -> Folder is empty or inaccessible.")
        return []

    items = data.get('courseContent', [])
    logger.info(f"{prefix}  -> Found {len(items)} items.")

    content_list = []
    for item in items:
        content_type = item.get('contentType')

        if content_type == 1: # Folder
            folder_node = {'contentType': 1, 'id': item.get('id'), 'name': item.get('name'), 'children': []}
            time.sleep(API_DELAY)
            children_content = build_initial_tree(folder_id=folder_node['id'], depth=depth + 1)
            if children_content:
                folder_node['children'] = children_content
                content_list.append(folder_node)

        elif content_type == 2: # Video
            content_list.append({
                'contentType': 2, 'id': item.get('id'), 'name': item.get('name'),
                'contentHashId': item.get('contentHashId'), 'duration': item.get('duration'),
                'downloadStatus': 'pending', 'finalUrl': None, 'error': None, 'retryCount': 0
            })
    return content_list

# MODIFICATION 1: The entire refresh function is updated with the pre-check logic.
def refresh_stale_content_hashes(nodes: List[Dict], parent_folder_id: Optional[int] = None, state: Optional[Dict[str, Any]] = None):
    """
    Recursively finds folders with stale videos (pending/failed) and refreshes
    their data, specifically updating the contentHashId. Includes a pre-check
    to avoid unnecessary API calls.
    """
    # Heuristic check: If we've already checked 10 items without finding a
    # difference, stop all further refresh checks for this run.
    if state and state.get('stop_refreshing'):
        return

    REFRESH_CHECK_LIMIT = 10
    
    # Check if this folder contains any videos that need processing
    needs_refresh = any(
        node.get('contentType') == 2 and node.get('downloadStatus') in ['pending', 'failed']
        for node in nodes
    )

    if needs_refresh:
        folder_name_log = f"ID {parent_folder_id}" if parent_folder_id else "Root"
        logger.info(f"🔎 Stale items detected in folder '{folder_name_log}'. Fetching fresh data...")

        time.sleep(API_DELAY)
        fresh_folder_data = fetch_folder_content(parent_folder_id)

        # Create a lookup map for quick access to fresh data by content ID
        fresh_content_map = {
            item['id']: item for item in fresh_folder_data.get('courseContent', [])
        }

        if not fresh_content_map:
            logger.warning(f"  -> Could not fetch fresh content for folder '{folder_name_log}'. Skipping refresh for this folder.")
        else:
            # Iterate through the existing nodes in the state and update them
            for node in nodes:
                if node.get('contentType') != 2:
                    continue # Only process videos here

                fresh_item_data = fresh_content_map.get(node['id'])
                if not fresh_item_data:
                    logger.warning(f"  -> Video '{node.get('name')}' (ID: {node.get('id')}) no longer exists in folder. Marking as permanently_failed.")
                    node['downloadStatus'] = 'permanently_failed'
                    node['error'] = 'Content removed from course by provider.'
                    continue

                old_hash = node.get('contentHashId')
                new_hash = fresh_item_data.get('contentHashId')

                # Only perform the check if we are within the initial limit
                if state and state['checked_count'] < REFRESH_CHECK_LIMIT:
                    state['checked_count'] += 1
                    if old_hash != new_hash:
                        # A difference was found! Mark it and continue refreshing normally.
                        state['diff_found'] = True
                        logger.info("  -> Difference found during pre-check. Full refresh will proceed.")

                # If we have checked 10 items and found no difference, stop.
                if state and state['checked_count'] >= REFRESH_CHECK_LIMIT and not state['diff_found']:
                    logger.info(f"Pre-check complete. No hash changes found in the first {REFRESH_CHECK_LIMIT} items. Halting further refresh checks.")
                    state['stop_refreshing'] = True
                    return # Exit this folder's processing

                if old_hash != new_hash:
                    logger.info(f"  -> Refreshing Hash ID for video: '{node.get('name')}'")
                    node['contentHashId'] = new_hash
                    node['name'] = fresh_item_data.get('name')
                    node['duration'] = fresh_item_data.get('duration')

    # Now, recurse into subfolders regardless of whether this level was refreshed
    for node in nodes:
        if node.get('contentType') == 1 and 'children' in node: # It's a folder
            refresh_stale_content_hashes(node['children'], parent_folder_id=node['id'], state=state)

def process_video_tree(nodes: List[Dict]):
    """Recursively traverses the data tree and fetches video URLs."""
    assert course_data is not None, "process_video_tree should not be called when course_data is None"

    for node in nodes:
        if node.get('contentType') == 2: # It's a video
            status = node.get('downloadStatus')

            if 'retryCount' not in node: node['retryCount'] = 0

            if (status == 'pending' or status == 'failed') and node['retryCount'] < MAX_VIDEO_ATTEMPTS:

                video_name = node.get('name', 'Unknown Video')
                attempt_num = node['retryCount'] + 1
                logger.info(f"🔄 Processing video: '{video_name}' (Attempt {attempt_num}/{MAX_VIDEO_ATTEMPTS})")

                node['retryCount'] += 1

                time.sleep(API_DELAY)

                content_hash = node.get('contentHashId')
                if not content_hash:
                    result = {"status": "failed", "error": "Missing contentHashId in course data"}
                else:
                    result = get_final_video_url(content_hash)

                if result['status'] == 'completed':
                    node['downloadStatus'] = 'completed'
                    node['finalUrl'] = result.get('url')
                    node['error'] = None
                    logger.info(f"  ✅ SUCCESS: URL fetched for '{video_name}'")
                else:
                    error_msg = result.get('error', 'Unknown error')
                    if node['retryCount'] >= MAX_VIDEO_ATTEMPTS:
                        node['downloadStatus'] = 'permanently_failed'
                        node['error'] = f"Final attempt failed: {error_msg}"
                        logger.error(f"  ❌ PERMANENT FAILURE for '{video_name}'. Reason: {error_msg}")
                    else:
                        node['downloadStatus'] = 'failed'
                        node['error'] = error_msg
                        logger.warning(f"  ⚠️ FAILED (will retry): Could not get URL for '{video_name}'. Reason: {error_msg}")

                save_state(course_data)

        elif node.get('contentType') == 1:
            logger.info(f"📁 Entering folder: '{node.get('name')}'")
            process_video_tree(node.get('children', []))
            logger.info(f"📁 Exiting folder: '{node.get('name')}'")


if __name__ == '__main__':
    if not ACCESS_TOKEN or "eyJhbGciOiJIUzM4NCIsInR5cCI6IkpXVCJ9" not in ACCESS_TOKEN:
        logger.critical("ACCESS_TOKEN is not set or looks invalid. Please edit the script. Exiting.")
        exit(1)

    logger.info("🚀 Starting Video Link Downloader v2.4 🚀")

    course_data = load_state()

    if course_data is None:
        logger.info(f"No state file found at '{STATE_FILE_PATH}'.")
        logger.info("========= STARTING FRESH COURSE SCAN =========")
        course_data = build_initial_tree()
        logger.info("=========  COURSE SCAN COMPLETE  =========")
        logger.info("Initial course structure built. Saving to state file...")
        save_state(course_data)
    else:
        logger.info(f"State file found. Resuming download process.")
        # MODIFICATION 2: The call to the refresh function is updated to use the state dictionary.
        logger.info("========= CHECKING FOR STALE CONTENT =========")
        try:
            # Initialize the state for our refresh heuristic
            refresh_state = {
                'checked_count': 0,
                'diff_found': False,
                'stop_refreshing': False
            }
            refresh_stale_content_hashes(course_data, state=refresh_state)
            
            if not refresh_state.get('stop_refreshing'):
                 logger.info("=========     STALE CHECK COMPLETE (updates found)     =========")
            else:
                 logger.info("=========     STALE CHECK COMPLETE (no updates needed)     =========")

            # Save state only if changes were potentially made before the heuristic stopped it
            if refresh_state.get('diff_found'):
                logger.info("Saving updated hash IDs to state file...")
                save_state(course_data)
            else:
                logger.info("No hash ID changes detected, state file is already up to date.")

        except Exception as e:
            logger.error(f"An unexpected error occurred during stale check: {e}. Processing with existing data.")

    # MODIFIED: Entire processing block wrapped in try/except for graceful shutdown
    if course_data is not None:
        try:
            logger.info("========= PROCESSING VIDEOS =========")
            process_video_tree(course_data)
            logger.info("=========  PROCESSING COMPLETE  =========")
            log_summary(course_data)
        except KeyboardInterrupt:
            logger.warning("\n🛑 Ctrl+C detected! Gracefully shutting down...")
            save_state(course_data)
            logger.info("Current progress has been saved to state file.")
            log_summary(course_data)
            sys.exit(130)  # Standard exit code for Ctrl+C
        except CriticalErrorExit as e:
            logger.critical(f"FATAL ERROR: {e}")
            save_state(course_data)
            logger.info("Current progress has been saved before forced exit.")
            log_summary(course_data)
            sys.exit(0)
    else:
        logger.critical("Failed to load or create course data. Cannot proceed.")

    logger.info("🏁 Script finished. 🏁")