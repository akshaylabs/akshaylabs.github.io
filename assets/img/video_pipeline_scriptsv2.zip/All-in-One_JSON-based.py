import os
import json
import re
import logging
import time
from pathlib import Path
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from datetime import datetime
from typing import Optional, List, Dict, Any

# -------------------------------
# CONFIGURATION
# -------------------------------
ACCESS_TOKEN = "eyJhbGciOiJIUzM4NCIsInR5cCI6IkpXVCJ9.eyJpZCI6MTYyNTQwOTYyLCJvcmdJZCI6NTczMTM4LCJ0eXBlIjoxLCJtb2JpbGUiOiI5MTkzMzY3OTcxOTMiLCJuYW1lIjoiQW1hbiBQYXJpaGFyIiwiZW1haWwiOiJhbWFudGhha3VyOTMzNjdAZ21haWwuY29tIiwiaXNJbnRlcm5hdGlvbmFsIjowLCJkZWZhdWx0TGFuZ3VhZ2UiOiJFTiIsImNvdW50cnlDb2RlIjoiSU4iLCJjb3VudHJ5SVNPIjoiOTEiLCJ0aW1lem9uZSI6IkdNVCs1OjMwIiwiaXNEaXkiOnRydWUsIm9yZ0NvZGUiOiJrdWpoaGsiLCJpc0RpeVN1YmFkbWluIjowLCJmaW5nZXJwcmludElkIjoiMzdjNzdmY2JiZDhlMTJkMjY3ZTZlZDRmNjI3YTcwODgiLCJpYXQiOjE3NTkwNDE1ODMsImV4cCI6MTc1OTY0NjM4M30.l_u5RxOJu8VSQmTgnK2fw7ZL9Buv61gglyCq6dyCfcJx7Gqnjh4U9z_xnn0nqdvF"
COURSE_ID = 733740
BASE_URL = "https://api.classplusapp.com/v2/course/content/get"

# --- All-in-One JSON Approach Configuration ---
# Directory for the final output and log files
OUTPUT_DIR = Path(os.getenv('COURSE_SAVE_PATH', './course_output')).resolve()
# The single file where all course data will be saved
OUTPUT_FILENAME = 'course_content.json'
LOG_FILE = OUTPUT_DIR / "download_log.jsonl"

# --- Network Robustness ---
REQUEST_TIMEOUT = 30  # Increased timeout for robustness
MAX_RETRIES = 5       # Total number of retries for failed requests
RETRY_BACKOFF_FACTOR = 0.5 # Wait time between retries (e.g., 0.5s, 1s, 2s...)

# -------------------------------
# LOGGING SETUP
# -------------------------------
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] %(levelname)s: %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)

# -------------------------------
# REQUESTS SESSION WITH RETRIES
# -------------------------------
session = requests.Session()
retries = Retry(
    total=MAX_RETRIES,
    backoff_factor=RETRY_BACKOFF_FACTOR,
    status_forcelist=(429, 500, 502, 503, 504), # Retry on these server errors
    allowed_methods=['GET']
)
adapter = HTTPAdapter(max_retries=retries)
session.mount('https://', adapter)
session.mount('http://', adapter)

# Using the original detailed headers as they are likely necessary for the API
HEADERS = {
    'accept-language': 'en',
    'user-agent': 'Mobile-Android',
    'region': 'IN',
    'is-apk': '1',
    'accept': 'application/json, text/plain, */*',
    'mobile-agent': 'Mobile-Android',
    'api-version': '52',
    'x-access-token': ACCESS_TOKEN,
    'origin': 'https://course-overview.classplusapp.com',
    'x-requested-with': 'co.jones.stibl',
    'sec-fetch-site': 'same-site',
    'sec-fetch-mode': 'cors',
    'sec-fetch-dest': 'empty',
    'referer': 'https://course-overview.classplusapp.com/',
    'accept-encoding': 'gzip, deflate'
}

# -------------------------------
# UTILITIES
# -------------------------------
def write_log(entry: dict):
    """Append a JSON log entry to the log file."""
    entry["timestamp"] = datetime.now().isoformat()
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        json.dump(entry, f)
        f.write("\n")

# -------------------------------
# FETCH AND BUILD LOGIC
# -------------------------------
def fetch_folder_content(course_id: int, folder_id: Optional[int] = None) -> dict:
    """Fetches ALL content for a given folder, handling pagination automatically."""
    params = {
        'courseId': course_id,
        # 'limit': 50,
        # 'offset': 0,
        # 'search': '',
        # 'originalCourseId': -1
    }
    if folder_id is not None:
        params['folderId'] = folder_id

    all_items = []
    last_data_packet = {}
    
    while True:
        try:
            resp = session.get(BASE_URL, headers=HEADERS, params=params, timeout=REQUEST_TIMEOUT)
            resp.raise_for_status()
            last_data_packet = resp.json().get('data', {})
            items = last_data_packet.get('courseContent', [])
            
            if not items:
                break # No more items to fetch

            all_items.extend(items)
            params['offset'] += len(items)
            time.sleep(0.2)

        except requests.exceptions.RequestException as e:
            logger.error(f"API request failed for folder {folder_id} at offset {params['offset']} after all retries: {e}")
            write_log({"action": "fetch_folder", "status": "fatal_error", "folder_id": folder_id, "error": str(e)})
            raise # Stop execution if a page fails to load

    return {
        'courseContent': all_items,
        'metadata': last_data_packet.get('metadata', {})
    }


def extract_relevant(item: Dict[str, Any]) -> Dict[str, Any]:
    """Extracts a clean, minimal subset of data from a raw API item."""
    ct = item.get('contentType')
    base = {
        'contentType': ct,
        'id': item.get('id'),
        'name': item.get('name')
    }
    if ct == 1: # Folder
        base.update({
            'description': item.get('description'),
            'resources': item.get('resources', {}),
            'counts': {
                'documents': item.get('documentCount'),
                'videos': item.get('videoCount'),
                'tests': item.get('testCount')
            },
            'children': [] # Placeholder for nested content
        })
    elif ct == 2: # Video
        base.update({
            'description': item.get('description', ''),
            'vidKey': item.get('vidKey'),
            'thumbnailUrl': item.get('thumbnailUrl'),
            'videoType': item.get('videoType'),
            'duration': item.get('duration'),
            'contentHashId': item.get('contentHashId')
        })
    elif ct == 3: # Document
        base.update({
            'description': item.get('description', ''),
            'format': item.get('format'),
            'url': item.get('url'),
            'isContentLocked': item.get('isContentLocked')
        })
    elif ct == 4: # Test
        base.update({
            'description': item.get('description', ''),
            'testId': item.get('testId'),
            'maxMarks': item.get('maxMarks'),
            'URL': item.get('URL')
        })
    return base


def recursively_build_structure(folder_id: Optional[int] = None) -> List[Dict[str, Any]]:
    """
    Recursively fetches course content and builds a nested list of dictionaries.
    This function returns the data structure instead of writing files directly.
    """
    try:
        data = fetch_folder_content(COURSE_ID, folder_id)
    except Exception as e:
        logger.error(f"FATAL: Could not fetch content for folder_id '{folder_id}'. Halting this branch. Error: {e}")
        return [] # Return an empty list for the failed branch

    items = data.get('courseContent', [])
    folder_name = data.get('metadata', {}).get('currentFolderDetails', {}).get('folderName', 'Course Root')
    
    logger.info(f"Processing folder: '{folder_name}' (ID: {folder_id}) with {len(items)} items.")
    write_log({"action": "process_folder", "folder_name": folder_name, "folder_id": folder_id, "item_count": len(items)})

    content_list = []
    for item in items:
        slim_item = extract_relevant(item)

        # If the item is a folder, recurse into it and attach the result
        if slim_item.get('contentType') == 1:
            item_id = slim_item.get('id')
            if item_id is not None:
                # The recursive call returns the list of children
                children_content = recursively_build_structure(item_id)
                slim_item['children'] = children_content
        
        content_list.append(slim_item)

    return content_list


if __name__ == '__main__':
    if not ACCESS_TOKEN or "eyJhbGciOiJIUzI1NiJ9" in ACCESS_TOKEN: # Basic check for placeholder
        logger.error("ACCESS_TOKEN is not set or is a placeholder. Please edit the script and add your token. Exiting.")
        exit(1)
        
    LOG_FILE.touch(exist_ok=True)

    logger.info("--- Starting Full Course Structure Fetch ---")
    logger.info(f"Course ID: {COURSE_ID}")
    logger.info(f"Output will be saved to: {OUTPUT_DIR.resolve()}")
    
    # This single call starts the recursive process to build the entire structure in memory.
    full_course_structure = recursively_build_structure(folder_id=None)
    
    # Save the complete structure to one JSON file
    output_path = OUTPUT_DIR / OUTPUT_FILENAME
    try:
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(full_course_structure, f, ensure_ascii=False, indent=2)
        
        logger.info(f"SUCCESS: Course structure successfully saved to '{output_path}'")
        write_log({
            "action": "save_master_json", "status": "success", "path": str(output_path)
        })
    except IOError as e:
        logger.error(f"Failed to write the final JSON file to '{output_path}': {e}")
        write_log({
            "action": "save_master_json", "status": "error", "path": str(output_path), "error": str(e)
        })

    logger.info("--- Fetch Process Finished ---")