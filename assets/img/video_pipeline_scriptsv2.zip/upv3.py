"""
High-Performance, Sequential Telegram Uploader with State Synchronization.

This script reads the `download_manifest.json`, intelligently syncs its state,
and uploads all available videos to Telegram in a strictly sequential order,
ensuring a perfectly organized channel.

It now also captures and stores a direct, shareable `tele_message_link` for each
successful upload.

ARCHITECTURE:
- Sequential Upload Loop: The core logic now uses a single, ordered loop to
  process files one by one, guaranteeing upload order.
- Resumable Widget ID: A sequential `widget_id` is assigned to each upload
  and is intelligently managed across script restarts.
- State Manager Thread: A dedicated thread still manages saving the state file
  (`upload_state.json`) to disk, keeping the main loop responsive.
- Graceful Interruption Handling: Catches Ctrl+C to prevent state corruption
  and ensures a clean shutdown, marking the in-progress file for re-upload.
"""
import os
import json
import re
import logging
import time
import subprocess
import shutil
from pathlib import Path
from datetime import datetime
from typing import Optional, List, Dict, Any, Tuple
from concurrent.futures import ThreadPoolExecutor, as_completed
from threading import Thread, Event
from queue import Queue
import requests
import sys

try:
    import colorlog
except ImportError:
    colorlog = None

try:
    from tqdm import tqdm
except ImportError:
    tqdm = None

# -------------------------------
# CONFIGURATION
# -------------------------------
BOT_TOKEN = "8033545689:AAFbB9gn2k8zOpzWVIJgIjSpUI0IZCFyOV0"
CHAT_ID = "@nifobry" # Use "@yourchannel" for public or "-100..." for private
BASE_URL_TEMPLATE = "http://127.0.0.1:8081/bot{}"

MAX_RETRIES = 5
RETRY_DELAY_SECONDS = 8
SAVE_INTERVAL_SECONDS = 5.0
STARTING_WIDGET_ID = 1

INPUT_DIR = Path('./course_output').resolve()
DOWNLOAD_ROOT_DIR = INPUT_DIR / 'course_downloads'
DOWNLOAD_MANIFEST_PATH = INPUT_DIR / 'download_manifest.json'
UPLOAD_STATE_PATH = INPUT_DIR / 'upload_state.json'
LOG_FILE = INPUT_DIR / "telegram_uploader_log.jsonl"

# -------------------------------
# ADVANCED LOGGING SETUP
# -------------------------------
class JsonFormatter(logging.Formatter):
    def format(self, record):
        log_object = {"timestamp": datetime.fromtimestamp(record.created).isoformat(), "level": record.levelname, "message": record.getMessage()}
        return json.dumps(log_object)
def setup_logging():
    INPUT_DIR.mkdir(parents=True, exist_ok=True)
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.INFO)
    root_logger.handlers = []
    if colorlog:
        formatter = colorlog.ColoredFormatter('%(log_color)s[%(asctime)s] %(levelname)-8s%(reset)s | %(message)s', datefmt='%H:%M:%S')
        handler = colorlog.StreamHandler()
    else:
        formatter = logging.Formatter('[%(asctime)s] %(levelname)-8s | %(message)s', datefmt='%H:%M:%S')
        handler = logging.StreamHandler()
    handler.setFormatter(formatter)
    root_logger.addHandler(handler)
    file_handler = logging.FileHandler(LOG_FILE, mode='a', encoding='utf-8')
    file_handler.setFormatter(JsonFormatter())
    root_logger.addHandler(file_handler)
    return logging.getLogger(__name__)
logger = setup_logging()
# -------------------------------
# STATE MANAGER CLASS
# -------------------------------
class StateManager(Thread):
    def __init__(self, state_data: List[Dict], update_queue: Queue, stop_event: Event):
        super().__init__(daemon=True, name="StateManager")
        self.state_data = state_data
        self.video_map = self._create_video_map(self.state_data)
        self.update_queue = update_queue
        self.stop_event = stop_event
        self.last_save_time = time.time()
    def _create_video_map(self, nodes: List[Dict]) -> Dict[Any, Dict]:
        video_map = {}
        for node in nodes:
            if node.get('contentType') == 2: video_map[node['id']] = node
            elif 'children' in node: video_map.update(self._create_video_map(node['children']))
        return video_map
    def run(self):
        logger.info("🗃️ State Manager thread started.")
        while not self.stop_event.is_set():
            try:
                update = self.update_queue.get(timeout=SAVE_INTERVAL_SECONDS)
                video_id = update.pop('id', None)
                if video_id in self.video_map: self.video_map[video_id].update(update)
                self.update_queue.task_done()
            except Exception: pass
            if time.time() - self.last_save_time > SAVE_INTERVAL_SECONDS: self._save_state()
        self._flush_queue(); self._save_state()
        logger.info("🗃️ State Manager thread finished and performed final save.")
    def _flush_queue(self):
        while not self.update_queue.empty():
            try:
                update = self.update_queue.get_nowait()
                video_id = update.pop('id', None)
                if video_id in self.video_map: self.video_map[video_id].update(update)
                self.update_queue.task_done()
            except Exception: break
    def _save_state(self):
        try:
            with open(UPLOAD_STATE_PATH, 'w', encoding='utf-8') as f: json.dump(self.state_data, f, ensure_ascii=False, indent=2)
            self.last_save_time = time.time()
        except IOError as e: logger.error(f"CRITICAL: State Manager failed to save state. Error: {e}")

# -------------------------------
# CORE UPLOAD LOGIC
# --- MODIFIED ---
# -------------------------------
def generate_caption(video_node: Dict) -> str:
    path_parts = Path(video_node.get('localPath', '')).parts
    folder_path = " / ".join(path_parts[:-1])
    video_title = video_node.get('name', 'Unknown File')
    return f"📁 {folder_path}\n\n- 📄 {video_title}"

def upload_file_to_telegram(file_path: Path, caption: str) -> Tuple[bool, Optional[str], Optional[int], Optional[str], Optional[str]]:
    """
    Uploads a file and returns its details for state management.
    
    Returns:
        A tuple containing:
        - success (bool): True if the upload was successful.
        - file_id (Optional[str]): The Telegram file_id for reuse.
        - message_id (Optional[int]): The message ID of the upload.
        - chat_username (Optional[str]): The username of the chat if public.
        - error_message (Optional[str]): A description of the error if failed.
    """
    error_message = "An unknown error occurred."
    for attempt in range(MAX_RETRIES):
        try:
            with open(file_path, 'rb') as f:
                VIDEO_EXTENSIONS = [
                    '.mp4', '.m4v', '.mov', '.mkv', '.avi', '.wmv', '.webm', '.flv', 
                    '.ts', '.3gp', '.vob', '.mpeg', '.mpg', '.ogv', '.rm', '.rmvb', 
                    '.f4v', '.divx', '.mxf', '.asf', '.drc', '.nut', '.roq', '.amv', '.nsv'
                ]

                ext = file_path.suffix.lower()
                url_path = "/sendVideo" if ext in VIDEO_EXTENSIONS else "/sendDocument"
                url = (BASE_URL_TEMPLATE + url_path).format(BOT_TOKEN)
                files = {'video' if url_path == "/sendVideo" else 'document': f}
                params = {'chat_id': CHAT_ID, 'caption': caption}

                is_video = ext in VIDEO_EXTENSIONS
                if "127.0.0.1" in BASE_URL_TEMPLATE and is_video:
                    params['supports_streaming'] = 'true'
                
                response = requests.post(url, files=files, params=params, timeout=600)
                response.raise_for_status()
                data = response.json()

                # --- MODIFIED: Extract all necessary pieces from the response ---
                result = data.get('result', {})
                file_id = result.get('video', {}).get('file_id') or result.get('document', {}).get('file_id')
                message_id = result.get('message_id')
                chat_info = result.get('chat', {})
                chat_username = chat_info.get('username') # e.g., 'nifobry'
                
                return True, file_id, message_id, chat_username, None

        except requests.exceptions.HTTPError as e:
            error_message = str(e)
            if e.response.status_code == 429:
                retry_after = int(e.response.json().get('parameters', {}).get('retry_after', RETRY_DELAY_SECONDS))
                logger.warning(f"Rate limit exceeded. Waiting {retry_after}s...")
                time.sleep(retry_after)
            else:
                logger.warning(f"HTTP Error: {e}. Retrying in {RETRY_DELAY_SECONDS}s... (Attempt {attempt + 1}/{MAX_RETRIES})")
                time.sleep(RETRY_DELAY_SECONDS)
        except KeyboardInterrupt:
            raise
        except Exception as e:
            error_message = f"An unexpected error occurred: {e}"
            logger.error(f"Upload failed for {file_path.name} with critical error: {e}")
            return False, None, None, None, error_message

    return False, None, None, None, f"Max retries ({MAX_RETRIES}) exceeded. Last error: {error_message}"

# -------------------------------
# NEW & REFACTORED FUNCTIONS
# --- MODIFIED ---
# -------------------------------
def get_next_widget_id(nodes: List[Dict]) -> int:
    max_id = 0
    def find_max(sub_nodes: List[Dict]):
        nonlocal max_id
        for node in sub_nodes:
            if node.get('contentType') == 2:
                widget_id = node.get('widget_id')
                if isinstance(widget_id, int) and widget_id > max_id:
                    max_id = widget_id
            elif 'children' in node:
                find_max(node['children'])
    find_max(nodes)
    return max_id + 1 if max_id > 0 else STARTING_WIDGET_ID

def synchronize_states(download_manifest: List[Dict], existing_upload_state: Optional[List[Dict]]) -> List[Dict]:
    if existing_upload_state is None:
        logger.info("No existing upload state found. Creating a fresh one.")
        def create_upload_state(nodes: List[Dict]) -> List[Dict]:
            transformed = []
            for node in nodes:
                new_node = node.copy()
                if new_node.get('contentType') == 2:
                    # --- MODIFIED: Initialize with `tele_message_link` ---
                    new_node.update({'uploadStatus': 'pending', 'telegramFileId': None, 'tele_message_link': None, 'uploadError': None, 'widget_id': None})
                elif 'children' in new_node:
                    new_node['children'] = create_upload_state(new_node['children'])
                transformed.append(new_node)
            return transformed
        return create_upload_state(download_manifest)

    logger.info("Synchronizing download manifest with existing upload state...")
    download_map = {node['id']: node for node in _flatten_tree(download_manifest) if node.get('contentType') == 2}
    upload_map = {node['id']: node for node in _flatten_tree(existing_upload_state) if node.get('contentType') == 2}
    new_videos_found = 0
    
    for video_id, download_node in download_map.items():
        if download_node.get('downloadStatus') == 'completed':
            if video_id not in upload_map:
                new_node = download_node.copy()
                # --- MODIFIED: Initialize with `tele_message_link` ---
                new_node.update({'uploadStatus': 'pending', 'telegramFileId': None, 'tele_message_link': None, 'uploadError': None, 'widget_id': None})
                upload_map[video_id] = new_node
                new_videos_found += 1
            else:
                upload_map[video_id]['downloadStatus'] = 'completed'
                if upload_map[video_id].get('uploadStatus') == 'uploading':
                    logger.warning(f"Found '{upload_map[video_id]['name']}' with 'uploading' status. Resetting to 'pending'.")
                    upload_map[video_id]['uploadStatus'] = 'pending'
    
    if new_videos_found > 0: logger.info(f"✅ Found {new_videos_found} newly downloaded videos to add to the upload queue.")
    else: logger.info("No new videos found. State is already up-to-date.")
    
    return _rebuild_tree_from_map(download_manifest, upload_map)

def _flatten_tree(nodes: List[Dict]) -> List[Dict]:
    flat_list = []
    for node in nodes:
        flat_list.append(node)
        if 'children' in node: flat_list.extend(_flatten_tree(node['children']))
    return flat_list

def _rebuild_tree_from_map(original_structure: List[Dict], upload_map: Dict[Any, Dict]) -> List[Dict]:
    new_tree = []
    for node_struct in original_structure:
        if node_struct.get('contentType') == 2:
            if node_struct['id'] in upload_map: new_tree.append(upload_map[node_struct['id']])
        elif node_struct.get('contentType') == 1:
            new_folder = node_struct.copy()
            if 'children' in new_folder:
                new_folder['children'] = _rebuild_tree_from_map(new_folder['children'], upload_map)
            new_tree.append(new_folder)
    return new_tree

def collect_pending_uploads(nodes: List[Dict]) -> List[Dict]:
    tasks = []
    for node in nodes:
        if node.get('contentType') == 2:
            if node.get('downloadStatus') == 'completed' and node.get('uploadStatus') != 'completed':
                tasks.append(node)
        elif 'children' in node:
            tasks.extend(collect_pending_uploads(node['children']))
    return tasks

# -------------------------------
# MAIN EXECUTION BLOCK
# --- MODIFIED ---
# -------------------------------
if __name__ == '__main__':
    if "YOUR_BOT_TOKEN" in BOT_TOKEN or "YOUR_CHAT_ID" in CHAT_ID:
        logger.critical("❌ Please update BOT_TOKEN and CHAT_ID in the script before running.")
        exit(1)

    logger.info(f"🚀 Starting Sequential Telegram Uploader 🚀")
    
    if not DOWNLOAD_MANIFEST_PATH.exists():
        logger.critical(f"❌ Download manifest '{DOWNLOAD_MANIFEST_PATH}' not found. Run the downloader script first.")
        exit(1)

    with open(DOWNLOAD_MANIFEST_PATH, 'r', encoding='utf-8') as f:
        download_manifest = json.load(f)
    
    existing_upload_state = None
    if UPLOAD_STATE_PATH.exists():
        try:
            with open(UPLOAD_STATE_PATH, 'r', encoding='utf-8') as f:
                existing_upload_state = json.load(f)
        except json.JSONDecodeError:
            logger.error("Could not decode existing upload state. Starting fresh.")
            existing_upload_state = None

    upload_state = synchronize_states(download_manifest, existing_upload_state)
    with open(UPLOAD_STATE_PATH, 'w', encoding='utf-8') as f:
        json.dump(upload_state, f, ensure_ascii=False, indent=2)

    pending_uploads = collect_pending_uploads(upload_state)
    
    if not pending_uploads:
        logger.info("✅ All available files have already been uploaded. Nothing to do.")
        sys.exit(0)

    logger.info(f"Found {len(pending_uploads)} files to upload.")
    logger.info("========= STARTING SEQUENTIAL UPLOAD PROCESS =========")
    
    update_queue = Queue()
    stop_event = Event()
    state_manager = StateManager(upload_state, update_queue, stop_event)
    state_manager.start()
    
    next_widget_id = get_next_widget_id(upload_state)
    logger.info(f"Starting widget ID for this session will be: {next_widget_id}")
    
    video_node_in_progress = None
    
    try:
        pbar = None
        iterator = pending_uploads
        if tqdm:
            pbar = tqdm(pending_uploads, desc="Overall Upload Progress", unit="file", bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}]")
            iterator = pbar
        
        for video_node in iterator:
            video_node_in_progress = video_node
            
            if pbar: 
                pbar.set_description(f"Uploading: {video_node.get('name', '...')[:30]}")

            video_name = video_node.get('name', 'Unknown Video')
            local_path = DOWNLOAD_ROOT_DIR / video_node.get('localPath', '')

            if not local_path.exists():
                logger.error(f"File not found for '{video_name}' at '{local_path}'. Skipping.")
                update_queue.put({'id': video_node['id'], 'uploadStatus': 'failed', 'uploadError': "Local file not found."})
                continue

            update_queue.put({'id': video_node['id'], 'uploadStatus': 'uploading'})
            
            # --- MODIFIED: Unpack new values and build the link ---
            success, file_id, message_id, chat_username, error = upload_file_to_telegram(local_path, generate_caption(video_node))
            
            if success:
                # --- NEW: Robust link construction logic ---
                tele_message_link = None
                if message_id:
                    if chat_username:
                        # For public channels with a username (e.g., @mychannel)
                        tele_message_link = f"https://t.me/{chat_username}/{message_id}"
                    elif str(CHAT_ID).startswith("-100"):
                        # For private channels/supergroups (e.g., -10012345678)
                        chat_id_short = str(CHAT_ID).replace("-100", "")
                        tele_message_link = f"https://t.me/c/{chat_id_short}/{message_id}"
                
                logger.info(f"✅ Successfully uploaded '{video_name}' | Link: {tele_message_link}")
                
                # --- MODIFIED: Add `tele_message_link` to the success update ---
                update_queue.put({
                    'id': video_node['id'],
                    'uploadStatus': 'completed',
                    'uploadError': None,
                    'telegramFileId': file_id,
                    'tele_message_link': tele_message_link,
                    'widget_id': next_widget_id
                })
                next_widget_id += 1
            else:
                logger.error(f"❌ Failed to upload '{video_name}'. Reason: {error}")
                update_queue.put({'id': video_node['id'], 'uploadStatus': 'failed', 'uploadError': str(error)})
            
            video_node_in_progress = None

    except KeyboardInterrupt:
        logger.warning("\n🚨 User interruption (Ctrl+C) detected. Cleaning up...")
        if video_node_in_progress:
            logger.info(f"Marking '{video_node_in_progress.get('name', 'current video')}' as pending for the next run.")
            update_queue.put({
                'id': video_node_in_progress['id'],
                'uploadStatus': 'pending',
                'uploadError': 'Upload interrupted by user.'
            })
    except Exception as e:
        logger.critical(f"An unexpected error occurred in the main loop: {e}", exc_info=True)
        if video_node_in_progress:
            update_queue.put({
                'id': video_node_in_progress['id'],
                'uploadStatus': 'failed',
                'uploadError': f'Critical error during upload: {e}'
            })
    finally:
        logger.info("Upload loop finished or was interrupted. Signalling State Manager to stop.")
        stop_event.set()
        
        logger.info("Waiting up to 2 minutes for final state save...")
        state_manager.join(timeout=120.0) 
        
        if state_manager.is_alive():
            logger.error("🚨 State Manager thread did not finish within the 2-minute timeout. State might be inconsistent.")
        else:
            logger.info("✅ State Manager finished gracefully. Final state saved.")

    logger.info("=========  UPLOAD PROCESS COMPLETE  =========")
    logger.info("🏁 Script finished. 🏁")