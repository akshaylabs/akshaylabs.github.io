"""
High-Performance, Multi-threaded Video Downloader for Classplus Courses.

This script utilizes an advanced concurrency model with a dedicated State Manager
thread and a dynamic worker pool to achieve maximum download performance.

ARCHITECTURE:
- ThreadPoolExecutor (Worker Pool Model): Manages a pool of worker threads. It
  maintains a constant level of concurrency, starting a new download task
  immediately as soon as a previous one finishes, ensuring no idle time. This is
  NOT a batch system.
- Download Workers: Each worker downloads a single video and sends lightweight
  update messages to a queue instead of writing to disk.
- State Manager Thread: A single, dedicated thread that consumes update messages,
  updates the main manifest in memory, and periodically saves the state to disk,
  eliminating I/O bottlenecks and ensuring data integrity.
- Thread-Safe Queue: Ensures safe, fast communication between all threads.
"""
import os
import json
import re
import logging
import time
import subprocess
import shutil
from pathlib import Path
from datetime import datetime
from typing import Optional, List, Dict, Any, Tuple
from concurrent.futures import ThreadPoolExecutor, as_completed
from threading import Thread, Event
from queue import Queue

try:
    import colorlog
except ImportError:
    colorlog = None

try:
    from tqdm import tqdm
except ImportError:
    tqdm = None

# -------------------------------
# CONFIGURATION
# -------------------------------
MAX_CONCURRENT_DOWNLOADS = 10
SAVE_INTERVAL_SECONDS = 5.0

INPUT_DIR = Path('./course_output').resolve()
DOWNLOAD_ROOT_DIR = INPUT_DIR / 'course_downloads'
LINKS_FILE_PATH = INPUT_DIR / 'course_data_with_videos.json'
DOWNLOAD_MANIFEST_PATH = INPUT_DIR / 'download_manifest.json'
LOG_FILE = INPUT_DIR / "video_downloader_log.jsonl"

FFMPEG_CMD = ['ffmpeg', '-y', '-i', '{url}', '-c', 'copy', '-bsf:a', 'aac_adtstoasc', '{output_path}']

# -------------------------------
# ADVANCED LOGGING SETUP
# (Identical to previous versions)
# -------------------------------
class JsonFormatter(logging.Formatter):
    def format(self, record):
        log_object = {
            "timestamp": datetime.fromtimestamp(record.created).isoformat(), "level": record.levelname,
            "message": record.getMessage(), "module": record.module, "funcName": record.funcName,
        }
        return json.dumps(log_object)

def setup_logging():
    INPUT_DIR.mkdir(parents=True, exist_ok=True)
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.INFO)
    root_logger.handlers = []

    if colorlog:
        formatter = colorlog.ColoredFormatter(
            '%(log_color)s[%(asctime)s] %(levelname)-8s%(reset)s | %(message)s', datefmt='%H:%M:%S'
        )
        handler = colorlog.StreamHandler()
    else:
        formatter = logging.Formatter('[%(asctime)s] %(levelname)-8s | %(message)s', datefmt='%H:%M:%S')
        handler = logging.StreamHandler()
    
    handler.setFormatter(formatter)
    root_logger.addHandler(handler)
    file_handler = logging.FileHandler(LOG_FILE, mode='a', encoding='utf-8')
    file_handler.setFormatter(JsonFormatter())
    root_logger.addHandler(file_handler)
    return logging.getLogger(__name__)

logger = setup_logging()

# -------------------------------
# STATE MANAGER CLASS
# -------------------------------
class StateManager(Thread):
    """A dedicated thread to manage manifest state and save it periodically."""
    def __init__(self, manifest: List[Dict], update_queue: Queue, stop_event: Event):
        super().__init__(daemon=True, name="StateManager")
        self.manifest = manifest
        self.video_map = self._create_video_map(self.manifest)
        self.update_queue = update_queue
        self.stop_event = stop_event
        self.last_save_time = time.time()

    def _create_video_map(self, nodes: List[Dict]) -> Dict[Any, Dict]:
        """Creates a flat dictionary for O(1) video node lookups by ID."""
        video_map = {}
        for node in nodes:
            if node.get('contentType') == 2:
                video_map[node['id']] = node
            elif 'children' in node:
                video_map.update(self._create_video_map(node['children']))
        return video_map

    def run(self):
        """The main loop of the state manager."""
        logger.info("🗃️ State Manager thread started.")
        while not self.stop_event.is_set():
            try:
                update_data = self.update_queue.get(timeout=SAVE_INTERVAL_SECONDS)
                video_id = update_data.pop('id', None)
                if video_id in self.video_map:
                    self.video_map[video_id].update(update_data)
                self.update_queue.task_done()
            except Exception: # queue.Empty is the expected timeout exception
                pass
            
            if time.time() - self.last_save_time > SAVE_INTERVAL_SECONDS:
                self._save_state()
        
        self._flush_queue()
        self._save_state()
        logger.info("🗃️ State Manager thread finished and performed final save.")

    def _flush_queue(self):
        """Process any remaining items in the queue before shutting down."""
        while not self.update_queue.empty():
            try:
                update_data = self.update_queue.get_nowait()
                video_id = update_data.pop('id', None)
                if video_id in self.video_map:
                    self.video_map[video_id].update(update_data)
                self.update_queue.task_done()
            except Exception:
                break
    
    def _save_state(self):
        """Save the entire manifest to disk."""
        try:
            with open(DOWNLOAD_MANIFEST_PATH, 'w', encoding='utf-8') as f:
                json.dump(self.manifest, f, ensure_ascii=False, indent=2)
            self.last_save_time = time.time()
        except IOError as e:
            logger.error(f"CRITICAL: State Manager failed to save manifest. Error: {e}")

# -------------------------------
# UTILITY AND DOWNLOAD FUNCTIONS
# -------------------------------
def check_dependencies():
    """Checks for core and optional dependencies."""
    if not shutil.which('ffmpeg') or not shutil.which('ffprobe'):
        logger.critical("❌ FFMPEG/FFPROBE NOT FOUND. Please install and add to your system's PATH.")
        exit(1)
    logger.info("✅ ffmpeg and ffprobe found.")
    if tqdm is None:
        logger.warning("⚠️ TQDM NOT FOUND (run 'pip install tqdm'). Progress bars will be disabled.")
    else:
        logger.info("✅ tqdm found (progress bars enabled).")

# --- NEW FUNCTIONALITY STARTS HERE ---
def _create_source_video_map(nodes: List[Dict]) -> Dict[Any, Dict]:
    """Recursively traverses the source data and creates a flat map of video_id -> video_node."""
    video_map = {}
    for node in nodes:
        if node.get('contentType') == 2 and 'id' in node:
            video_map[node['id']] = node
        if 'children' in node and node['children']:
            video_map.update(_create_source_video_map(node['children']))
    return video_map

def _refresh_manifest_from_source(manifest_nodes: List[Dict], source_map: Dict[Any, Dict]) -> Tuple[int, int]:
    """
    Recursively traverses the manifest, updating nodes with fresh data from the source map.
    Resets 'failed' statuses to 'pending' to allow for retries.
    Returns counts of (updated_nodes, reset_nodes).
    """
    updated_count = 0
    reset_count = 0
    for manifest_node in manifest_nodes:
        # If it's a video, try to update it
        if manifest_node.get('contentType') == 2 and 'id' in manifest_node:
            source_video = source_map.get(manifest_node['id'])
            if source_video:
                # Update volatile data from the new source
                manifest_node['name'] = source_video.get('name', manifest_node['name'])
                manifest_node['finalUrl'] = source_video.get('finalUrl')
                updated_count += 1
                
                # If a download failed previously, reset it to retry with the new URL
                if manifest_node.get('downloadStatus') == 'failed':
                    manifest_node['downloadStatus'] = 'pending'
                    manifest_node['downloadError'] = None
                    reset_count += 1

        # Recurse into children for folders
        if 'children' in manifest_node and manifest_node['children']:
            child_updated, child_reset = _refresh_manifest_from_source(manifest_node['children'], source_map)
            updated_count += child_updated
            reset_count += child_reset
            
    return updated_count, reset_count
# --- NEW FUNCTIONALITY ENDS HERE ---

def get_video_duration(url: str) -> Optional[float]:
    """Uses ffprobe to get video duration."""
    command = ['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'default=noprint_wrappers=1:nokey=1', url]
    try:
        result = subprocess.run(command, capture_output=True, text=True, timeout=30)
        return float(result.stdout.strip()) if result.returncode == 0 and result.stdout.strip() else None
    except Exception: return None

def download_video_with_progress(url: str, output_path: Path, position: int) -> Tuple[bool, Optional[str]]:
    """Downloads a video, showing a progress bar."""
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    if tqdm is None:
        logger.info(f"Downloading '{output_path.name}'...")
        command = ['ffmpeg', '-y', '-i', url, '-c', 'copy', '-bsf:a', 'aac_adtstoasc', '-loglevel', 'error', str(output_path)]
        process = subprocess.run(command, capture_output=True, text=True, encoding='utf-8', errors='replace')
        return (True, None) if process.returncode == 0 else (False, f"ffmpeg exited with code {process.returncode}.")

    duration = get_video_duration(url)
    command = ['ffmpeg', '-y', '-i', url, '-c', 'copy', '-bsf:a', 'aac_adtstoasc', str(output_path)]
    process = subprocess.Popen(command, stderr=subprocess.PIPE, universal_newlines=True, encoding='utf-8', errors='replace')
    assert process.stderr is not None

    pbar_opts = {"unit": "s", "unit_scale": True, "dynamic_ncols": True, "position": position, "leave": False, "desc": output_path.name[:35].ljust(35)}
    pbar = tqdm(total=duration, **pbar_opts) if duration else tqdm(unit="B", unit_scale=True, **pbar_opts)
    
    last_time = 0.0
    with pbar:
        for line in process.stderr:
            if duration:
                match = re.search(r"time=(\d{2}):(\d{2}):(\d{2})\.(\d{2})", line)
                if match:
                    h, m, s, ms = map(int, match.groups())
                    current_time = h * 3600 + m * 60 + s + ms / 100
                    pbar.update(current_time - last_time)
                    last_time = current_time
            else:
                match = re.search(r"size=\s*(\d+)", line)
                if match:
                    pbar.n = int(match.group(1)) * 1024; pbar.refresh()
    
    process.wait()
    if process.returncode == 0:
        if duration: pbar.n = duration; pbar.refresh()
        return True, None
    else:
        return False, f"ffmpeg exited with code {process.returncode}."

def download_worker(video_node: Dict, update_queue: Queue, position: int):
    """The function executed by each thread. Downloads one video."""
    video_name = video_node.get('name', 'Unknown Video')
    local_path = DOWNLOAD_ROOT_DIR / video_node.get('localPath', '')
    final_url = video_node.get('finalUrl')

    if not final_url:
        update_queue.put({'id': video_node['id'], 'downloadStatus': 'failed', 'downloadError': "URL not available."})
    else:
        update_queue.put({'id': video_node['id'], 'downloadStatus': 'downloading'})
        success, error = download_video_with_progress(final_url, local_path, position)
        
        if success:
            update_queue.put({'id': video_node['id'], 'downloadStatus': 'completed', 'downloadError': None})
        else:
            logger.error(f"Failed to download '{video_name}'. Reason: {error}")
            update_queue.put({'id': video_node['id'], 'downloadStatus': 'failed', 'downloadError': str(error)})

def collect_pending_videos(nodes: List[Dict]) -> List[Dict]:
    """Recursively finds all videos that need downloading."""
    tasks = []
    for node in nodes:
        if node.get('contentType') == 2:
            local_path = DOWNLOAD_ROOT_DIR / node.get('localPath', '')
            if node.get('downloadStatus') != 'completed' or not local_path.exists():
                tasks.append(node)
        elif 'children' in node:
            tasks.extend(collect_pending_videos(node['children']))
    return tasks

# -------------------------------
# MAIN EXECUTION BLOCK
# -------------------------------
if __name__ == '__main__':
    check_dependencies()
    logger.info(f"🚀 Starting High-Performance Downloader (up to {MAX_CONCURRENT_DOWNLOADS} concurrent downloads) 🚀")
    
    if not LINKS_FILE_PATH.exists():
        logger.critical(f"❌ Input file '{LINKS_FILE_PATH}' not found. Run the link fetcher script first.")
        exit(1)

    with open(LINKS_FILE_PATH, 'r', encoding='utf-8') as f:
        link_data = json.load(f)

    if DOWNLOAD_MANIFEST_PATH.exists():
        logger.info("Found existing download manifest. Resuming and refreshing session...")
        with open(DOWNLOAD_MANIFEST_PATH, 'r', encoding='utf-8') as f:
            download_manifest = json.load(f)
        
        # --- MODIFIED BLOCK STARTS HERE ---
        logger.info("Creating a map from the source data to find updates...")
        source_video_map = _create_source_video_map(link_data)
        
        logger.info("Refreshing manifest with latest URLs and resetting failed downloads...")
        updated, reset = _refresh_manifest_from_source(download_manifest, source_video_map)
        logger.info(f"✅ Refresh complete. Updated data for {updated} videos. Reset {reset} failed downloads for retry.")
        # --- MODIFIED BLOCK ENDS HERE ---

    else:
        logger.info("No download manifest found. Creating one from the links file.")
        def create_manifest(nodes: List[Dict], current_path=Path()) -> List[Dict]:
            transformed_nodes = []
            for node in nodes:
                new_node = node.copy()
                if new_node.get('contentType') == 2:
                    sanitized_name = re.sub(r'[<>:"/\\|?*]', '_', new_node.get('name', 'untitled_video')).strip()
                    new_node.update({'downloadStatus': 'pending', 'localPath': str(current_path / f"{sanitized_name}.mp4"), 'downloadError': None})
                elif new_node.get('contentType') == 1:
                    sanitized_name = re.sub(r'[<>:"/\\|?*]', '_', new_node.get('name', 'untitled_folder')).strip()
                    if 'children' in new_node:
                        new_node['children'] = create_manifest(new_node['children'], current_path / sanitized_name)
                transformed_nodes.append(new_node)
            return transformed_nodes
        
        download_manifest = create_manifest(link_data)
        with open(DOWNLOAD_MANIFEST_PATH, 'w', encoding='utf-8') as f:
            json.dump(download_manifest, f, ensure_ascii=False, indent=2)

    pending_videos = collect_pending_videos(download_manifest)
    
    if not pending_videos:
        logger.info("✅ All videos are already downloaded. Nothing to do.")
    else:
        logger.info(f"Found {len(pending_videos)} videos to download.")
        logger.info("========= STARTING DOWNLOAD PROCESS =========")
        
        update_queue = Queue()
        stop_event = Event()
        state_manager = StateManager(download_manifest, update_queue, stop_event)
        state_manager.start()
        
        try:
            # The ThreadPoolExecutor manages a queue of tasks and a pool of worker threads.
            # It will automatically start the next task as soon as a worker thread becomes free,
            # ensuring a constant level of concurrency.
            with ThreadPoolExecutor(max_workers=MAX_CONCURRENT_DOWNLOADS, thread_name_prefix="Downloader") as executor:
                # Submit all pending videos to the executor's queue.
                # The executor will start the first MAX_CONCURRENT_DOWNLOADS immediately.
                futures = {
                    executor.submit(download_worker, video_node, update_queue, i + 1): video_node
                    for i, video_node in enumerate(pending_videos)
                }
                
                pbar_opts = {"total": len(pending_videos), "desc": "Overall Progress", "unit": "video", "position": 0}
                pbar = tqdm(**pbar_opts) if tqdm else None
                
                # as_completed() yields futures as they finish, allowing the main thread
                # to update progress without waiting for all tasks to complete.
                for future in as_completed(futures):
                    if pbar: pbar.update(1)
                
                if pbar: pbar.close()

        finally:
            logger.info("All download tasks submitted. Waiting for state manager to perform final save...")
            stop_event.set()
            state_manager.join() # Wait for the state manager thread to finish completely

    logger.info("=========  DOWNLOAD PROCESS COMPLETE  =========")
    logger.info("🏁 Script finished. 🏁")