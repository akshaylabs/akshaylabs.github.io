#!/usr/bin/env python3
"""
Video Pipeline Dashboard
------------------------
Single-page Gradio (3.x) control panel that:
  • Schedules and runs a 3-step video pipeline (fetch -> download -> upload)
  • Runs immediately, then every N hours (user-configurable; default 14)
  • Allows manual one-shot runs
  • Cleanly stops scripts (Ctrl+C -> terminate -> kill)
  • Tracks success/fail/aborted counters
  • Shows colored status, uptime, next run time
  • Separates app logs vs subprocess logs
  • Auto-refresh + manual refresh for status & logs
  • Token management (masked reveal; update .env)
  • Compact / Expanded log view toggle
  • Light / Dark theme toggle (CSS class swap)
"""

import os
import sys
import time
import signal
import logging
import threading
import subprocess
from datetime import datetime, timedelta
from typing import List, Optional, Tuple

import gradio as gr
from dotenv import load_dotenv

# =============================================================================
# Configuration Defaults
# =============================================================================
DEFAULT_INTERVAL_HOURS = 14
SCRIPTS: List[str] = ["/teamspace/studios/this_studio/video_av_chemistry_classes/fetch_videos.py",
    "/teamspace/studios/this_studio/video_av_chemistry_classes/download_videos.py",
    "/teamspace/studios/this_studio/video_av_chemistry_classes/upload_video_v3.py"]

# Separate log files for app + subprocess output
APP_LOG_FILE = "app.log"
SUBPROCESS_LOG_FILE = "subprocess.log"
ENV_FILE = ".env"

GRACE_SHUTDOWN_SECONDS = 5          # After Ctrl+C before escalate
MAX_LOG_LINES_APP = 1500            # Tail lines app log
MAX_LOG_LINES_SUB = 1500            # Tail lines subprocess log
MAX_LOG_LINES_APP_COMPACT = 400     # Compact mode tail
MAX_LOG_LINES_SUB_COMPACT = 400     # Compact mode tail

# =============================================================================
# Environment
# =============================================================================
load_dotenv()  # Load ACCESS_TOKEN etc.


# =============================================================================
# Logging (App)
# =============================================================================
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] [App] %(message)s",
    handlers=[
        logging.FileHandler(APP_LOG_FILE, mode="a", encoding="utf-8", delay=False),
        logging.StreamHandler(sys.stdout),
    ],
    force=True,
)
logger = logging.getLogger(__name__)


def _flush_log_handlers() -> None:
    """Flush all log handlers so UI sees newest entries quickly."""
    for h in logger.handlers:
        try:
            h.flush()
        except Exception:
            pass


# =============================================================================
# Global State
# =============================================================================
periodic_enabled = False                  # True when Start pressed
stop_event = threading.Event()            # Signal to stop periodic wait

exec_lock = threading.Lock()              # Serialize pipeline runs
exec_in_progress = False                  # True while scripts executing

last_status = "Idle"                      # Human-readable pipeline state
last_run_time: Optional[str] = None       # Timestamp string of last start
next_run_time: Optional[datetime] = None  # When periodic will next fire
start_time: Optional[datetime] = None     # When current run started

current_processes: List[subprocess.Popen] = []  # Track live subprocesses
progress_details = ""                     # Step indicator text

# History counters
run_success_count = 0
run_failure_count = 0
run_aborted_count = 0
run_skipped_count = 0                     # Counter for skipped scripts
skip_current_script_event = threading.Event() # Signal to skip current script

# Dynamic schedule interval (user-set)
interval_hours_lock = threading.Lock()
_interval_hours = DEFAULT_INTERVAL_HOURS   # internal; use getter/setter


def get_interval_hours() -> int:
    with interval_hours_lock:
        return _interval_hours


def set_interval_hours(hours: int) -> None:
    global _interval_hours
    with interval_hours_lock:
        _interval_hours = max(1, min(24 * 7, int(hours)))  # clamp 1h..168h
    logger.info(f"Interval updated to {_interval_hours} hours.")
    _flush_log_handlers()


# =============================================================================
# Subprocess Log Streaming Support
# =============================================================================
# We stream each subprocess's stdout/stderr to SUBPROCESS_LOG_FILE in real time
# via a background thread reading from pipes. This improves log freshness.

def _stream_pipe_to_file(pipe, prefix: str, fh, stop_flag: threading.Event):
    """
    Read lines from a subprocess pipe and write them to the shared subprocess log.
    Stops when pipe EOF or stop_flag set.
    """
    try:
        for line in iter(pipe.readline, ''):
            if not line:
                break
            ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            fh.write(f"{ts} [{prefix}] {line}")
            fh.flush()
            if stop_flag.is_set():
                break
    except Exception as e:
        fh.write(f"\n--- STREAM ERROR [{prefix}]: {e} ---\n")
        fh.flush()


# =============================================================================
# Helper Functions
# =============================================================================
def _update_status(msg: str) -> None:
    """Update global status and log it to the app log."""
    global last_status
    last_status = msg
    logger.info(f"Status changed: {msg}")
    _flush_log_handlers()


def _format_ts(dt: Optional[datetime] = None) -> str:
    return (dt or datetime.now()).strftime("%Y-%m-%d %H:%M:%S")


def _append_process(proc: subprocess.Popen) -> None:
    current_processes.append(proc)


def _remove_process(proc: subprocess.Popen) -> None:
    try:
        current_processes.remove(proc)
    except ValueError:
        pass


def _send_ctrl_c(proc: subprocess.Popen) -> None:
    """Best-effort Ctrl+C / SIGINT across platforms."""
    try:
        if os.name == "nt":
            # CTRL_BREAK_EVENT is more forceful and affects the whole process group
            proc.send_signal(signal.CTRL_BREAK_EVENT)
        else:
            # SIGINT is the equivalent of Ctrl+C on Unix-like systems
            proc.send_signal(signal.SIGINT)
    except Exception as e:
        logger.error(f"Error sending interrupt to PID {proc.pid}: {e}")


def _terminate_process(proc: subprocess.Popen) -> None:
    try:
        proc.terminate()
    except Exception as e:
        logger.error(f"Error terminating PID {proc.pid}: {e}")


def _kill_process(proc: subprocess.Popen) -> None:
    try:
        proc.kill()
    except Exception as e:
        logger.error(f"Error killing PID {proc.pid}: {e}")


def _stop_all_processes() -> None:
    """Send Ctrl+C to all running scripts; escalate if still alive."""
    procs = current_processes[:]
    if not procs:
        return

    logger.info("Sending Ctrl+C to running scripts...")
    for p in procs:
        _send_ctrl_c(p)

    deadline = time.time() + GRACE_SHUTDOWN_SECONDS
    while time.time() < deadline and any(p.poll() is None for p in procs):
        time.sleep(0.2)

    lingering = [p for p in procs if p.poll() is None]
    if lingering:
        logger.warning("Processes did not exit after Ctrl+C; terminating...")
        for p in lingering:
            _terminate_process(p)
        time.sleep(2)  # Give terminate a moment to take effect
        still = [p for p in lingering if p.poll() is None]
        if still:
            logger.error("Force killing stubborn processes...")
            for p in still:
                _kill_process(p)
    _flush_log_handlers()


# =============================================================================
# Log Reading
# =============================================================================
def _tail_log_lines(path: str, max_lines: int) -> str:
    """Return tail of file (up to max_lines)."""
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            lines = f.readlines()
    except FileNotFoundError:
        return f"Log file not found: {path}"
    if max_lines is not None and max_lines > 0 and len(lines) > max_lines:
        lines = lines[-max_lines:]
    return "".join(lines).rstrip()


# =============================================================================
# Script / Pipeline Execution
# =============================================================================
def run_script(script_name: str, step: int, total_steps: int) -> str:
    """
    Run a script; live-stream its output to SUBPROCESS_LOG_FILE.
    Returns a status string: 'SUCCESS', 'FAILURE', 'SKIPPED', 'ABORTED'.
    """
    global progress_details
    _update_status(f"Running: {script_name}")
    progress_details = f"Step {step}/{total_steps}: {script_name}"
    logger.info(f"Starting script: {script_name}")

    proc = None
    rc = None
    stop_flag = threading.Event()
    return_status = 'FAILURE' # Default to failure

    try:
        log_header = (
            f"\n{'='*22} {script_name} START { _format_ts() } {'='*22}\n"
        )
        with open(SUBPROCESS_LOG_FILE, "a", encoding="utf-8") as subfh:
            subfh.write(log_header)
            subfh.flush()

        proc = subprocess.Popen(
            [sys.executable, script_name],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding='utf-8',
            errors='replace',
            bufsize=1,
            creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name == "nt" else 0,
        )
        _append_process(proc)

        def _stream_wrapper():
            with open(SUBPROCESS_LOG_FILE, "a", encoding="utf-8") as subfh:
                _stream_pipe_to_file(proc.stdout, script_name, subfh, stop_flag)

        t_stream = threading.Thread(target=_stream_wrapper, daemon=True)
        t_stream.start()

        while True:
            rc = proc.poll()
            if rc is not None:
                break
            if skip_current_script_event.is_set():
                logger.warning(f"Skipping script (requested): {script_name}")
                _send_ctrl_c(proc) # Attempt graceful stop
                return_status = 'SKIPPED'
                break # Exit poll loop to handle cleanup
            if not exec_in_progress:
                return_status = 'ABORTED'
                break # Interrupted by main stop signal
            time.sleep(0.2)

        if rc is None: # Interrupted by skip or abort
            try:
                proc.wait(timeout=GRACE_SHUTDOWN_SECONDS)
            except subprocess.TimeoutExpired:
                _terminate_process(proc)
            rc = proc.poll()

        stop_flag.set()
        t_stream.join(timeout=2)

        # Determine final status only if not already set by an event
        if return_status not in ('SKIPPED', 'ABORTED'):
            if rc == 0:
                return_status = 'SUCCESS'
            else:
                return_status = 'FAILURE'

        log_footer = f"\n{'-'*22} {script_name} END (rc={rc}, status={return_status}) { _format_ts() } {'-'*22}\n"
        with open(SUBPROCESS_LOG_FILE, "a", encoding="utf-8") as subfh:
            subfh.write(log_footer)
            subfh.flush()

    except Exception as e:
        logger.error(f"Failed to start or monitor script {script_name}: {e}")
        return_status = 'FAILURE'
    finally:
        if proc:
            _remove_process(proc)
        if return_status == 'SKIPPED':
             skip_current_script_event.clear() # Reset event for next run

    if return_status == 'SUCCESS':
        logger.info(f"Completed script: {script_name}")
    else:
        logger.error(f"Script {script_name} finished with status: {return_status}, exit code: {rc}")

    _flush_log_handlers()
    return return_status


def run_pipeline() -> Tuple[bool, str]:
    """
    Run the full pipeline. Returns (success_bool, reason_string).
    reason = script name that failed OR "ABORTED".
    """
    global last_run_time, progress_details, run_skipped_count
    last_run_time = _format_ts()
    progress_details = "Starting pipeline..."
    total_steps = len(SCRIPTS)

    for idx, script in enumerate(SCRIPTS, start=1):
        if not exec_in_progress:
            _update_status("Stopped")
            progress_details = f"Aborted before step {idx}/{total_steps}"
            return False, "ABORTED"

        status = run_script(script, idx, total_steps)

        if status == 'SUCCESS':
            continue
        elif status == 'SKIPPED':
            run_skipped_count += 1
            progress_details = f"Skipped step {idx}/{total_steps}"
            continue # Move to the next script
        elif status == 'ABORTED':
            _update_status("Stopped")
            progress_details = f"Aborted during step {idx}/{total_steps}"
            return False, "ABORTED"
        else: # 'FAILURE'
            _update_status(f"Failed on {script}")
            progress_details = f"Error at step {idx}/{total_steps}"
            return False, script

    _update_status("Completed")
    progress_details = "Pipeline finished successfully."
    return True, ""


def _pipeline_exec_wrapper():
    """
    Acquire lock, run pipeline, update counters.
    """
    global exec_in_progress, start_time, progress_details
    global run_success_count, run_failure_count, run_aborted_count

    with exec_lock:
        exec_in_progress = True
        start_time = datetime.now()
        try:
            success, reason = run_pipeline()
            if success:
                run_success_count += 1
            elif reason == "ABORTED":
                run_aborted_count += 1
            else:
                run_failure_count += 1
        finally:
            exec_in_progress = False
            start_time = None
            progress_details = ""
            _flush_log_handlers()


def periodic_runner():
    """
    Background loop for scheduled runs. Uses current interval_hours value.
    """
    global next_run_time
    while periodic_enabled:
        _pipeline_exec_wrapper()
        if not periodic_enabled:
            break

        hours = get_interval_hours()
        next_run_time = datetime.now() + timedelta(hours=hours)
        _update_status(f"Waiting {hours}h for next run...")
        stop_event.wait(timeout=hours * 3600)
        if stop_event.is_set():
            break


# =============================================================================
# UI Callback Functions
# =============================================================================
def start_pipeline_cb():
    """Start schedule (immediate run + interval repeats)."""
    global periodic_enabled, next_run_time
    if periodic_enabled:
        return "Pipeline is already scheduled."
    periodic_enabled = True
    stop_event.clear()
    next_run_time = None  # Will be set after first run completes
    threading.Thread(target=periodic_runner, daemon=True).start()
    return "Schedule started. Running now, then repeating."


def stop_pipeline_cb():
    """Stop schedule + interrupt running scripts."""
    global periodic_enabled, exec_in_progress, next_run_time
    if not periodic_enabled and not exec_in_progress:
        return "Nothing to stop."
    was_active = periodic_enabled or exec_in_progress
    periodic_enabled = False
    next_run_time = None
    stop_event.set()
    if exec_in_progress:
        exec_in_progress = False
        _stop_all_processes()
    _update_status("Stopped")
    return "Stop signal sent; scripts interrupted." if was_active else "Already stopped."


def skip_script_cb():
    """Signal the current script to stop and the pipeline to continue."""
    if not exec_in_progress:
        return "Cannot skip: no pipeline is currently running."
    skip_current_script_event.set()
    return "Skip signal sent. The current script will be terminated."


def run_now_cb():
    """Manual one-shot run."""
    if exec_in_progress:
        return "Pipeline is already running. Please wait or stop it first."
    threading.Thread(target=_pipeline_exec_wrapper, daemon=True).start()
    return "Manual run triggered."


# ----- UI status coloring + details -----
def get_status_html():
    status = last_status
    if status in ("Completed", "Idle"):
        color = "limegreen"
    elif status.startswith("Waiting"):
        color = "goldenrod"
    elif status.startswith("Running"):
        color = "orangered"
    else:
        # Failed / Stopped / other
        color = "red"

    uptime_str = ""
    if start_time:
        delta = datetime.now() - start_time
        mins, secs = divmod(int(delta.total_seconds()), 60)
        uptime_str = f" | Uptime: {mins}m {secs}s"

    counters_str = (
        f"Runs: ✔️{run_success_count}  ❌{run_failure_count}  ⏹️{run_aborted_count}  ⏭️{run_skipped_count}"
    )
    next_run_str = (
        f"Next Scheduled Run: {_format_ts(next_run_time)}"
        if next_run_time
        else "Next Scheduled Run: —"
    )

    html = f"""
    <div class="status-wrapper">
        <div class="status-line">
            <span class="status-dot" style="color:{color}">●</span>
            <span class="status-text" style="color:{color};font-weight:bold;">{status}</span>
        </div>
        <div class="status-progress"><strong>{progress_details}</strong></div>
        <div class="status-meta">
            <div>Last Run Start: {last_run_time or 'Never'}{uptime_str}</div>
            <div>{next_run_str}</div>
            <div>{counters_str}</div>
        </div>
    </div>
    """
    return html


# ----- Logs -----
def show_app_logs_cb(max_lines: Optional[int] = None):
    _flush_log_handlers()
    return _tail_log_lines(APP_LOG_FILE, max_lines or MAX_LOG_LINES_APP)


def show_subprocess_logs_cb(max_lines: Optional[int] = None):
    return _tail_log_lines(SUBPROCESS_LOG_FILE, max_lines or MAX_LOG_LINES_SUB)


# Combined refresh (status + logs)
def refresh_all_ui_cb(compact: bool):
    _flush_log_handlers()
    max_app = MAX_LOG_LINES_APP_COMPACT if compact else MAX_LOG_LINES_APP
    max_sub = MAX_LOG_LINES_SUB_COMPACT if compact else MAX_LOG_LINES_SUB
    return get_status_html(), show_app_logs_cb(max_app), show_subprocess_logs_cb(max_sub)


# ----- Token Management -----
def _mask_token(token: str) -> str:
    if not token:
        return "No ACCESS_TOKEN set."
    if len(token) <= 4:
        return "*" * len(token)
    return "*" * (len(token) - 4) + token[-4:]


def get_current_token_cb(reveal: bool):
    token = os.getenv("ACCESS_TOKEN")
    if not token:
        return "No ACCESS_TOKEN is set in the environment."
    return token if reveal else _mask_token(token)


def update_token_cb(new_token: str):
    if not new_token or not new_token.strip():
        return "Token cannot be empty!", gr.update()
    # basic sanitation
    if any(char in new_token for char in ('\n', '\r', '"', "'")):
        return "Token contains invalid characters.", gr.update()

    lines = []
    if os.path.exists(ENV_FILE):
        with open(ENV_FILE, "r", encoding="utf-8") as f:
            lines = f.readlines()

    updated = False
    for i, line in enumerate(lines):
        if line.strip().startswith("ACCESS_TOKEN="):
            lines[i] = f"ACCESS_TOKEN={new_token.strip()}\n"
            updated = True
            break
    if not updated:
        lines.append(f"\nACCESS_TOKEN={new_token.strip()}\n")

    try:
        with open(ENV_FILE, "w", encoding="utf-8") as f:
            f.writelines(lines)
    except Exception as e:
        logger.error(f"Failed writing .env: {e}")
        _flush_log_handlers()
        return f"Error writing .env: {e}", gr.update()

    os.environ["ACCESS_TOKEN"] = new_token.strip()
    logger.info("ACCESS_TOKEN updated via UI.")
    _flush_log_handlers()
    # On success, update the token display to show the new masked token
    return "Token updated. Will be used on next run.", get_current_token_cb(False)


# ----- Interval Management -----
def apply_interval_cb(hours: float):
    set_interval_hours(int(hours))
    return f"Interval set to {int(hours)} hour(s)."


# ----- Button Interactivity Control -----
def ui_interactivity_state() -> Tuple[bool, bool, bool, bool]:
    """
    Returns tuple: (start_enabled, stop_enabled, run_now_enabled, skip_enabled)
    """
    # start disabled if schedule active or currently running
    start_enabled = not periodic_enabled and not exec_in_progress
    # stop enabled if schedule active or running
    stop_enabled = periodic_enabled or exec_in_progress
    # run_now enabled if not running (schedule allowed; it just triggers run if idle)
    run_now_enabled = not exec_in_progress
    # skip enabled ONLY when a script is actively executing
    skip_enabled = exec_in_progress
    return start_enabled, stop_enabled, run_now_enabled, skip_enabled


def make_control_updates() -> Tuple[gr.Button, gr.Button, gr.Button, gr.Button]:
    s, p, r, k = ui_interactivity_state()
    return (
        gr.Button(interactive=s),
        gr.Button(interactive=p),
        gr.Button(interactive=r),
        gr.Button(interactive=k),
    )


# Combined master refresh returns: status_html, app_logs, sub_logs, start_upd, stop_upd, run_upd
def master_refresh_cb(compact: bool):
    """Full refresh; used for auto-refresh and big 'Refresh All' button."""
    status_html, app_logs, sub_logs = refresh_all_ui_cb(compact)
    start_upd, stop_upd, run_upd, skip_upd = make_control_updates()
    return status_html, app_logs, sub_logs, start_upd, stop_upd, run_upd, skip_upd


# =============================================================================
# Gradio UI
# =============================================================================
DARK_CSS = """
gradio-app.dark {
    background-color: #0f1117 !important;
    color: #e5e5e5 !important;
}
gradio-app.dark .gr-button {
    border-color: #555 !important;
    background: #232630 !important;
    color: #e5e5e5 !important;
}
gradio-app.dark .gr-button.primary {
    background: #f97316 !important;
    color: white !important;
}
gradio-app.dark .gr-button.stop {
    background: #dc2626 !important;
    color: white !important;
}
gradio-app.dark textarea, gradio-app.dark input {
    background: #1c1f2b !important;
    color: #e5e5e5 !important;
    border-color: #444 !important;
}
gradio-app.dark .status-meta { color: #9ca3af !important; }
gradio-app.dark .gr-box { background-color: #1a1d25 !important; border-color: #333 !important;}
gradio-app.dark .gr-panel { background-color: #1a1d25 !important; border-color: #333 !important;}
"""

CUSTOM_CSS = """
.status-wrapper { line-height:1.4; }
.status-line { font-size:1.2em; margin-bottom:4px; }
.status-dot { margin-right:4px; }
.status-meta { font-size:0.9em; color:#555; }
.log-box textarea {
    font-family: 'SF Mono','Consolas','Menlo',monospace !important;
    font-size:12px !important;
    line-height:1.3 !important;
    white-space:pre !important;
}
.compact-mode textarea { height: 150px !important; }
.expanded-mode textarea { height: 400px !important; }
""" + DARK_CSS


with gr.Blocks(
    title="Video Pipeline Dashboard",
    theme=gr.themes.Soft(
        primary_hue="orange",
        secondary_hue="blue",
    ),
    css=CUSTOM_CSS,
) as demo:
    # State object to track compact view toggle across callbacks
    compact_state = gr.State(value=False)

    gr.Markdown("# 🎥 Video Processing Pipeline Dashboard")
    gr.Markdown(
        "Control scheduled runs, trigger manual runs, manage the access token, and monitor live logs.<br>"
        "Auto-refresh every 5s; use the 'Refresh All' button for an instant update."
    )

    # Global toggles row
    with gr.Row():
        compact_toggle = gr.Checkbox(label="Compact log view", value=False)
        dark_toggle = gr.Checkbox(label="Dark mode", value=False)

    # Controls + Status + Token left; Logs right
    with gr.Row(variant="panel"):
        # LEFT COLUMN
        with gr.Column(scale=1):
            with gr.Group():
                gr.Markdown("### ⚡ Controls")
                with gr.Row():
                    start_btn = gr.Button("▶ Start Schedule", variant="primary")
                    stop_btn = gr.Button("⏹️ Stop All", variant="stop")
                    run_btn = gr.Button("🚀 Run Now", variant="secondary")
                    skip_btn = gr.Button("⏭️ Skip Step", variant="secondary")

                control_feedback = gr.Textbox(label="Action Status", interactive=False, lines=1)

                gr.Markdown("**Schedule Interval (hours)**")
                interval_slider = gr.Slider(
                    minimum=1, maximum=168, step=1, value=DEFAULT_INTERVAL_HOURS, label="Hours Between Runs",
                )
                apply_interval_btn = gr.Button("Apply Interval")

            with gr.Group():
                gr.Markdown("### 📊 Pipeline Status")
                status_html = gr.HTML(value=get_status_html)

            with gr.Group():
                gr.Markdown("### 🔑 ACCESS_TOKEN Management")
                token_input = gr.Textbox(label="New ACCESS_TOKEN", type="password", placeholder="Enter new token and update")
                token_btn = gr.Button("Update Token")
                token_update_status = gr.Textbox(label="Token Update Status", interactive=False, lines=1)

                token_display = gr.Textbox(label="Current Token", value=get_current_token_cb(False), interactive=False)
                reveal_token_chk = gr.Checkbox(label="Reveal current token value", value=False)


        # RIGHT COLUMN
        with gr.Column(scale=2):
            gr.Markdown("### 📜 Logs")
            refresh_all_btn = gr.Button("🔄 Refresh All (Status + Logs)", variant="secondary")

            with gr.Group():
                gr.Markdown("#### Application Logs (Dashboard)")
                app_logs_box = gr.Textbox(
                    label=f"Displaying tail of {APP_LOG_FILE}",
                    interactive=False,
                    lines=15, # Initial line count, CSS will control height
                    elem_classes=["log-box", "expanded-mode"],
                )

            with gr.Group():
                gr.Markdown("#### Subprocess Logs (Pipeline Scripts)")
                subprocess_logs_box = gr.Textbox(
                    label=f"Displaying tail of {SUBPROCESS_LOG_FILE}",
                    interactive=False,
                    lines=15, # Initial line count, CSS will control height
                    elem_classes=["log-box", "expanded-mode"],
                )

    # -------------------------------------------------------------------------
    # UI Updates & Bindings
    # -------------------------------------------------------------------------

    # Theme and View Toggles
    def _set_dark_mode_js(is_dark):
        """Generates JS to toggle a 'dark' class on the root Gradio element."""
        dark_class_js = "document.querySelector('gradio-app').classList.add('dark');"
        light_class_js = "document.querySelector('gradio-app').classList.remove('dark');"
        js_code = dark_class_js if is_dark else light_class_js
        return f"<script>{js_code}</script>"

    dark_mode_html = gr.HTML(visible=False)
    dark_toggle.change(_set_dark_mode_js, inputs=dark_toggle, outputs=dark_mode_html)

    def toggle_compact_view_cb(is_compact):
        """Updates log boxes' CSS class and content for compact/expanded view."""
        classes = ["log-box", "compact-mode" if is_compact else "expanded-mode"]
        max_app = MAX_LOG_LINES_APP_COMPACT if is_compact else MAX_LOG_LINES_APP
        max_sub = MAX_LOG_LINES_SUB_COMPACT if is_compact else MAX_LOG_LINES_SUB
        app_content = show_app_logs_cb(max_app)
        sub_content = show_subprocess_logs_cb(max_sub)
        return (
            is_compact,
            gr.Textbox(elem_classes=classes, value=app_content),
            gr.Textbox(elem_classes=classes, value=sub_content)
        )

    compact_toggle.change(
        fn=toggle_compact_view_cb,
        inputs=compact_toggle,
        outputs=[compact_state, app_logs_box, subprocess_logs_box],
    )

    # Control Buttons
    apply_interval_btn.click(apply_interval_cb, inputs=interval_slider, outputs=control_feedback)

    start_btn.click(start_pipeline_cb, outputs=control_feedback).then(
        master_refresh_cb, inputs=compact_state,
        outputs=[status_html, app_logs_box, subprocess_logs_box, start_btn, stop_btn, run_btn, skip_btn]
    )
    stop_btn.click(stop_pipeline_cb, outputs=control_feedback).then(
        master_refresh_cb, inputs=compact_state,
        outputs=[status_html, app_logs_box, subprocess_logs_box, start_btn, stop_btn, run_btn, skip_btn]
    )
    run_btn.click(run_now_cb, outputs=control_feedback).then(
        master_refresh_cb, inputs=compact_state,
        outputs=[status_html, app_logs_box, subprocess_logs_box, start_btn, stop_btn, run_btn, skip_btn]
    )
    # Add the click handler for the new skip button
    skip_btn.click(skip_script_cb, outputs=control_feedback).then(
        master_refresh_cb, inputs=compact_state,
        outputs=[status_html, app_logs_box, subprocess_logs_box, start_btn, stop_btn, run_btn, skip_btn]
    )


    # Refresh Button
    refresh_all_btn.click(
        master_refresh_cb, inputs=compact_state,
        outputs=[status_html, app_logs_box, subprocess_logs_box, start_btn, stop_btn, run_btn, skip_btn]
    )

    # Token Management
    def _update_and_clear_token_input(new_token):
        msg, new_display_val = update_token_cb(new_token)
        return msg, "", new_display_val

    token_btn.click(
        _update_and_clear_token_input,
        inputs=token_input,
        outputs=[token_update_status, token_input, token_display]
    )

    reveal_token_chk.change(
        fn=get_current_token_cb,
        inputs=reveal_token_chk,
        outputs=token_display
    )

    # -------------------------------------------------------------------------
    # Global Auto-Refresh Loop
    # -------------------------------------------------------------------------
    # demo.load(
    #     fn=master_refresh_cb,
    #     inputs=compact_state,
    #     outputs=[status_html, app_logs_box, subprocess_logs_box, start_btn, stop_btn, run_btn],
    #     every=5,
    # )

# =============================================================================
# Global Auto-Refresh Loop (Correct for Gradio 4.x and newer)
# =============================================================================
# In modern Gradio, timers are handled by the gr.Timer component.

# 1. Run the master refresh function ONCE when the UI loads to populate it.
    demo.load(
        fn=master_refresh_cb,
        inputs=[compact_state],
        outputs=[status_html, app_logs_box, subprocess_logs_box, start_btn, stop_btn, run_btn, skip_btn],
    )

    # 2. Use gr.Timer and the .tick() event to set up the recurring 5-second auto-refresh.
    # This is an invisible component that triggers the function on each interval.
    timer = gr.Timer(5) # Set the timer interval to 5 seconds.
    timer.tick(
        fn=master_refresh_cb,
        inputs=[compact_state],
        outputs=[status_html, app_logs_box, subprocess_logs_box, start_btn, stop_btn, run_btn, skip_btn],
    )


# =============================================================================
# Launch
# =============================================================================
if __name__ == "__main__":
    # Ensure log files exist
    for log_file in (APP_LOG_FILE, SUBPROCESS_LOG_FILE):
        if not os.path.exists(log_file):
            with open(log_file, 'w', encoding='utf-8') as f:
                f.write(f"Log file created at {_format_ts()}\n")

    # .queue() is essential for long-running apps / concurrency
    demo.queue()
    # demo.launch(server_name="0.0.0.0", server_port=7860)
    demo.launch()