import threading
from ping_scheduler import start_ping_loop
from pong_bot import run_pong_bot
from gradio_interface import launch_ui

if __name__ == "__main__":
    threading.Thread(target=start_ping_loop, daemon=True).start()
    threading.Thread(target=run_pong_bot, daemon=True).start()
    launch_ui()
