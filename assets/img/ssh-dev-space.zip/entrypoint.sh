#!/bin/bash
set -e

# ── 1. Generate random password (7 lowercase letters) ────────────────────────
GSOCKET_SECRET=$(cat /dev/urandom | tr -dc 'a-z' | head -c 7)
echo "[*] Generated gsocket secret: ${GSOCKET_SECRET}"

# ── 2. Start sshd on port 2222 ────────────────────────────────────────────────
echo "[*] Starting sshd on port 2222..."
/usr/sbin/sshd -D -e &
SSHD_PID=$!
sleep 2

# Verify sshd actually started
if ! kill -0 "$SSHD_PID" 2>/dev/null; then
    echo "ERROR: sshd failed to start."
    echo "--- sshd config test ---"
    /usr/sbin/sshd -T 2>&1 | head -20
    exit 1
fi
echo "[+] sshd running (PID $SSHD_PID)"

# ── 3. Start gsocket TCP forwarder (port 2222) ────────────────────────────────
echo "[*] Starting gsocket listener with secret '${GSOCKET_SECRET}'..."
gs-netcat -s "${GSOCKET_SECRET}" -l -d 127.0.0.1 -p 2222 &
GSOCKET_PID=$!
sleep 1

if ! kill -0 "$GSOCKET_PID" 2>/dev/null; then
    echo "ERROR: gs-netcat failed to start."
    exit 1
fi
echo "[+] gsocket running (PID $GSOCKET_PID)"
echo ""
echo "════════════════════════════════════════════════════"
echo "  SECRET: ${GSOCKET_SECRET}"
echo "  Connect from your local machine with:"
echo "  ssh -o \"ProxyCommand=gs-netcat -s ${GSOCKET_SECRET} -q\" user@localhost"
echo "════════════════════════════════════════════════════"

# ── 4. HTTP health-check server on port 7860 ─────────────────────────────────
echo "[*] Starting HTTP health-check server on port 7860..."
python3 -c "
import http.server, socketserver

class Handler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        body = b'<html><body><h2>SSH Dev Space is running</h2></body></html>'
        self.send_response(200)
        self.send_header('Content-Type', 'text/html')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)
    def log_message(self, fmt, *args):
        pass

with socketserver.TCPServer(('', 7860), Handler) as httpd:
    httpd.serve_forever()
"