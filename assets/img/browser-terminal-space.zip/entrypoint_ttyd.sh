#!/bin/bash
set -e

echo "[*] Starting ttyd browser terminal on port 7860..."

# ttyd flags:
#   -p 7860        → listen on HF's required port
#   -W             → allow clients to write (not read-only)
#   -t fontSize=16 → slightly larger font for comfort
#   -t theme=...   → dark theme
#   --writable     → enable keyboard input
#   su - user      → drop into the non-root user shell
exec ttyd \
    --port 7860 \
    --writable \
    -t fontSize=16 \
    -t 'theme={"background":"#1e1e2e","foreground":"#cdd6f4","cursor":"#f5c2e7","black":"#45475a","red":"#f38ba8","green":"#a6e3a1","yellow":"#f9e2af","blue":"#89b4fa","magenta":"#cba6f7","cyan":"#89dceb","white":"#bac2de"}' \
    su - user
