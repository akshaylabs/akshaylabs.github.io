import os
import json
import re
import logging
import time
from pathlib import Path
import hashlib
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from datetime import datetime

# -------------------------------
# CONFIGURATION
# -------------------------------
ACCESS_TOKEN = "eyJhbGciOiJIUzM4NCIsInR5cCI6IkpXVCJ9.eyJpZCI6MTI0MTc4MjUzLCJvcmdJZCI6NDM5MzUxLCJ0eXBlIjoxLCJtb2JpbGUiOiI5MTYzOTIyNDk4MzciLCJuYW1lIjoiQWpheSIsImVtYWlsIjpudWxsLCJpc0ludGVybmF0aW9uYWwiOjAsImRlZmF1bHRMYW5ndWFnZSI6ImVuIiwiY291bnRyeUNvZGUiOiJJTiIsImNvdW50cnlJU08iOiI5MSIsInRpbWV6b25lIjoiR01UKzU6MzAiLCJpc0RpeSI6dHJ1ZSwib3JnQ29kZSI6InN0aWJsIiwiaXNEaXlTdWJhZG1pbiI6MCwiZmluZ2VycHJpbnRJZCI6IjMyNTI3ODljNzY2MjQ1OGYiLCJpYXQiOjE3NTM4NjE3OTQsImV4cCI6MTc1NDQ2NjU5NH0.gxsVGQ7xjdKmr9U8ky8Gmt3VPWp3jG9D5tXDRfP9Ycirsli3GefSWh5y1RyjJcBh"
COURSE_ID = 516707
BASE_URL = "https://api.classplusapp.com/v2/course/content/get"

# --- IMPORTANT ---
# To fetch the ENTIRE course, set START_FOLDER_ID to None.
# To fetch only a specific folder and its subfolders, set it to the integer ID of that folder.
# Example: START_FOLDER_ID = 38232234
START_FOLDER_ID: int | None = None

# Local filesystem root where course content will be saved
BASE_SAVE_PATH = Path(os.getenv('COURSE_SAVE_PATH', './course_content')).resolve()
# File name for root index
INDEX_FILENAME = 'index.json'
LOG_FILE = BASE_SAVE_PATH / "download_log.jsonl"

# -------------------------------
# LOGGING SETUP
# -------------------------------
logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] %(levelname)s: %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)

# -------------------------------
# REQUESTS SESSION WITH RETRIES
# -------------------------------
session = requests.Session()
retries = Retry(total=5, backoff_factor=0.3,
                status_forcelist=(500, 502, 503, 504),
                allowed_methods=['GET'])
adapter = HTTPAdapter(max_retries=retries)
session.mount('https://', adapter)
session.mount('http://', adapter)

HEADERS = {
    'accept-language': 'en',
    'user-agent': 'Mobile-Android',
    'region': 'IN',
    'is-apk': '1',
    'accept': 'application/json, text/plain, */*',
    'mobile-agent': 'Mobile-Android',
    'api-version': '52',
    'x-access-token': ACCESS_TOKEN,
    'origin': 'https://course-overview.classplusapp.com',
    'x-requested-with': 'co.jones.stibl',
    'sec-fetch-site': 'same-site',
    'sec-fetch-mode': 'cors',
    'sec-fetch-dest': 'empty',
    'referer': 'https://course-overview.classplusapp.com/',
    'accept-encoding': 'gzip, deflate'
}


# -------------------------------
# UTILITIES
# -------------------------------
def write_log(entry: dict):
    """Append a JSON log entry to the log file."""
    entry["timestamp"] = datetime.now().isoformat()
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        json.dump(entry, f)
        f.write("\n")

def safe_name(name: str) -> str:
    cleaned = re.sub(r'[<>:"/\\|?*]', '_', name)
    return cleaned.strip() or '_'

def safe_filename(name: str, ext: str = "json") -> str:
    name = re.sub(r"[^\w\s.-]", "", name)
    name = re.sub(r"\s+", "_", name).strip("_")
    if len(name) > 80:
        hash_part = hashlib.md5(name.encode()).hexdigest()[:6]
        name = f"{name[:72]}_{hash_part}"
    return f"{name}.{ext}"

# -------------------------------
# FETCH AND SAVE LOGIC
# -------------------------------
def fetch_folder_content(course_id: int, folder_id: int | None = None) -> dict:
    """Fetches ALL content for a given folder, handling pagination automatically."""
    params = {
        'courseId': course_id,
        'limit': 50, # Fetch up to 50 items per API call
        'offset': 0,
        'search': '',
        'originalCourseId': -1
    }
    if folder_id is not None:
        params['folderId'] = folder_id

    all_items = []
    last_data_packet = {}
    
    while True:
        try:
            resp = session.get(BASE_URL, headers=HEADERS, params=params, timeout=20)
            resp.raise_for_status()
            last_data_packet = resp.json().get('data', {})
            items = last_data_packet.get('courseContent', [])
            
            if not items:
                break # No more items to fetch, exit the loop

            all_items.extend(items)
            params['offset'] += len(items) # Set offset for the next page
            time.sleep(0.2) # Small delay to be respectful to the API

        except requests.exceptions.RequestException as e:
            logger.error(f"API request failed for folder {folder_id} at offset {params['offset']}: {e}")
            raise # Stop execution if a page fails to load

    # Combine all fetched items with the metadata from the last request
    return {
        'courseContent': all_items,
        'metadata': last_data_packet.get('metadata', {})
    }


def extract_relevant(item: dict) -> dict:
    """Extracts key information from a content item."""
    ct = item.get('contentType')
    base = {
        'contentType': ct,
        'id': item.get('id'),
        'name': item.get('name')
    }
    if ct == 1: # Folder
        base.update({
            'description': item.get('description'),
            'resources': item.get('resources', {}),
            'counts': {
                'documents': item.get('documentCount'),
                'videos': item.get('videoCount'),
                'tests': item.get('testCount')
            }
        })
    elif ct == 2: # Video
        base.update({
            'description': item.get('description', ''),
            'vidKey': item.get('vidKey'),
            'thumbnailUrl': item.get('thumbnailUrl'),
            'videoType': item.get('videoType'),
            'duration': item.get('duration'),
            'contentHashId': item.get('contentHashId')
        })
    elif ct == 3: # Document
        base.update({
            'description': item.get('description', ''),
            'format': item.get('format'),
            'url': item.get('url'),
            'isContentLocked': item.get('isContentLocked')
        })
    elif ct == 4: # Test
        base.update({
            'description': item.get('description', ''),
            'testId': item.get('testId'),
            'maxMarks': item.get('maxMarks'),
            'URL': item.get('URL')
        })
    return base

def save_content_file(content: dict, save_dir: Path) -> str:
    """Saves the content metadata to a JSON file."""
    original_name = content.get("name", f"item_{content.get('id')}")
    raw_filename = f"{original_name}.json"
    raw_filepath = save_dir / raw_filename

    try:
        with open(raw_filepath, "w", encoding="utf-8") as f:
            json.dump(content, f, indent=2, ensure_ascii=False)
        write_log({
            "action": "save_file", "status": "success",
            "file": raw_filename, "path": str(raw_filepath)
        })
        return raw_filename

    except (OSError, FileNotFoundError) as e:
        sanitized_name = safe_filename(original_name)
        safe_path = save_dir / sanitized_name
        with open(safe_path, "w", encoding="utf-8") as f:
            json.dump(content, f, indent=2, ensure_ascii=False)
        write_log({
            "action": "save_file", "status": "fallback_filename",
            "original_name": original_name, "fallback_name": sanitized_name,
            "path": str(safe_path), "error": str(e)
        })
        return sanitized_name

def recursively_save(folder_id: int | None, path: Path):
    """Recursively fetches and saves content, starting from a given folder ID."""
    try:
        data = fetch_folder_content(COURSE_ID, folder_id)
    except Exception as e:
        logger.error(f"FATAL: Could not fetch content for folder_id '{folder_id}'. Halting this branch. Error: {e}")
        write_log({"action": "fetch_folder", "status": "fatal_error", "folder_id": folder_id, "error": str(e)})
        return

    items = data.get('courseContent', [])
    meta = data.get('metadata', {})
    
    # Determine the name for the current directory
    if folder_id is None:
        # This is the top-level call, we create a "root" folder
        folder_name = 'root'
    else:
        # For subfolders, use the name from the API's metadata
        folder_name = meta.get('currentFolderDetails', {}).get('folderName', f"folder_{folder_id}")

    safe_folder_name = safe_name(folder_name)
    current_path = path / safe_folder_name
    current_path.mkdir(parents=True, exist_ok=True)
    
    logger.info(f"Processing folder: '{folder_name}' (ID: {folder_id}) -> Saving to '{current_path}'")
    write_log({"action": "enter_folder", "folder_name": folder_name, "folder_id": folder_id, "item_count": len(items)})

    index_list = []
    for item in items:
        slim = extract_relevant(item)
        filename = save_content_file(slim, current_path)
        index_list.append(filename)

        # If the item is a folder (contentType 1), recurse into it
        if item.get('contentType') == 1 and 'id' in item:
            recursively_save(item['id'], current_path)

    # Create an index file for the current folder
    index_path = current_path / INDEX_FILENAME
    with open(index_path, 'w', encoding='utf-8') as f:
        json.dump(index_list, f, ensure_ascii=False, indent=2)
    logger.info(f"Wrote index for '{folder_name}' with {len(index_list)} items.")
    write_log({"action": "write_index", "folder": str(current_path), "index_file": INDEX_FILENAME})


if __name__ == '__main__':
    if not ACCESS_TOKEN:
        logger.error("ACCESS_TOKEN is not set. Please edit the script and add your token. Exiting.")
        exit(1)
        
    BASE_SAVE_PATH.mkdir(exist_ok=True)
    LOG_FILE.touch(exist_ok=True)

    logger.info("--- Starting Full Course Download ---")
    logger.info(f"Course ID: {COURSE_ID}")
    logger.info(f"Saving content to: {BASE_SAVE_PATH.resolve()}")
    if START_FOLDER_ID is not None:
         logger.warning(f"Warning: Starting from specific folder ID: {START_FOLDER_ID}, not the course root.")
    
    # This initial call starts the entire recursive process.
    # It starts at the base save path and uses the configured START_FOLDER_ID.
    recursively_save(folder_id=START_FOLDER_ID, path=Path(BASE_SAVE_PATH.parent))
    
    logger.info("--- Download Process Finished ---")