import requests
import json
import brotli
import time
import os
import argparse
import sys
import copy
from urllib.parse import urlparse, parse_qs

# --- CONFIGURATION ---
BASE_URL = "https://cms-gcp.classplusapp.com/student/api/v2"
USER_AGENT = "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36"
INPUT_COURSE_FILE = "course.json" # Raw course data from the source
MASTER_FILE = "master_course.json"       # The single source of truth for all processing
OUTPUT_BASE_DIR = "outputs"
MAX_RETRIES = 3
RETRY_DELAY_SECONDS = 5

# --- HELPER FUNCTIONS ---

def get_headers(test_specific_token, extra_headers=None):
    """Constructs the base headers using the test-specific token."""
    headers = {
        "accept": "application/json, text/plain, */*",
        "accept-encoding": "br",
        "content-type": "application/json",
        "origin": "https://student-cms.classplusapp.com",
        "referer": "https://student-cms.classplusapp.com/",
        "user-agent": USER_AGENT,
        "x-cms-access-token": test_specific_token
    }
    if extra_headers:
        headers.update(extra_headers)
    return headers

def make_request_with_retry(method, url, **kwargs):
    """Makes an HTTP request with a built-in retry mechanism."""
    for attempt in range(MAX_RETRIES):
        try:
            response = requests.request(method, url, **kwargs, timeout=30)
            # if response.status_code == 200:
            # The API can return 200 OK or 201 Created on success, so we check for any 2xx status code.
            if response.ok: 
                return response
            else:
                print(f"  ⚠️  Request to {url} failed with status {response.status_code}. Retrying... ({attempt + 1}/{MAX_RETRIES})")
        except requests.exceptions.RequestException as e:
            print(f"  ❌ Request to {url} failed with exception: {e}. Retrying... ({attempt + 1}/{MAX_RETRIES})")
        if attempt < MAX_RETRIES - 1:
            time.sleep(RETRY_DELAY_SECONDS)
    print(f"  ❌ All {MAX_RETRIES} retries failed for {url}.")
    return None

# --- MASTER FILE MANAGEMENT ---

def load_master_file(filepath):
    """Loads the master course data file."""
    if not os.path.exists(filepath):
        print(f"❌ Master file '{filepath}' not found. Please create it first using the --init flag.")
        print(f"   Example: python your_script_name.py --init {INPUT_COURSE_FILE}")
        return None
    with open(filepath, 'r', encoding='utf-8') as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            print(f"❌ Error: Could not parse '{filepath}'. It might be corrupted.")
            return None

def save_master_file(data, filepath):
    """Saves the master course data to the file, ensuring atomicity."""
    temp_filepath = filepath + ".tmp"
    with open(temp_filepath, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2)
    os.replace(temp_filepath, filepath)

def _prune_and_enhance_node(node):
    """
    Recursively processes a node.
    - If it's a test, it's enhanced and returned.
    - If it's a folder, its children are processed, and the folder is kept only if it's not empty.
    - All other content types (videos, PDFs) are discarded by returning None.
    """
    node = copy.deepcopy(node) # Use a copy to avoid issues with modifying during iteration

    # Rule 1: KEEP & ENHANCE A TEST
    # This is a terminal node in our pruned tree.
    if node.get("contentType") == 4 and node.get("testId") and node.get("URL"):
        node["processingInfo"] = {
            "status": "pending",
            "token": None,
            "questionsPath": None,
            "solutionsPath": None,
            "lastAttemptTimestamp": None,
            "lastError": None
        }
        try:
            parsed_url = urlparse(node["URL"])
            token = parse_qs(parsed_url.query).get('token', [None])[0]
            node["processingInfo"]["token"] = token
        except Exception as e:
            node["processingInfo"]["status"] = "failed"
            node["processingInfo"]["lastError"] = f"Could not parse token from URL: {e}"
        return node

    # Rule 2: DISCARD NON-TEST, NON-FOLDER ITEMS
    # This prunes videos, PDFs, etc.
    if node.get("contentType") != 1:
        return None

    # Rule 3: PROCESS FOLDER CHILDREN RECURSIVELY
    # If we are here, contentType is 1 (a folder).
    if "children" in node and isinstance(node["children"], list):
        pruned_children = []
        for child in node["children"]:
            pruned_child = _prune_and_enhance_node(child)
            if pruned_child:
                pruned_children.append(pruned_child)
        
        # Rule 4: DISCARD FOLDER IF IT'S NOW EMPTY, otherwise keep it with pruned children
        if pruned_children:
            node["children"] = pruned_children
            return node

    # Discard anything else (e.g., malformed or now-empty folders)
    return None


def initialize_master_file(input_path, output_path):
    """
    Creates a lean, test-focused master file from a raw course file.
    It prunes all non-test content and any folders that become empty as a result.
    """
    print(f"⚙️  Initializing a lean, test-only master file from '{input_path}'...")
    if not os.path.exists(input_path):
        print(f"❌ Input course file not found at '{input_path}'")
        return

    with open(input_path, 'r', encoding='utf-8') as f:
        try:
            course_data = json.load(f)
        except json.JSONDecodeError:
            print(f"❌ Could not parse '{input_path}'.")
            return

    pruned_master_data = []
    if isinstance(course_data, list):
        for item in course_data:
            processed_item = _prune_and_enhance_node(item)
            if processed_item:
                pruned_master_data.append(processed_item)

    save_master_file(pruned_master_data, output_path)
    print(f"✅ Pruning complete. Lean master file created at '{output_path}'")
    print("   This file contains only tests and the folders required to access them.")


def find_tests_to_process(data):
    """
    Recursively searches the master data tree to find test objects that need processing.
    """
    tests = []
    def _recursive_search(node):
        if isinstance(node, dict):
            if node.get("contentType") == 4 and "processingInfo" in node:
                status = node["processingInfo"].get("status")
                if status in ["pending", "failed"] or (args.fetch_answers and status == "questions_only"):
                    tests.append(node)
            if "children" in node and isinstance(node["children"], list):
                for child in node["children"]:
                    _recursive_search(child)
    if isinstance(data, list):
        for item in data:
            _recursive_search(item)
    return tests

# --- CORE LOGIC FUNCTIONS (Unchanged from previous version) ---

def process_test_questions_only(test_obj):
    """Fetches only the questions for a test. Returns a dictionary of updates."""
    test_id = test_obj['testId']
    token = test_obj['processingInfo']['token']
    print(f"\n{'='*20}\nProcessing Test ID (Questions Only): {test_id}\n{'='*20}")
    print("▶️  STEP 1: Fetching test questions...")

    start_url = f"{BASE_URL}/test/start"
    payload = {"testId": test_id}
    response = make_request_with_retry("POST", start_url, json=payload, headers=get_headers(token))

    if not response:
        return {"status": "failed", "lastError": "Could not fetch questions after retries."}
    try:
        questions_data = response.json()
        test_output_dir = os.path.join(OUTPUT_BASE_DIR, str(test_id))
        os.makedirs(test_output_dir, exist_ok=True)
        questions_path = os.path.join(test_output_dir, "questions.json")
        with open(questions_path, 'w', encoding='utf-8') as f:
            json.dump(questions_data, f, indent=2)
        print(f"🎉 Success! Questions saved to '{questions_path}'")
        return {"status": "questions_only", "questionsPath": questions_path, "lastError": None}
    except Exception as e:
        return {"status": "failed", "lastError": f"Error saving questions: {e}"}

def _save_solutions(sol_response, test_output_dir):
    """Helper to decompress and save solution file with fallback."""
    solution_data = None
    try:
        # Check if the server claims the content is Brotli compressed
        if "br" in sol_response.headers.get("content-encoding", ""):
            try:
                # First, ATTEMPT to decompress
                solution_data = json.loads(brotli.decompress(sol_response.content))
            except brotli.error:
                # If decompression fails, log a warning and fall back to plain JSON
                print("  ⚠️  Brotli decompression failed. Server may have sent a misleading header. Falling back to plain JSON.")
                solution_data = sol_response.json()
        else:
            # If the server doesn't claim it's Brotli, just parse as JSON
            solution_data = sol_response.json()
        
        solutions_path = os.path.join(test_output_dir, "solutions.json")
        with open(solutions_path, "w", encoding="utf-8") as f: json.dump(solution_data, f, indent=2)
        print(f"🎉 Success! Solutions saved to '{solutions_path}'")
        return solutions_path, None
    except Exception as e:
        # This will catch any other errors, like if the data isn't valid JSON at all
        error_msg = f"Error decoding or saving solutions: {e}"
        print(f"  ❌ {error_msg}")
        return None, error_msg

def process_test_full_flow(test_obj):
    """Runs the full flow using the standard (slow) one-by-one submission method."""
    test_id = test_obj['testId']
    token = test_obj['processingInfo']['token']
    print(f"\n{'='*20}\nProcessing Test ID (Full Flow - Slow Method): {test_id}\n{'='*20}")

    print("▶️  STEP 1: Fetching and saving test questions...")
    start_url = f"{BASE_URL}/test/start"; payload = {"testId": test_id}
    response = make_request_with_retry("POST", start_url, json=payload, headers=get_headers(token))
    if not response: return {"status": "failed", "lastError": "Could not start the test."}
    try:
        start_data = response.json(); test_output_dir = os.path.join(OUTPUT_BASE_DIR, str(test_id)); os.makedirs(test_output_dir, exist_ok=True)
        questions_path = os.path.join(test_output_dir, "questions.json")
        with open(questions_path, 'w', encoding='utf-8') as f: json.dump(start_data, f, indent=2)
        print(f"✅ Questions saved to '{questions_path}'")
        student_test_id = start_data['data']['studentTestId']; device_id = start_data['data'].get('deviceId', f"web_{int(time.time() * 1000)}")
        questions = start_data.get('data', {}).get('test', {}).get('sections', [{}])[0].get('questions', [])
    except (KeyError, IndexError, json.JSONDecodeError) as e:
        return {"status": "failed", "lastError": f"Invalid start response: {e}", "questionsPath": test_obj['processingInfo'].get('questionsPath')}

    total_time_taken = 0
    if questions:
        print(f"\n▶️  STEP 2: Submitting {len(questions)} answers (one-by-one)...")
        submit_url = f"{BASE_URL}/question/submit"; headers_submit = get_headers(token, {"x-cms-device-id": str(device_id)})
        for q in questions:
            time_per_question = 1500; total_time_taken += time_per_question
            q_payload = {"testId": test_id, "studentTestId": student_test_id, "questions": [{"solution": "", "_id": q['_id'], "isGpscType": False, "__v": 0, "timeTaken": time_per_question, "fillUpsAnswers": [], "selectedOptions": [], "markForReview": False}], "timeTaken": total_time_taken}
            if not make_request_with_retry("POST", submit_url, json=q_payload, headers=headers_submit):
                return {"status": "failed", "lastError": f"Submission failed for question {q['_id']}", "questionsPath": questions_path}
        print("✅ All answers submitted.")

    print("\n▶️  STEP 3: Evaluating test...")
    evaluate_url = f"{BASE_URL}/test/evaluate"
    evaluate_payload = {"testId": test_id, "studentTestId": student_test_id, "questions": [], "timeTaken": total_time_taken + 5000, "reasonForSubmit": "Student switched from test for 3 times", "autoSubmitType": 3}
    if not make_request_with_retry("POST", evaluate_url, headers=get_headers(token, {"x-cms-device-id": str(device_id)}), json=evaluate_payload):
        return {"status": "failed", "lastError": "Evaluation request failed.", "questionsPath": questions_path}
    print("✅ Evaluation request sent.")

    print("\n▶️  STEP 4: Fetching solutions...")
    solution_url = f"{BASE_URL}/test/{test_id}/student/{student_test_id}/solutions?section=true"
    sol_response = make_request_with_retry("GET", solution_url, headers=get_headers(token, {"x-cms-device-id": str(device_id)}))
    if not sol_response: return {"status": "failed", "lastError": "Could not fetch solutions.", "questionsPath": questions_path}

    solutions_path, error = _save_solutions(sol_response, test_output_dir)
    if error:
        return {"status": "failed", "lastError": error, "questionsPath": questions_path}
    else:
        return {"status": "completed", "questionsPath": questions_path, "solutionsPath": solutions_path, "lastError": None}

def process_test_quick_submit(test_obj):
    """Runs the full flow using the immediate evaluation method (quick submit)."""
    test_id = test_obj['testId']
    token = test_obj['processingInfo']['token']
    print(f"\n{'='*20}\nProcessing Test ID (Full Flow - Quick Method): {test_id}\n{'='*20}")
    
    print("▶️  STEP 1: Starting test and saving questions...")
    start_url = f"{BASE_URL}/test/start"; payload = {"testId": test_id}
    response = make_request_with_retry("POST", start_url, json=payload, headers=get_headers(token))
    if not response: return {"status": "failed", "lastError": "Could not start the test."}
    try:
        start_data = response.json(); test_output_dir = os.path.join(OUTPUT_BASE_DIR, str(test_id)); os.makedirs(test_output_dir, exist_ok=True)
        questions_path = os.path.join(test_output_dir, "questions.json")
        with open(questions_path, 'w', encoding='utf-8') as f: json.dump(start_data, f, indent=2)
        print(f"✅ Questions saved to '{questions_path}'")
        student_test_id = start_data['data']['studentTestId']; device_id = start_data['data'].get('deviceId', f"web_{int(time.time() * 1000)}")
    except (KeyError, IndexError, json.JSONDecodeError) as e:
        return {"status": "failed", "lastError": f"Invalid start response: {e}", "questionsPath": test_obj['processingInfo'].get('questionsPath')}

    print("\n▶️  STEP 2: Forcing immediate test evaluation (quick submit)...")
    evaluate_url = f"{BASE_URL}/test/evaluate"
    evaluate_payload = {"testId": test_id, "studentTestId": student_test_id, "questions": [], "timeTaken": 5000, "reasonForSubmit": "Student submitted test successfully", "autoSubmitType": 1}
    headers_with_device = get_headers(token, {"x-cms-device-id": str(device_id)})
    if not make_request_with_retry("POST", evaluate_url, headers=headers_with_device, json=evaluate_payload):
        return {"status": "failed", "lastError": "Quick evaluation request failed.", "questionsPath": questions_path}
    print("✅ Quick evaluation request sent.")
    
    print("\n▶️  STEP 3: Fetching solutions...")
    solution_url = f"{BASE_URL}/test/{test_id}/student/{student_test_id}/solutions?section=true"
    sol_response = make_request_with_retry("GET", solution_url, headers=headers_with_device)
    if not sol_response: return {"status": "failed", "lastError": "Could not fetch solutions after quick submit.", "questionsPath": questions_path}

    solutions_path, error = _save_solutions(sol_response, test_output_dir)
    if error:
        return {"status": "failed", "lastError": error, "questionsPath": questions_path}
    else:
        return {"status": "completed", "questionsPath": questions_path, "solutionsPath": solutions_path, "lastError": None}


# --- MAIN EXECUTION ---
if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        formatter_class=argparse.RawTextHelpFormatter,
        description="""A robust script to fetch Classplus test data.

Workflow:
1. First-time setup:
   - Place your raw course content in 'input_course.json'.
   - Run: python your_script.py --init
   - This creates a lean 'master_course.json' containing ONLY tests
     and the folders needed to access them. All other content is discarded.

2. Running the script:
   - Run: python your_script.py [--fetch-answers] [--quick-submit]
   - The script finds all 'pending' or 'failed' tests in 'master_course.json' and processes them.
   - The master file is updated in real-time after each test.
   - Press Ctrl+C at any time to safely interrupt and save progress."""
    )
    parser.add_argument("--init", action="store_true", help=f"Initialize a new, lean master file from '{INPUT_COURSE_FILE}'.")
    parser.add_argument("--master-file", default=MASTER_FILE, help=f"Path to the master course data file (default: {MASTER_FILE})")
    parser.add_argument("--fetch-answers", action="store_true", help="Enable fetching answers. Default is questions only.")
    parser.add_argument("--quick-submit", action="store_true", help="Use fast submission. Requires --fetch-answers.")
    args = parser.parse_args()

    # Mode 1: Initialize Master File
    if args.init:
        initialize_master_file(INPUT_COURSE_FILE, args.master_file)
        sys.exit(0)

    # Mode 2: Process Tests from Master File
    print("🚀 Starting test processing run...")
    master_data = load_master_file(args.master_file)
    if master_data is None:
        sys.exit(1)

    tests_to_process = find_tests_to_process(master_data)
    total_tests = len(tests_to_process)
    if not tests_to_process:
        print("\n✅ All eligible tests in the master file have been processed. Nothing to do.")
        sys.exit(0)
    
    print(f"\nℹ️  Found {total_tests} test(s) with 'pending' or 'failed' status to process.")
    succeeded_count, failed_count = 0, 0

    try:
        for i, test_obj in enumerate(tests_to_process):
            test_id = test_obj.get("testId")
            print(f"\n--- Processing test {i+1}/{total_tests} (ID: {test_id}) ---")

            token = test_obj.get("processingInfo", {}).get("token")
            if not token:
                print(f"  ⚠️ Skipping test {test_id}: No valid token found in processingInfo.")
                updates = {"status": "failed", "lastError": "No token available."}
            else:
                test_obj["processingInfo"]["lastAttemptTimestamp"] = time.strftime("%Y-%m-%d %H:%M:%S")

                if args.fetch_answers:
                    if args.quick_submit: updates = process_test_quick_submit(test_obj)
                    else: updates = process_test_full_flow(test_obj)
                else:
                    updates = process_test_questions_only(test_obj)
            
            test_obj["processingInfo"].update(updates)

            if updates["status"] not in ["failed"]:
                succeeded_count += 1
                print(f"✅ STATUS for Test ID {test_id}: {updates['status'].upper()}")
            else:
                failed_count += 1
                print(f"❌ STATUS for Test ID {test_id}: {updates['status'].upper()} - {updates['lastError']}")

            print(f"💾 Saving real-time progress to '{args.master_file}'...")
            save_master_file(master_data, args.master_file)

    except KeyboardInterrupt:
        print("\n\n❗️ Interrupted by user (Ctrl+C). Saving current state before exiting...")
        save_master_file(master_data, args.master_file)
        print("✅ Progress saved. Exiting now.")
        sys.exit(1)

    # Final summary
    print("\n" + "="*20 + " Run Summary " + "="*20)
    print(f"✅ Successfully processed/advanced: {succeeded_count} test(s).")
    print(f"❌ Failed to process: {failed_count} test(s).")
    if failed_count > 0:
        print(f"   Failed tests are marked in '{args.master_file}' and will be retried on the next run.")
    print("="*53)
