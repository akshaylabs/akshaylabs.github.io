import requests
import json
import time

# --- STEP 1: Start the Test ---
start_url = "https://cms-gcp.classplusapp.com/student/api/v2/test/start"
headers = {
    "accept": "application/json, text/plain, */*",
    "accept-encoding": "gzip, deflate, br", # It's good practice to still accept compression
    "content-type": "application/json",
    "origin": "https://student-cms.classplusapp.com",
    "referer": "https://student-cms.classplusapp.com/",
    "user-agent": "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36",
    "x-cms-access-token": "eyJhbGciOiJIUzM4NCIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyNDE3ODI1MywibmFtZSI6IkFqYXkiLCJlbWFpbCI6bnVsbCwibW9iaWxlIjoiOTE2MzkyMjQ5ODM3Iiwic3R1ZGVudElkIjo5NTc4NjY5MywiY29udGVudElkIjoxNTgwMDMxNCwib3JnSWQiOjQzOTM1MSwiY29udGVudFR5cGUiOjQsImNvdXJzZUlkIjoiNTE2NzA3IiwidGltZXN0YW1wIjoxNzUzODczMjc1MTQ0LCJjb3Vyc2VOYW1lIjoiRC4gUGhhcm0gU2Vjb25kIHllYXIgbmV3IEJhdGNoIHZhbGlkIHRpbGwganVseSAyMDI1IiwidGVzdElkIjoiNjZlNjgyYjI1NjM3Y2U3MmJlNWVhNzA2IiwibnVtYmVyT2ZBdHRlbXB0cyI6LTEsIm1ldGFEYXRhIjp7Im9jc0lkIjozMDIzNjM5NCwib2NzVGltZSI6MTcyMDUzNDE4ODAwMH0sImlhdCI6MTc1Mzg3MzI3NSwiZXhwIjoxNzU0NDc4MDc1fQ.ntjhx-k89CkYoO4uk9lXA0BvsvVUdXnee7FTGjtfydxdowrW9wcWzYlrK5U5Xn7H"
}

payload = {
    "testId": "66e682b25637ce72be5ea706"
}

print("▶️  STEP 1: Starting the test...")
response = requests.post(start_url, json=payload, headers=headers)
print(f"✅ Test Started. Status Code: {response.status_code}")

try:
    start_data = response.json()
    test_id = start_data['data']['test']['_id']
    student_test_id = start_data['data']['studentTestId']
    device_id = start_data['data'].get('deviceId', f"web_{int(time.time() * 1000)}")
    questions_from_start = start_data['data']['test']['sections'][0]['questions']
except KeyError as e:
    print(f"❌ Missing expected data in start response: {e}")
    exit()

# --- STEP 2: Submit Each Question Individually ---
submit_url = "https://cms-gcp.classplusapp.com/student/api/v2/question/submit"
headers_submit = {**headers, "x-cms-device-id": str(device_id)}
total_time_taken = 0

print(f"\n▶️  STEP 2: Submitting {len(questions_from_start)} answers one by one...")

for i, q in enumerate(questions_from_start):
    time_per_question = 1500
    total_time_taken += time_per_question
    question_payload = {
        "testId": test_id, "studentTestId": student_test_id,
        "questions": [{"solution": "", "_id": q['_id'], "isGpscType": False, "__v": 0, "timeTaken": time_per_question, "fillUpsAnswers": [], "selectedOptions": [], "markForReview": False}],
        "timeTaken": total_time_taken
    }
    submit_response = requests.post(submit_url, json=question_payload, headers=headers_submit)
    print(f"  -> Submitting Q{i+1}/{len(questions_from_start)} ({q['_id']})... Status: {submit_response.status_code}")
    if submit_response.status_code != 200:
        print(f"  ⚠️  Submission failed for question {q['_id']}. Stopping.")
        break

print("✅ All answers submitted individually.")

# --- STEP 3: Evaluate the Test ---
evaluate_url = "https://cms-gcp.classplusapp.com/student/api/v2/test/evaluate"
headers_eval = {**headers, "x-cms-device-id": str(device_id)}
evaluate_payload = {
    "testId": test_id, "studentTestId": student_test_id, "questions": [],
    "timeTaken": total_time_taken + 5000,
    "reasonForSubmit": "Student submitted test successfully", "autoSubmitType": 1
}

print("\n▶️  STEP 3: Finalizing and Evaluating the test...")
eval_response = requests.post(evaluate_url, headers=headers_eval, json=evaluate_payload)
print(f"✅ Test Evaluate Request Sent. Status: {eval_response.status_code}")

# --- STEP 4: Fetch Solutions ---
solution_url = f"https://cms-gcp.classplusapp.com/student/api/v2/test/{test_id}/student/{student_test_id}/solutions?section=true"
headers_sol = {**headers, "x-cms-device-id": str(device_id)}

print("\n▶️  STEP 4: Fetching solutions...")
sol_response = requests.get(solution_url, headers=headers_sol)
print(f"✅ Solutions Request Sent. Status: {sol_response.status_code}")

if sol_response.status_code != 200:
    print("⚠️  Could not fetch solutions.")
    print(f"↩️  Raw content: {sol_response.content[:500]}")
    exit()

# --- STEP 5: Save to File (Final Version) ---
try:
    # Directly parse the response as JSON. The requests library handles the decoding.
    solution_data = sol_response.json()
        
    with open("test_solutions.json", "w", encoding="utf-8") as f:
        json.dump(solution_data, f, indent=2, ensure_ascii=False)

    print("\n🎉🎉🎉 COMPLETE SUCCESS! Solutions saved to 'test_solutions.json' 🎉🎉🎉")

except json.JSONDecodeError as e:
    print(f"❌ A JSON error occurred. This means the response was not valid JSON: {e}")
    print(f"📄 Raw Response Content: {sol_response.text}")
except Exception as e:
    print(f"❌ An unexpected error occurred: {e}")