import requests
import json
import time

# --- STEP 1: Start the Test ---
start_url = "https://cms-gcp.classplusapp.com/student/api/v2/test/start"
headers = {
    "accept": "application/json, text/plain, */*",
    "accept-encoding": "gzip, deflate, br",
    "content-type": "application/json",
    "origin": "https://student-cms.classplusapp.com",
    "referer": "https://student-cms.classplusapp.com/",
    "user-agent": "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36",
    "x-cms-access-token": "eyJhbGciOiJIUzM4NCIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyNDE3ODI1MywibmFtZSI6IkFqYXkiLCJlbWFpbCI6bnVsbCwibW9iaWxlIjoiOTE2MzkyMjQ5ODM3Iiwic3R1ZGVudElkIjo5NTc4NjY5MywiY29udGVudElkIjoxNTgwMDMxNCwib3JnSWQiOjQzOTM1MSwiY29udGVudFR5cGUiOjQsImNvdXJzZUlkIjoiNTE2NzA3IiwidGltZXN0YW1wIjoxNzUzODczMjc1MTQ0LCJjb3Vyc2VOYW1lIjoiRC4gUGhhcm0gU2Vjb25kIHllYXIgbmV3IEJhdGNoIHZhbGlkIHRpbGwganVseSAyMDI1IiwidGVzdElkIjoiNjZlNjgyYjI1NjM3Y2U3MmJlNWVhNzA2IiwibnVtYmVyT2ZBdHRlbXB0cyI6LTEsIm1ldGFEYXRhIjp7Im9jc0lkIjozMDIzNjM5NCwib2NzVGltZSI6MTcyMDUzNDE4ODAwMH0sImlhdCI6MTc1Mzg3MzI3NSwiZXhwIjoxNzU0NDc4MDc1fQ.ntjhx-k89CkYoO4uk9lXA0BvsvVUdXnee7FTGjtfydxdowrW9wcWzYlrK5U5Xn7H"
}

payload = {
    "testId": "66e682b25637ce72be5ea706"
}

print("▶️  STEP 1: Starting the test...")
response = requests.post(start_url, json=payload, headers=headers)
print(f"✅ Test Started. Status Code: {response.status_code}")

try:
    start_data = response.json()
    test_id = start_data['data']['test']['_id']
    student_test_id = start_data['data']['studentTestId']
    device_id = start_data['data'].get('deviceId', f"web_{int(time.time() * 1000)}")
    first_question = start_data['data']['test']['sections'][0]['questions'][0]
except (KeyError, IndexError) as e:
    print(f"❌ Could not get required data from start response: {e}")
    exit()

# --- STEP 2: Submit ONLY the First Question to Activate the Test ---
submit_url = "https://cms-gcp.classplusapp.com/student/api/v2/question/submit"
headers_submit = {**headers, "x-cms-device-id": str(device_id)}
time_for_one_question = 1500

print(f"\n▶️  STEP 2: Submitting only the first question to activate session...")

question_payload = {
    "testId": test_id,
    "studentTestId": student_test_id,
    "questions": [{
        "solution": "", "_id": first_question['_id'], "isGpscType": False, "__v": 0,
        "timeTaken": time_for_one_question, "fillUpsAnswers": [], "selectedOptions": [], "markForReview": False
    }],
    "timeTaken": time_for_one_question
}

submit_response = requests.post(submit_url, json=question_payload, headers=headers_submit)
print(f"  -> Submitted Q1 ({first_question['_id']})... Status: {submit_response.status_code}")

if submit_response.status_code != 200:
    print("  ⚠️  Submission of the first question failed. The process might not work.")

# --- STEP 3: Evaluate the Test (with Auto-Submit Reason) ---
evaluate_url = "https://cms-gcp.classplusapp.com/student/api/v2/test/evaluate"
headers_eval = {**headers, "x-cms-device-id": str(device_id)}
evaluate_payload = {
    "testId": test_id,
    "studentTestId": student_test_id,
    "questions": [],
    "timeTaken": time_for_one_question + 2000, # Add a little extra time
    "reasonForSubmit": "Student switched from test for 3 times",
    "autoSubmitType": 3 # The key field to force submission
}

print("\n▶️  STEP 3: Forcing test evaluation via auto-submit...")
eval_response = requests.post(evaluate_url, headers=headers_eval, json=evaluate_payload)
print(f"✅ Test Evaluate Request Sent. Status: {eval_response.status_code}")

# --- STEP 4: Fetch Solutions ---
solution_url = f"https://cms-gcp.classplusapp.com/student/api/v2/test/{test_id}/student/{student_test_id}/solutions?section=true"
headers_sol = {**headers, "x-cms-device-id": str(device_id)}

print("\n▶️  STEP 4: Fetching solutions...")
sol_response = requests.get(solution_url, headers=headers_sol)
print(f"✅ Solutions Request Sent. Status: {sol_response.status_code}")

if sol_response.status_code != 200:
    print("⚠️  Could not fetch solutions.")
    print(f"↩️  Raw content: {sol_response.content[:500]}")
    exit()

# --- STEP 5: Save to File ---
try:
    solution_data = sol_response.json()
    with open("test_solutions_optimized.json", "w", encoding="utf-8") as f:
        json.dump(solution_data, f, indent=2, ensure_ascii=False)
    print("\n🎉🎉🎉 OPTIMIZED SUCCESS! Solutions saved to 'test_solutions_optimized.json' 🎉🎉🎉")
except Exception as e:
    print(f"❌ An error occurred during file saving: {e}")