import requests
import json
import time

# --- Configuration ---
# Your unique access token is the only thing you should need to change.
# It's a long string starting with "eyJ...".
# How to get it:
# 1. Open the test in your web browser (Chrome is recommended).
# 2. Open Developer Tools (F12 or Ctrl+Shift+I).
# 3. Go to the "Network" tab.
# 4. Find a request to the classplusapp API (e.g., a "start" or "submit" request).
# 5. In the "Headers" tab for that request, find "x-cms-access-token" and copy its value.
ACCESS_TOKEN = "eyJhbGciOiJIUzM4NCIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyNDE3ODI1MywibmFtZSI6IkFqYXkiLCJlbWFpbCI6bnVsbCwibW9iaWxlIjoiOTE2MzkyMjQ5ODM3Iiwic3R1ZGVudElkIjo5NTc4NjY5MywiY29udGVudElkIjoxNTgwMDMxNCwib3JnSWQiOjQzOTM1MSwiY29udGVudFR5cGUiOjQsImNvdXJzZUlkIjoiNTE2NzA3IiwidGltZXN0YW1wIjoxNzUzODczMjc1MTQ0LCJjb3Vyc2VOYW1lIjoiRC4gUGhhcm0gU2Vjb25kIHllYXIgbmV3IEJhdGNoIHZhbGlkIHRpbGwganVseSAyMDI1IiwidGVzdElkIjoiNjZlNjgyYjI1NjM3Y2U3MmJlNWVhNzA2IiwibnVtYmVyT2ZBdHRlbXB0cyI6LTEsIm1ldGFEYXRhIjp7Im9jc0lkIjozMDIzNjM5NCwib2NzVGltZSI6MTcyMDUzNDE4ODAwMH0sImlhdCI6MTc1Mzg3MzI3NSwiZXhwIjoxNzU0NDc4MDc1fQ.ntjhx-k89CkYoO4uk9lXA0BvsvVUdXnee7FTGjtfydxdowrW9wcWzYlrK5U5Xn7H"

# The ID of the test you want to access.
# You can usually find this in the URL when you open the test.
TEST_ID_PAYLOAD = "66e682b25637ce72be5ea706"


# --- API Endpoints and Headers ---
start_url = "https://cms-gcp.classplusapp.com/student/api/v2/test/start"
evaluate_url = "https://cms-gcp.classplusapp.com/student/api/v2/test/evaluate"

base_headers = {
    "accept": "application/json, text/plain, */*",
    "accept-encoding": "gzip, deflate, br",
    "content-type": "application/json",
    "origin": "https://student-cms.classplusapp.com",
    "referer": "https://student-cms.classplusapp.com/",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "x-cms-access-token": ACCESS_TOKEN
}

# --- STEP 1: Start the Test ---
print("▶️  STEP 1: Starting the test...")
start_payload = {"testId": TEST_ID_PAYLOAD}

try:
    response = requests.post(start_url, json=start_payload, headers=base_headers)
    response.raise_for_status() # Raises an error for bad status codes (4xx or 5xx)

    start_data = response.json()
    test_id = start_data['data']['test']['_id']
    student_test_id = start_data['data']['studentTestId']
    # Generate a unique device ID for this session
    device_id = start_data['data'].get('deviceId', f"web_{int(time.time() * 1000)}")
    print(f"✅ Test Started Successfully. StudentTestId: {student_test_id}")

except (requests.exceptions.RequestException, KeyError, IndexError) as e:
    print(f"❌ Could not start the test. Error: {e}")
    if 'response' in locals() and response.content:
         print(f"   Raw response: {response.text[:500]}") # Show first 500 chars of response
    exit()


# --- STEP 2: Evaluate the Test Immediately (Auto-Submit) ---
# We skip submitting any questions and go straight to evaluation.
# The server will mark the test as submitted even with no answers.
print("\n▶️  STEP 2: Forcing immediate test evaluation (auto-submitting)...")
headers_with_device = {**base_headers, "x-cms-device-id": str(device_id)}

evaluate_payload = {
    "testId": test_id,
    "studentTestId": student_test_id,
    "questions": [],  # Sending an empty list as we haven't answered anything
    "timeTaken": 5000, # A small, arbitrary time taken in milliseconds
    "reasonForSubmit": "Student submitted test successfully",
    "autoSubmitType": 1 # This flag seems to help the auto-submit process
}

try:
    eval_response = requests.post(evaluate_url, headers=headers_with_device, json=evaluate_payload)
    eval_response.raise_for_status()
    print(f"✅ Test Evaluation Request Sent. Status: {eval_response.status_code}")

except requests.exceptions.RequestException as e:
    print(f"❌ Could not evaluate the test. Error: {e}")
    if 'eval_response' in locals() and eval_response.content:
         print(f"   Raw response: {eval_response.text[:500]}")
    exit()


# --- STEP 3: Fetch Solutions ---
solution_url = f"https://cms-gcp.classplusapp.com/student/api/v2/test/{test_id}/student/{student_test_id}/solutions?section=true"

print("\n▶️  STEP 3: Fetching solutions...")
try:
    sol_response = requests.get(solution_url, headers=headers_with_device)
    sol_response.raise_for_status()
    print(f"✅ Solutions Request Sent. Status: {sol_response.status_code}")

except requests.exceptions.RequestException as e:
    print(f"❌ Could not fetch solutions. Error: {e}")
    if 'sol_response' in locals() and sol_response.content:
        print(f"   Raw response: {sol_response.text[:500]}")
    exit()


# --- STEP 4: Save Solutions to File ---
try:
    solution_data = sol_response.json()
    file_name = f"solutions_{test_id}.json"
    with open(file_name, "w", encoding="utf-8") as f:
        json.dump(solution_data, f, indent=2, ensure_ascii=False)
    print(f"\n🎉🎉🎉 SUCCESS! Solutions saved to '{file_name}' 🎉🎉🎉")

except (json.JSONDecodeError, IOError) as e:
    print(f"❌ An error occurred during file saving or JSON decoding: {e}")
    print("   Saving raw response text instead.")
    with open(f"solutions_raw_{test_id}.txt", "w", encoding="utf-8") as f:
        f.write(sol_response.text)
    print(f"   Raw response saved to 'solutions_raw_{test_id}.txt'")